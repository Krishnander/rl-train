"""
Production RL Training Pipeline with Full Multi-Objective Support.

Features:
- 5-objective reward tracking (Sharpe, ROI, DD, Survival, Efficiency)
- ReDit-enabled GRPO
- EWC + Replay for continual learning
- Cyclic regime curriculum
"""

import sys
import os
import jax
import jax.numpy as jnp
import numpy as np
from typing import List, Dict, Optional
import pickle
from pathlib import Path

# Add src to path
sys.path.append(os.path.join(os.getcwd(), 'src'))

from env.nifty_env import NiftyEnv
from models.moe import MoENet
from models.grpo import GRPOTrainer
from models.continual import EWC, ReplayBuffer


class RLTrainer:
    """
    Production-grade RL training with multi-objective optimization.
    
    Features:
    - Full 5-objective reward tracking
    - EWC for catastrophic forgetting prevention
    - Experience replay for rare events
    - Cyclic regime curriculum
    """
    
    def __init__(self, group_size: int = 8, seq_len: int = 30):
        self.group_size = group_size
        self.seq_len = seq_len
        self.env = NiftyEnv()
        
        # Continual Learning
        self.ewc = EWC(lambda_ewc=50.0)
        self.replay_buffer = ReplayBuffer(capacity=100)
        
        # MoE Network (19 features as per expanded state space)
        self.model = MoENet(num_actions=4)
        self.trainer = GRPOTrainer(
            model=self.model, 
            learning_rate=3e-4,
            redit_scale=0.1,  # ReDit enabled
            ewc_fn=self.ewc.penalty
        )
        
        self.rng = jax.random.PRNGKey(42)
        self.state = self.trainer.init_state(self.rng, obs_dim=NiftyEnv.OBS_DIM)
        
        # Regime curriculum
        self.regime_schedule = [0, 1, 2, 3]
        self.current_regime_idx = 0
    
    def collect_rollouts(self, fixed_regime: Optional[int] = None) -> Dict[str, jnp.ndarray]:
        """
        Collect trajectories with full 5-objective metrics.
        """
        all_obs = []
        all_actions = []
        all_logprobs = []
        
        # 5 objectives
        all_sharpe = []
        all_roi = []
        all_drawdown = []
        all_survival = []
        all_efficiency = []
        
        for _ in range(self.group_size):
            obs = self.env.reset(fixed_regime=fixed_regime)
            obs_seq = []
            act_seq = []
            lp_seq = []
            
            done = False
            step_count = 0
            
            # Initialize hidden state for the episode (Milestone 8)
            h = self.model.initialize_carry(1)
            
            while not done and step_count < self.seq_len:
                self.rng, subkey = jax.random.split(self.rng)
                logits, values, _, next_h = self.model.apply(self.state.params, obs[jnp.newaxis, ...], h)
                
                action = jax.random.categorical(subkey, logits[0])
                log_prob = jax.nn.log_softmax(logits[0])[action]
                
                # Dynamic Edge Prediction
                predicted_edge = float(values[0, 0])
                
                new_obs, reward, done, info = self.env.step(int(action), expected_edge_pct=predicted_edge)
                
                obs_seq.append(obs)
                act_seq.append(int(action))
                lp_seq.append(float(log_prob))
                
                obs = new_obs
                h = next_h  # Propagate hidden state
                step_count += 1
            
            # Pad if necessary
            while len(obs_seq) < self.seq_len:
                obs_seq.append(obs_seq[-1] if obs_seq else np.zeros(NiftyEnv.OBS_DIM))
                act_seq.append(0)
                lp_seq.append(0.0)
            
            all_obs.append(jnp.array(obs_seq[:self.seq_len]))
            all_actions.append(jnp.array(act_seq[:self.seq_len]))
            all_logprobs.append(jnp.array(lp_seq[:self.seq_len]))
            
            # Compute 5 objectives from final episode info
            # SNIPER PATCH: Heavily penalize excessive trading
            trade_count = info['trade_count']
            
            all_sharpe.append(info['sharpe'])
            all_roi.append(info['roi'])
            all_drawdown.append(-info['max_drawdown'])  # Negative because we want to minimize DD
            all_survival.append(info['survival_pct'])
            
            # CRITICAL: Loosening the Sniper Lock for Mastery Phase
            # Was -0.5, now -0.05 per trade to encourage exploration of recursive edges
            if trade_count <= 1:
                efficiency_score = 0.5  # Higher bonus for being selective
            elif trade_count <= 2:
                efficiency_score = 0.1  # Small bonus
            else:
                efficiency_score = -0.05 * (trade_count - 2)  # Light penalty
            
            all_efficiency.append(efficiency_score)
        
        return {
            'obs': jnp.stack(all_obs),
            'actions': jnp.stack(all_actions),
            'old_logprobs': jnp.stack(all_logprobs),
            'rewards_sharpe': jnp.array(all_sharpe),
            'rewards_roi': jnp.array(all_roi),
            'rewards_drawdown': jnp.array(all_drawdown),
            'rewards_survival': jnp.array(all_survival),
            'rewards_efficiency': jnp.array(all_efficiency)
        }
    
    def train_step(self, step_idx: int):
        """Execute one training step with regime curriculum."""
        regime = self.regime_schedule[self.current_regime_idx]
        
        batch = self.collect_rollouts(fixed_regime=regime)
        
        # EWC update (every 10 steps, switch regime)
        if step_idx % 10 == 0 and step_idx > 0:
            print(f"  [EWC] Updating importance for regime {regime}")
            self.ewc.update_importance(self.state, batch, self.trainer.compute_loss)
            self.replay_buffer.add(batch)
            self.current_regime_idx = (self.current_regime_idx + 1) % len(self.regime_schedule)
        
        # Log every 10 steps
        if step_idx % 10 == 0:
            mean_sharpe = jnp.mean(batch['rewards_sharpe'])
            mean_roi = jnp.mean(batch['rewards_roi'])
            mean_dd = -jnp.mean(batch['rewards_drawdown'])
            print(f"  Regime={regime}, Sharpe={mean_sharpe:.2f}, ROI={mean_roi*100:.1f}%, DD={mean_dd:.1%}")
        
        # Main update
        self.rng, subkey = jax.random.split(self.rng)
        self.state, loss, info = self.trainer.update(self.state, batch, subkey)
        
        # Experience replay (every 5 steps)
        if step_idx % 5 == 0:
            replay_batch = self.replay_buffer.sample()
            if replay_batch:
                self.rng, subkey = jax.random.split(self.rng)
                self.state, _, _ = self.trainer.update(self.state, replay_batch, subkey)
        
        return loss, info
    
    def save_params(self, path: str = "checkpoints/rl_trader_v2.pkl"):
        """Save model parameters."""
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        with open(path, "wb") as f:
            pickle.dump(self.state.params, f)
        print(f"Model saved to {path}")


def main():
    print("=" * 60)
    print("  - 5-objective MO-GRPO (Sharpe, ROI, DD, Survival, Efficiency)")
    print("  - ReDit for 10x faster convergence")
    print("  - EWC + Replay for continual learning")
    print("  - 21-feature state space (Recursive Upgrade)")
    print("  - Realistic microstructure (VIX-dependent)")
    print("=" * 60)
    
    trainer = RLTrainer(group_size=8)
    
    total_steps = 500  # MASTERY SESSION (High-Fidelity Sim-to-Real)
    try:
        for i in range(total_steps):
            loss, info = trainer.train_step(i)
            if i % 10 == 0:
                print(f"Step {i}: Loss={loss:.4f}, Entropy={info['entropy']:.3f}, "
                      f"RouterEnt={info['router_entropy']:.3f}")
    except KeyboardInterrupt:
        print("\nTraining interrupted by user. Saving progress...")
    
    trainer.save_params()
    print("\nTraining complete!")


if __name__ == "__main__":
    main()
