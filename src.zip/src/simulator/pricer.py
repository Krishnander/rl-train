import numpy as np
from scipy.stats import norm
from typing import Tuple

class OptionPricer:
    """
    Standard Black-Scholes pricing with realistic adjustments for Nifty options.
    """
    
    def __init__(self, risk_free_rate: float = 0.065):
        self.r = risk_free_rate  # 6.5% standard for India
        
    def black_scholes(self, S: float, K: float, T: float, sigma: float, option_type: str = 'call') -> float:
        """
        Standard Black-Scholes formula.
        S: Spot price
        K: Strike price
        T: Time to expiry in years
        sigma: Implied Volatility (decimal)
        """
        if T <= 0:
            if option_type == 'call':
                return max(0, S - K)
            else:
                return max(0, K - S)
                
        d1 = (np.log(S / K) + (self.r + 0.5 * sigma**2) * T) / (sigma * np.sqrt(T))
        d2 = d1 - sigma * np.sqrt(T)
        
        if option_type == 'call':
            price = S * norm.cdf(d1) - K * np.exp(-self.r * T) * norm.cdf(d2)
        else:
            price = K * np.exp(-self.r * T) * norm.cdf(-d2) - S * norm.cdf(-d1)
            
        return max(0, price)
        
    def get_greeks(self, S: float, K: float, T: float, sigma: float, option_type: str = 'call') -> dict:
        """
        Calculate key Greeks (Delta, Gamma, Theta).
        """
        if T <= 0:
            return {
                'delta': 1.0 if (option_type == 'call' and S > K) or (option_type == 'put' and S < K) else 0.0, 
                'theta': 0.0,
                'gamma': 0.0
            }
            
        d1 = (np.log(S / K) + (self.r + 0.5 * sigma**2) * T) / (sigma * np.sqrt(T))
        d2 = d1 - sigma * np.sqrt(T)
        
        # Delta
        if option_type == 'call':
            delta = norm.cdf(d1)
        else:
            delta = norm.cdf(d1) - 1
        
        # Gamma (same for call and put)
        gamma = norm.pdf(d1) / (S * sigma * np.sqrt(T))
            
        # Theta (approximate yearly to daily)
        theta_common = -(S * norm.pdf(d1) * sigma) / (2 * np.sqrt(T))
        if option_type == 'call':
            theta = theta_common - self.r * K * np.exp(-self.r * T) * norm.cdf(d2)
        else:
            theta = theta_common + self.r * K * np.exp(-self.r * T) * norm.cdf(-d2)
            
        return {
            'delta': float(delta),
            'gamma': float(gamma),
            'theta': float(theta / 252)  # Return daily theta
        }

    def price_pair(self, S: float, K: float, T_days: int, vix: float, regime_adj: float = 1.0) -> Tuple[float, float]:
        """
        Price ATM Call and Put pair given VIX.
        T_days: Days to expiry
        vix: VIX value (e.g., 15.5)
        regime_adj: Multiplier for IV based on market regime (e.g., 1.2 in Crisis)
        """
        T = max(T_days, 0.5) / 365.0  # Min 0.5 day to avoid division by zero
        # Simple VIX to IV mapping (VIX is roughly ATM IV)
        sigma = (vix / 100.0) * regime_adj
        
        # Add some noise/skew adjustment (Real IV is usually VIX + 2-3%)
        sigma += 0.02 
        
        ce_price = self.black_scholes(S, K, T, sigma, 'call')
        pe_price = self.black_scholes(S, K, T, sigma, 'put')
        
        return ce_price, pe_price
