
import jax
import jax.numpy as jnp
from jax.scipy.special import erf

def cdf_norm(x):
    """Cumulative distribution function for standard normal distribution."""
    return 0.5 * (1.0 + erf(x / jnp.sqrt(2.0)))

def pdf_norm(x):
    """Probability density function for standard normal distribution."""
    return jnp.exp(-0.5 * x**2) / jnp.sqrt(2.0 * jnp.pi)

def bs_price(S, K, T, r, sigma, option_type):
    """
    Vectorized Black-Scholes Pricing.
    
    Args:
        S: Spot price
        K: Strike price
        T: Time to expiry (in years)
        r: Risk-free rate
        sigma: Implied Volatility
        option_type: 1 for Call, -1 for Put (using -1 simplifies put logic)
                     BUT our Env uses {0: Hold, 1: Call, 2: Put}.
                     So we should use 'is_call' boolean or map internally.
                     Let's stick to standard 'is_call' boolean or flag.
                     
    Returns:
        Option Price
    """
    # Prevent divide by zero
    T = jnp.maximum(T, 1e-5)
    sigma = jnp.maximum(sigma, 1e-4) # Min 0.01% vol
    
    d1 = (jnp.log(S / K) + (r + 0.5 * sigma**2) * T) / (sigma * jnp.sqrt(T))
    d2 = d1 - sigma * jnp.sqrt(T)
    
    # Call Price
    call_price = S * cdf_norm(d1) - K * jnp.exp(-r * T) * cdf_norm(d2)
    
    # Put Price (Put-Call Parity)
    put_price = K * jnp.exp(-r * T) * cdf_norm(-d2) - S * cdf_norm(-d1)
    
    return jnp.where(option_type == 1, call_price, put_price)

def bs_greeks(S, K, T, r, sigma):
    """
    Computes Greeks for both Call and Put.
    
    Returns:
        params dict with delta_call, delta_put, gamma, theta_call, theta_put, vega
    """
    T = jnp.maximum(T, 1e-5)
    sigma = jnp.maximum(sigma, 1e-4)
    
    d1 = (jnp.log(S / K) + (r + 0.5 * sigma**2) * T) / (sigma * jnp.sqrt(T))
    d2 = d1 - sigma * jnp.sqrt(T)
    
    pdf_d1 = pdf_norm(d1)
    cdf_d1 = cdf_norm(d1)
    cdf_d2 = cdf_norm(d2)
    cdf_neg_d1 = cdf_norm(-d1)
    cdf_neg_d2 = cdf_norm(-d2)
    
    # Delta
    delta_call = cdf_d1
    delta_put = delta_call - 1.0
    
    # Gamma (Same for Call and Put)
    gamma = pdf_d1 / (S * sigma * jnp.sqrt(T))
    
    # Vega (Same for Call and Put) -> Sensitivity to Vol (1% change)
    vega = S * pdf_d1 * jnp.sqrt(T) * 0.01 
    
    # Theta (Daily Decay)
    # Theta Call
    term1 = -(S * pdf_d1 * sigma) / (2 * jnp.sqrt(T))
    term2_call = -r * K * jnp.exp(-r * T) * cdf_d2
    theta_call = (term1 + term2_call) / 365.0
    
    # Theta Put
    term2_put = r * K * jnp.exp(-r * T) * cdf_neg_d2
    theta_put = (term1 + term2_put) / 365.0
    
    return {
        'delta_call': delta_call,
        'delta_put': delta_put,
        'gamma': gamma,
        'vega': vega,
        'theta_call': theta_call,
        'theta_put': theta_put
    }
