"""
Expanded MarketState with all 18+ features from DESIGN.md specification.
"""

import numpy as np
import pandas as pd
from typing import List, Dict, Any, Optional
from dataclasses import dataclass, field
from simulator.pricer import OptionPricer
from simulator.microstructure import Microstructure

@dataclass
class MarketState:
    """
    Complete market state with all features from DESIGN.md specification.
    
    18 core features:
    - Market: spot, prev_close, gap_pct, vix, vix_percentile
    - Options: ce_premium, pe_premium, iv_skew, dte, ce_delta, pe_delta, ce_theta, pe_theta
    - Flow: fii_momentum_5d, fii_net_oi_z, retail_trap_z
    - Portfolio: position_type, entry_price, unrealized_pnl_pct, drawdown_from_peak, days_in_trade
    """
    # Timestamps
    timestamp: pd.Timestamp
    day_index: int
    
    # Market Data
    spot: float
    prev_close: float
    gap_pct: float  # Today's open vs yesterday's close
    vix: float
    vix_percentile: float  # Rolling 252-day percentile
    
    # Options Data
    atm_strike: float
    ce_price: float
    pe_price: float
    iv_skew: float  # Put IV - Call IV (positive = fear)
    days_to_expiry: int
    ce_delta: float
    pe_delta: float
    ce_theta: float
    pe_theta: float
    ce_gamma: float
    pe_gamma: float
    
    # Flow Signals
    fii_momentum_5d: float
    fii_net_oi_z: float  # Z-score of FII net OI
    fii_velocity: float  # ROC of FII flow (Milestone 13)
    retail_trap_z: float
    
    # Microstructure
    bid_ask_spread: float
    regime: int  # 0: Calm, 1: Bull, 2: Bear, 3: Crisis
    
    # SOTA Trend Features (Milestone 18)
    ma_50_slope: float = 0.0
    ma_200_div: float = 0.0


class MarketSimulator:
    """
    Production-grade Nifty Market Simulator.
    
    Features:
    - 4-state HMM regime model
    - VIX-dependent microstructure
    - Full Black-Scholes Greeks
    - Realistic signal dynamics
    """
    
    def __init__(self, historical_data_path: Optional[str] = None):
        self.pricer = OptionPricer()
        self.microstructure = Microstructure()
        
        # Regime definitions with realistic parameters (Fitted from 2020-2024 data)
        self.regimes = {
            0: {'name': 'Calm',   'vol': 0.012, 'bias': -0.0005, 'vix_range': (10, 18), 'fii_bias': 200},
            1: {'name': 'Bull',   'vol': 0.010, 'bias': 0.0015,  'vix_range': (12, 16), 'fii_bias': 900},
            2: {'name': 'Bear',   'vol': 0.018, 'bias': -0.0025, 'vix_range': (18, 28), 'fii_bias': -1500},
            3: {'name': 'Crisis', 'vol': 0.028, 'bias': -0.0065, 'vix_range': (28, 60), 'fii_bias': -3500}
        }
        
        # Transition matrix (fitted from historical Nifty regimes)
        self.transition_matrix = np.array([
            [0.92, 0.05, 0.02, 0.01],  # Calm → most stable
            [0.08, 0.87, 0.04, 0.01],  # Bull → sticky
            [0.04, 0.04, 0.82, 0.10],  # Bear → can escalate
            [0.02, 0.02, 0.16, 0.80]   # Crisis → slowly recovers
        ])
        
        # VIX history for percentile calculation
        self.vix_history = []
        self.vix_history_window = 252  # 1 year trading days
        
        if historical_data_path:
            self._fit_from_data(historical_data_path)
    
    def _fit_from_data(self, path: str):
        """Fit model parameters from historical data."""
        # TODO: Implement in Phase 2
        pass
    
    def _update_vix_percentile(self, vix: float) -> float:
        """Calculate rolling VIX percentile."""
        self.vix_history.append(vix)
        if len(self.vix_history) > self.vix_history_window:
            self.vix_history.pop(0)
        
        if len(self.vix_history) < 20:
            return 0.5  # Not enough data
        
        return np.mean(np.array(self.vix_history) <= vix)
    
    def generate_episode(self, start_spot: float = 22000.0, days: int = 30, 
                         fixed_regime: Optional[int] = None) -> List[MarketState]:
        """
        Generate a complete trading episode.
        
        Args:
            start_spot: Starting Nifty level
            days: Episode length
            fixed_regime: If set, locks to this regime (for curriculum training)
        """
        episode = []
        
        # Initialize state
        current_spot = start_spot
        prev_close = start_spot
        
        if fixed_regime is not None:
            current_regime = fixed_regime
        else:
            current_regime = np.random.choice([0, 1])
        
        # Initial values
        vix = np.random.uniform(*self.regimes[current_regime]['vix_range'])
        fii_momentum = np.random.normal(0, 500)
        fii_net_oi_z = np.random.normal(0, 1)
        retail_trap = np.random.normal(0, 0.5)
        
        days_to_expiry = np.random.randint(3, 10)
        start_date = pd.Timestamp.now().normalize()
        
        for d in range(days):
            # 1. Regime Transition
            if fixed_regime is None:
                current_regime = np.random.choice(4, p=self.transition_matrix[current_regime])
            
            regime_params = self.regimes[current_regime]
            
            # 2. Market Price Evolution (Regime-aware GBM)
            gap_pct = np.random.normal(regime_params['bias'], regime_params['vol'] * 0.5)
            intraday_return = np.random.normal(0, regime_params['vol'] * 0.7)
            
            open_price = prev_close * (1 + gap_pct)
            current_spot = open_price * (1 + intraday_return)
            
            # 3. VIX Evolution (Mean-reverting O-U process)
            vix_target = np.mean(regime_params['vix_range'])
            vix_vol = 0.8 if current_regime <= 1 else 1.5
            vix += 0.15 * (vix_target - vix) + np.random.normal(0, vix_vol)
            vix = np.clip(vix, 8, 60)
            
            vix_percentile = self._update_vix_percentile(vix)
            
            # 4. Signal Evolution
            # FII Momentum (AR(1) with regime-dependent drift)
            fii_momentum = 0.75 * fii_momentum + 0.25 * np.random.normal(regime_params['fii_bias'], 1000)
            
            # FII Net OI Z-score (correlated with momentum)
            fii_net_oi_z = 0.8 * fii_net_oi_z + 0.2 * (fii_momentum / 2000 + np.random.normal(0, 0.5))
            fii_net_oi_z = np.clip(fii_net_oi_z, -3, 3)
            
            # Retail Trap (contrarian indicator)
            rt_bias = -0.5 if current_regime == 1 else 0.8 if current_regime >= 2 else 0
            retail_trap = 0.7 * retail_trap + 0.3 * np.random.normal(rt_bias, 0.5)
            retail_trap = np.clip(retail_trap, -2.5, 2.5)
            
            # 5. Option Pricing
            atm_strike = round(current_spot / 50) * 50
            T = max(days_to_expiry, 0.5) / 365.0
            
            # IV from VIX with regime adjustment
            regime_iv_adj = {0: 0.95, 1: 0.98, 2: 1.05, 3: 1.25}
            sigma = (vix / 100.0) * regime_iv_adj[current_regime] + 0.02
            
            ce_price = self.pricer.black_scholes(current_spot, atm_strike, T, sigma, 'call')
            pe_price = self.pricer.black_scholes(current_spot, atm_strike, T, sigma, 'put')
            
            # IV Skew (Put IV - Call IV, typically positive)
            iv_skew = np.random.normal(0.02, 0.01) * (1 + 0.1 * retail_trap)
            
            # Greeks
            ce_greeks = self.pricer.get_greeks(current_spot, atm_strike, T, sigma, 'call')
            pe_greeks = self.pricer.get_greeks(current_spot, atm_strike, T, sigma, 'put')
            
            # Microstructure
            spread = self.microstructure.bid_ask_spread(vix)
            
            episode.append(MarketState(
                timestamp=start_date + pd.Timedelta(days=d),
                day_index=d,
                spot=float(current_spot),
                prev_close=float(prev_close),
                gap_pct=float(gap_pct),
                vix=float(vix),
                vix_percentile=float(vix_percentile),
                atm_strike=float(atm_strike),
                ce_price=float(ce_price),
                pe_price=float(pe_price),
                iv_skew=float(iv_skew),
                days_to_expiry=days_to_expiry,
                ce_delta=ce_greeks['delta'],
                pe_delta=pe_greeks['delta'],
                ce_theta=ce_greeks['theta'],
                pe_theta=pe_greeks['theta'],
                ce_gamma=ce_greeks.get('gamma', 0.0),
                pe_gamma=ce_greeks.get('gamma', 0.0),
                fii_momentum_5d=float(fii_momentum),
                fii_net_oi_z=float(fii_net_oi_z),
                retail_trap_z=float(retail_trap),
                bid_ask_spread=float(spread),
                regime=current_regime
            ))
            
            # Update for next day
            prev_close = current_spot
            days_to_expiry -= 1
            if days_to_expiry < 1:
                days_to_expiry = np.random.randint(5, 10)  # New expiry cycle
        
        return episode
