"""
Production Evaluation Script for RL Trader v2.

Evaluates the trained agent against baselines across all regimes.
Reports all 5 objectives: Sharpe, ROI, Drawdown, Survival, Efficiency.
"""

import sys
import os
import jax
import jax.numpy as jnp
import numpy as np
import pickle
from typing import Dict, List

sys.path.append(os.path.join(os.getcwd(), 'src'))

from env.nifty_env import NiftyEnv
from models.moe import MoENet
from agents.rule_based import RuleBasedAgent


class Evaluator:
    """
    Comprehensive evaluation across all regimes and objectives.
    """
    
    def __init__(self, checkpoint_path: str = "checkpoints/rl_trader_v2.pkl"):
        self.env = NiftyEnv()
        self.model = MoENet(num_actions=4)
        
        if os.path.exists(checkpoint_path):
            with open(checkpoint_path, "rb") as f:
                loaded = pickle.load(f)
            # Handle different checkpoint formats
            if isinstance(loaded, dict) and 'params' in loaded:
                self.params = loaded['params']  # Unwrap if nested
            else:
                self.params = loaded
            print(f"Loaded parameters from {checkpoint_path}")
        else:
            print(f"WARNING: Checkpoint not found at {checkpoint_path}")
            # Initialize with random params for testing
            rng = jax.random.PRNGKey(0)
            dummy_obs = jnp.ones((1, NiftyEnv.OBS_DIM))
            dummy_h = self.model.initialize_carry(1)
            self.params = self.model.init(rng, dummy_obs, dummy_h)
    
    def run_agent(self, agent_type: str, n_episodes: int = 20, 
                  regime: int = None) -> Dict:
        """
        Run agent and collect all 5 objective metrics.
        """
        results = {
            'sharpe': [],
            'roi': [],
            'max_dd': [],
            'survival': [],
            'trade_count': []
        }
        
        rule_agent = RuleBasedAgent(fii_threshold=500.0)
        
        for _ in range(n_episodes):
            obs = self.env.reset(fixed_regime=regime)
            done = False
            h = self.model.initialize_carry(1)  # Initialize hidden state
            
            while not done:
                if agent_type == "rl":
                    logits, values, _, h = self.model.apply(self.params, obs[jnp.newaxis, ...], h)
                    action = int(jnp.argmax(logits[0]))
                    predicted_edge = float(values[0, 0])
                    obs, _, done, info = self.env.step(action, expected_edge_pct=predicted_edge)
                elif agent_type == "rule":
                    # Map obs to rule-based format
                    fii_mom = obs[12] * 5000  # Denormalize
                    vix = obs[2] * 50
                    action = rule_agent.act_on_features(fii_mom, vix)
                    obs, _, done, info = self.env.step(action)
                else:  # random
                    action = np.random.choice([0, 1, 2, 3], p=[0.7, 0.1, 0.1, 0.1])
                    obs, _, done, info = self.env.step(action)
            
            results['sharpe'].append(info['sharpe'])
            results['roi'].append(info['roi'])
            results['max_dd'].append(info['max_drawdown'])
            results['survival'].append(info['survival_pct'])
            results['trade_count'].append(info['trade_count'])
        
        return {
            'mean_sharpe': np.mean(results['sharpe']),
            'mean_roi': np.mean(results['roi']),
            'mean_dd': np.mean(results['max_dd']),
            'mean_survival': np.mean(results['survival']),
            'mean_trades': np.mean(results['trade_count']),
            'win_rate': np.mean(np.array(results['roi']) > 0) * 100
        }


def main():
    evaluator = Evaluator()
    
    print("\n" + "=" * 70)
    print("RL TRADER v2.0 - FINAL EVALUATION")
    print("=" * 70)
    
    regimes = {0: "Calm", 1: "Bull", 2: "Bear", 3: "Crisis"}
    agents = ["rl", "rule", "random"]
    
    all_results = {}
    
    for rid, name in regimes.items():
        print(f"\n--- Regime: {name} ---")
        print(f"{'Agent':<12} | {'Sharpe':>8} | {'ROI':>8} | {'MaxDD':>8} | {'WinRate':>8} | {'Trades':>6}")
        print("-" * 70)
        
        for agent in agents:
            stats = evaluator.run_agent(agent, n_episodes=20, regime=rid)
            agent_name = "RL (MO-GRPO)" if agent == "rl" else ("Rule-Based" if agent == "rule" else "Random")
            
            print(f"{agent_name:<12} | {stats['mean_sharpe']:>8.2f} | "
                  f"{stats['mean_roi']*100:>7.1f}% | {stats['mean_dd']*100:>7.1f}% | "
                  f"{stats['win_rate']:>7.0f}% | {stats['mean_trades']:>6.1f}")
            
            all_results[f"{name}_{agent}"] = stats
    
    # Overall summary
    print("\n" + "=" * 70)
    print("OVERALL SUMMARY")
    print("=" * 70)
    
    for agent in agents:
        agent_name = "RL (MO-GRPO)" if agent == "rl" else ("Rule-Based" if agent == "rule" else "Random")
        avg_roi = np.mean([all_results[f"{name}_{agent}"]['mean_roi'] for name in regimes.values()])
        avg_sharpe = np.mean([all_results[f"{name}_{agent}"]['mean_sharpe'] for name in regimes.values()])
        avg_dd = np.mean([all_results[f"{name}_{agent}"]['mean_dd'] for name in regimes.values()])
        
        print(f"{agent_name:<12}: Avg ROI={avg_roi*100:.1f}%, Avg Sharpe={avg_sharpe:.2f}, Avg DD={avg_dd*100:.1f}%")


if __name__ == "__main__":
    main()
