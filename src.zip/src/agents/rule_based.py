import numpy as np

class RuleBasedAgent:
    """
    Standard Rule-based agent following the Phase 0 discovery:
    - Long on high FII momentum (> 1500)
    - Short on low FII momentum (< -1500)
    - Hold for up to 10 days
    """
    
    def __init__(self, fii_threshold: float = 500.0, max_hold_days: int = 10):
        self.fii_threshold = fii_threshold
        self.max_hold_days = max_hold_days
        self.days_held = 0
        
    def act(self, obs: np.ndarray) -> int:
        """
        obs indices in NiftyEnv:
        0: spot_chg
        1: vix
        2: fii_mom (normalized by 5000)
        3: retail_trap
        4: dte
        5: pos_type (0: None, 0.5: CE, 1.0: PE)
        6: unrealized_pnl
        """
        fii_mom = obs[2] * 5000.0 # Denormalize
        pos_type_norm = obs[5]
        pos_type = 0
        if pos_type_norm == 0.5: pos_type = 1
        elif pos_type_norm == 1.0: pos_type = 2
        
        # 1. If currently in a position
        if pos_type > 0:
            self.days_held += 1
            # Exit conditions:
            # - Hold limit reached
            # - Drastic signal flip (optional, but let's stick to pure time-based for baseline)
            if self.days_held >= self.max_hold_days:
                self.days_held = 0
                return 3 # EXIT
            return 0 # HOLD
            
        # 2. If no position, look for entry
        if fii_mom > self.fii_threshold:
            self.days_held = 0
            return 1 # BUY_CE
        elif fii_mom < -self.fii_threshold:
            self.days_held = 0
            return 2 # BUY_PE
            
        return 0 # NO_SIGNAL

    def act_on_features(self, fii_momentum: float, vix: float) -> int:
        """
        Action based on raw features (for evaluation use).
        """
        # High VIX = stay out
        if vix > 30:
            return 0  # HOLD
        
        if fii_momentum > self.fii_threshold:
            return 1  # BUY_CE
        elif fii_momentum < -self.fii_threshold:
            return 2  # BUY_PE
        else:
            return 0  # HOLD
