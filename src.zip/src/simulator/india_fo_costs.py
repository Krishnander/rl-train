"""
India F&O Trading Costs (2026) - Based on SEBI/NSE Regulations.

Official rates effective January 2026:
- Nifty lot size: 65 units
- STT: 0.10% on option sell (increased Oct 2024)
- NSE Transaction: 0.03503% on premium
- SEBI Fee: ₹10 per crore
- Stamp Duty: 0.003% on options buy
- GST: 18% on (brokerage + exchange + SEBI)
- Brokerage: ₹20 flat per order (discount broker)

Sources:
- NSE India (nseindia.com)
- SEBI Circular October 2024
- Zerodha Calculator
"""

from dataclasses import dataclass
from typing import Tuple


@dataclass
class TradeDetails:
    """Details of a single option trade."""
    premium: float           # Option premium per unit
    quantity: int            # Number of units
    is_buy: bool            # True for buy, False for sell
    is_intraday: bool = False  # Intraday or delivery
    spot_price: float = 22000  # Underlying spot (for reference)


@dataclass
class CostBreakdown:
    """Complete breakdown of trading costs."""
    contract_value: float    # Premium × Quantity
    brokerage: float        # Broker fee
    stt: float              # Securities Transaction Tax
    exchange_txn: float     # NSE Transaction charges
    sebi_fee: float         # SEBI Turnover fee
    stamp_duty: float       # State stamp duty
    gst: float              # GST on services
    ipft: float             # Investor Protection Fund
    total_cost: float       # Total all-in cost
    cost_pct: float         # Cost as % of contract value


class IndiaFOCostCalculator:
    """
    Precise F&O cost calculator for Indian markets (2026).
    
    All rates based on SEBI circulars and NSE schedule.
    """
    
    # 2026 Lot Sizes (Jan 2026 onwards)
    LOT_SIZES = {
        'NIFTY': 65,
        'BANKNIFTY': 30,
        'FINNIFTY': 60,
        'MIDCPNIFTY': 120,
        'NIFTYNEXT50': 25
    }
    
    # Cost Rates (2026)
    # STT - Securities Transaction Tax
    STT_OPTIONS_SELL = 0.0010      # 0.10% on sell (Oct 2024 increase)
    STT_OPTIONS_EXERCISE = 0.00125 # 0.125% on exercise
    STT_FUTURES_SELL = 0.0002      # 0.02% on sell
    
    # NSE Transaction Charges
    NSE_TXN_OPTIONS = 0.0003503    # 0.03503% on premium
    NSE_TXN_FUTURES = 0.0000180    # 0.00180% on turnover
    
    # SEBI Fee
    SEBI_FEE_PER_CRORE = 10        # ₹10 per crore
    
    # Stamp Duty (buy side only)
    STAMP_DUTY_OPTIONS = 0.00003   # 0.003%
    STAMP_DUTY_FUTURES = 0.00002   # 0.002%
    
    # GST
    GST_RATE = 0.18                # 18%
    
    # IPFT (Investor Protection Fund Trust)
    IPFT_RATE = 0.000005           # ₹0.50 per lakh = 0.0005%
    
    # Brokerage (Discount Broker - Zerodha/Groww/etc.)
    BROKERAGE_FLAT = 20            # ₹20 per executed order
    
    def __init__(self, index: str = 'NIFTY'):
        """
        Initialize calculator for specific index.
        
        Args:
            index: 'NIFTY', 'BANKNIFTY', 'FINNIFTY', 'MIDCPNIFTY', 'NIFTYNEXT50'
        """
        self.index = index.upper()
        self.lot_size = self.LOT_SIZES.get(self.index, 65)
    
    def calculate_buy_cost(self, premium: float, lots: int = 1) -> CostBreakdown:
        """
        Calculate total cost for BUYING options.
        
        On buy side: Brokerage, Exchange, SEBI, Stamp Duty, GST
        NO STT on buy.
        """
        quantity = lots * self.lot_size
        contract_value = premium * quantity
        
        # Brokerage (flat ₹20)
        brokerage = self.BROKERAGE_FLAT
        
        # Exchange Transaction
        exchange_txn = contract_value * self.NSE_TXN_OPTIONS
        
        # SEBI Fee
        sebi_fee = contract_value * (self.SEBI_FEE_PER_CRORE / 1e7)  # ₹10/Cr
        
        # Stamp Duty (only on buy)
        stamp_duty = contract_value * self.STAMP_DUTY_OPTIONS
        
        # STT - NONE on buy
        stt = 0.0
        
        # IPFT
        ipft = contract_value * self.IPFT_RATE
        
        # GST (on brokerage + exchange + SEBI)
        gst_base = brokerage + exchange_txn + sebi_fee
        gst = gst_base * self.GST_RATE
        
        total_cost = brokerage + stt + exchange_txn + sebi_fee + stamp_duty + gst + ipft
        cost_pct = (total_cost / contract_value) * 100 if contract_value > 0 else 0
        
        return CostBreakdown(
            contract_value=contract_value,
            brokerage=brokerage,
            stt=stt,
            exchange_txn=exchange_txn,
            sebi_fee=sebi_fee,
            stamp_duty=stamp_duty,
            gst=gst,
            ipft=ipft,
            total_cost=total_cost,
            cost_pct=cost_pct
        )
    
    def calculate_sell_cost(self, premium: float, lots: int = 1) -> CostBreakdown:
        """
        Calculate total cost for SELLING options.
        
        On sell side: Brokerage, Exchange, SEBI, STT, GST
        NO Stamp Duty on sell.
        """
        quantity = lots * self.lot_size
        contract_value = premium * quantity
        
        # Brokerage
        brokerage = self.BROKERAGE_FLAT
        
        # Exchange Transaction
        exchange_txn = contract_value * self.NSE_TXN_OPTIONS
        
        # SEBI Fee
        sebi_fee = contract_value * (self.SEBI_FEE_PER_CRORE / 1e7)
        
        # Stamp Duty - NONE on sell
        stamp_duty = 0.0
        
        # STT (0.10% on option sell - major cost!)
        stt = contract_value * self.STT_OPTIONS_SELL
        
        # IPFT
        ipft = contract_value * self.IPFT_RATE
        
        # GST
        gst_base = brokerage + exchange_txn + sebi_fee
        gst = gst_base * self.GST_RATE
        
        total_cost = brokerage + stt + exchange_txn + sebi_fee + stamp_duty + gst + ipft
        cost_pct = (total_cost / contract_value) * 100 if contract_value > 0 else 0
        
        return CostBreakdown(
            contract_value=contract_value,
            brokerage=brokerage,
            stt=stt,
            exchange_txn=exchange_txn,
            sebi_fee=sebi_fee,
            stamp_duty=stamp_duty,
            gst=gst,
            ipft=ipft,
            total_cost=total_cost,
            cost_pct=cost_pct
        )
    
    def calculate_round_trip(self, 
                              buy_premium: float, 
                              sell_premium: float, 
                              lots: int = 1) -> dict:
        """
        Calculate complete round-trip cost (buy + sell).
        
        Args:
            buy_premium: Entry premium
            sell_premium: Exit premium
            lots: Number of lots
            
        Returns:
            Dict with buy/sell breakdown and totals
        """
        buy = self.calculate_buy_cost(buy_premium, lots)
        sell = self.calculate_sell_cost(sell_premium, lots)
        
        gross_pnl = (sell_premium - buy_premium) * lots * self.lot_size
        total_costs = buy.total_cost + sell.total_cost
        net_pnl = gross_pnl - total_costs
        
        return {
            'buy': buy,
            'sell': sell,
            'gross_pnl': gross_pnl,
            'total_costs': total_costs,
            'net_pnl': net_pnl,
            'breakeven_move': (total_costs / (lots * self.lot_size)),
            'cost_as_pct_of_buy': (total_costs / buy.contract_value) * 100
        }
    
    def get_execution_slippage(self, 
                                premium: float, 
                                lots: int,
                                vix: float = 15,
                                urgency: float = 0.5) -> float:
        """
        Estimate execution slippage (bid-ask spread + impact).
        
        Args:
            premium: Option premium
            lots: Number of lots
            vix: VIX level
            urgency: 0=passive, 1=aggressive
            
        Returns:
            Slippage as fraction of premium
        """
        # Base spread (increases with VIX)
        base_spread_pct = 0.002 + 0.0001 * max(0, vix - 15)  # 0.2% base
        
        # Impact (increases with size)
        size_factor = (lots * self.lot_size) / 1000  # per 1000 units
        impact_pct = 0.0005 * size_factor  # 0.05% per 1000
        
        # Urgency multiplier
        urgency_mult = 0.5 + urgency  # 0.5x to 1.5x
        
        total_slippage = (base_spread_pct + impact_pct) * urgency_mult
        
        return total_slippage


# Convenience function for environment
def calculate_option_trade_cost(
    premium: float,
    lots: int = 1,
    is_buy: bool = True,
    index: str = 'NIFTY'
) -> Tuple[float, float]:
    """
    Convenience function to get total cost for an option trade.
    
    Args:
        premium: Option premium per unit
        lots: Number of lots
        is_buy: True for buy, False for sell
        index: Index name
        
    Returns:
        Tuple of (total_cost, cost_as_pct)
    """
    calc = IndiaFOCostCalculator(index)
    
    if is_buy:
        breakdown = calc.calculate_buy_cost(premium, lots)
    else:
        breakdown = calc.calculate_sell_cost(premium, lots)
    
    return breakdown.total_cost, breakdown.cost_pct


if __name__ == "__main__":
    calc = IndiaFOCostCalculator('NIFTY')
    
    print("=" * 70)
    print("INDIA F&O COST CALCULATOR (2026)")
    print("=" * 70)
    print(f"Index: NIFTY | Lot Size: {calc.lot_size}")
    
    # Example trade
    buy_premium = 150
    sell_premium = 180
    lots = 1
    
    print(f"\n--- Trade: {lots} lot @ Rs.{buy_premium} -> Rs.{sell_premium} ---\n")
    
    # Buy breakdown
    buy = calc.calculate_buy_cost(buy_premium, lots)
    print("BUY COST BREAKDOWN:")
    print(f"  Contract Value: Rs.{buy.contract_value:,.2f}")
    print(f"  Brokerage:      Rs.{buy.brokerage:,.2f}")
    print(f"  Exchange Txn:   Rs.{buy.exchange_txn:,.2f}")
    print(f"  SEBI Fee:       Rs.{buy.sebi_fee:,.2f}")
    print(f"  Stamp Duty:     Rs.{buy.stamp_duty:,.2f}")
    print(f"  STT:            Rs.{buy.stt:,.2f}")
    print(f"  GST:            Rs.{buy.gst:,.2f}")
    print(f"  IPFT:           Rs.{buy.ipft:,.2f}")
    print(f"  TOTAL:          Rs.{buy.total_cost:,.2f} ({buy.cost_pct:.2f}%)")
    
    # Sell breakdown
    sell = calc.calculate_sell_cost(sell_premium, lots)
    print("\nSELL COST BREAKDOWN:")
    print(f"  Contract Value: Rs.{sell.contract_value:,.2f}")
    print(f"  Brokerage:      Rs.{sell.brokerage:,.2f}")
    print(f"  Exchange Txn:   Rs.{sell.exchange_txn:,.2f}")
    print(f"  SEBI Fee:       Rs.{sell.sebi_fee:,.2f}")
    print(f"  Stamp Duty:     Rs.{sell.stamp_duty:,.2f}")
    print(f"  STT:            Rs.{sell.stt:,.2f}")
    print(f"  GST:            Rs.{sell.gst:,.2f}")
    print(f"  IPFT:           Rs.{sell.ipft:,.2f}")
    print(f"  TOTAL:          Rs.{sell.total_cost:,.2f} ({sell.cost_pct:.2f}%)")
    
    # Round trip
    rt = calc.calculate_round_trip(buy_premium, sell_premium, lots)
    print("\n--- ROUND TRIP SUMMARY ---")
    print(f"  Gross P&L:      Rs.{rt['gross_pnl']:,.2f}")
    print(f"  Total Costs:    Rs.{rt['total_costs']:,.2f}")
    print(f"  Net P&L:        Rs.{rt['net_pnl']:,.2f}")
    print(f"  Breakeven Move: Rs.{rt['breakeven_move']:.2f} per unit")
    print(f"  Cost % of Buy:  {rt['cost_as_pct_of_buy']:.2f}%")
    print("=" * 70)
