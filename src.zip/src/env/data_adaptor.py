import pandas as pd
import numpy as np
from typing import List, Optional
from pathlib import Path
import sys
import os

# Add src to path
sys.path.append(os.path.join(os.getcwd(), 'src'))

from simulator.simulator import MarketState
from simulator.pricer import OptionPricer

class ParquetLoader:
    """
    Loads and transforms historical parquet data into MarketState episodes.
    """
    def __init__(self, file_path: str):
        self.file_path = file_path
        self.df = pd.read_parquet(file_path)
        self._preprocess()
        self.pricer = OptionPricer()

    def _preprocess(self):
        """Resample 5-min data to Daily to match MoE training frequency."""
        # Ensure temporal order and convert index to datetime if not already
        self.df.index = pd.to_datetime(self.df.index)
        self.df = self.df.sort_index()
        
        # Resample to Daily (End of Day)
        # Aggregation rules:
        # Prices: Last value of the day
        # VIX/Signals: Mean or Last
        resampled = self.df.resample('D').agg({
            'syn_close': 'last',
            'atm_call_close': 'last',
            'atm_put_close': 'last',
            'otm_call_close': 'last',
            'otm_put_close': 'last',
            'atm_strike': 'last',
            'VIX': 'last',
            'FII_Net_OI_Z': 'last',
            'Retail_Trap_Z': 'last',
            'FII_Momentum_5D': 'last',
            'date': 'last'
        })
        
        # Use ffill to preserve trading days (don't drop)
        resampled = resampled.ffill().dropna(subset=['syn_close'])  # Only drop if no price
        
        self.df = resampled
        
        # Calculate Gap %
        self.df['prev_close'] = self.df['syn_close'].shift(1)
        self.df['gap_pct'] = (self.df['syn_close'] / self.df['prev_close'] - 1).fillna(0)
        
        self.df['vix_percentile'] = self.df['VIX'].rolling(252).apply(
            lambda x: (x[-1] >= x).mean() if len(x) > 0 else 0.5
        ).fillna(method='bfill').fillna(0.5)
        
        # SOTA Trend Features Calculation
        # 1. 50-day EMA Slope (Normalized)
        self.df['ma_50'] = self.df['syn_close'].ewm(span=50).mean()
        self.df['ma_50_slope'] = (self.df['ma_50'] - self.df['ma_50'].shift(1)) / self.df['ma_50']
        self.df['ma_50_slope'] = self.df['ma_50_slope'].fillna(0.0) * 100.0 # Scale up for NN
        
        # 2. 200-day SMA Divergence
        self.df['ma_200'] = self.df['syn_close'].rolling(window=200).mean()
        self.df['ma_200_div'] = (self.df['syn_close'] - self.df['ma_200']) / self.df['ma_200']
        self.df['ma_200_div'] = self.df['ma_200_div'].fillna(0.0)
        
        # Fill NaNs in sentiment features (22k+ NaNs found in source)
        self.df['FII_Net_OI_Z'] = self.df['FII_Net_OI_Z'].fillna(0.0)
        self.df['FII_Velocity'] = self.df['FII_Net_OI_Z'].diff().fillna(0.0) # ROC of Flow
        self.df['Retail_Trap_Z'] = self.df['Retail_Trap_Z'].fillna(0.0)
        self.df['FII_Momentum_5D'] = self.df['FII_Momentum_5D'].fillna(0.0)
        
        # Calculate IV Skew (proxy: OTM Put / OTM Call premium ratio)
        # Use safe division to avoid Inf/NaN
        self.df['iv_skew'] = (self.df['otm_put_close'] / self.df['otm_call_close'].replace(0, 0.01))
        self.df['iv_skew'] = self.df['iv_skew'].fillna(1.0).replace([np.inf, -np.inf], 10.0)
        self.df['iv_skew'] = self.df['iv_skew'].clip(0.1, 10.0)
        
        # Days to Expiry (Simplified: assume weekly Thursday expiry)
        self.df['date_dt'] = pd.to_datetime(self.df['date'])
        self.df['day_of_week'] = self.df['date_dt'].dt.dayofweek
        # Days until next Thursday (3)
        self.df['dte'] = (3 - self.df['day_of_week']) % 7
        self.df.loc[self.df['dte'] == 0, 'dte'] = 7 # Reset on expiry day for next cycle

    def get_episode(self, start_idx: int, length: int = 30) -> List[MarketState]:
        """Extract a sequence of historical data as MarketState objects."""
        subset = self.df.iloc[start_idx : start_idx + length]
        episode = []
        
        from simulator.microstructure import Microstructure
        micro = Microstructure()
        
        for i, (idx, row) in enumerate(subset.iterrows()):
            # Prepare arguments for Black-Scholes
            T = max(row['dte'], 0.5) / 365.0
            sigma = (row['VIX'] / 100.0) + 0.02 # Match pricer.py internal logic
            
            ce_greeks = self.pricer.get_greeks(row['syn_close'], row['atm_strike'], T, sigma, 'call')
            pe_greeks = self.pricer.get_greeks(row['syn_close'], row['atm_strike'], T, sigma, 'put')
            
            # Microstructure
            spread = micro.bid_ask_spread(row['VIX'])
            
            # Simplified regime mapping based on VIX and Momentum
            # 0: Calm, 1: Bull, 2: Bear, 3: Crisis
            regime = 0
            if row['VIX'] > 25: regime = 3
            elif row['FII_Momentum_5D'] > 1000: regime = 1
            elif row['FII_Momentum_5D'] < -1000: regime = 2
            
            state = MarketState(
                timestamp=row['date_dt'],
                day_index=i,
                spot=float(row['syn_close']),
                prev_close=float(row['prev_close']),
                gap_pct=float(row['gap_pct']),
                vix=float(row['VIX']),
                vix_percentile=float(row['vix_percentile']),
                atm_strike=float(row['atm_strike']),
                ce_price=float(row['atm_call_close']),
                pe_price=float(row['atm_put_close']),
                iv_skew=float(row['iv_skew']),
                days_to_expiry=int(row['dte']),
                ce_delta=float(ce_greeks['delta']),
                pe_delta=float(pe_greeks['delta']),
                ce_theta=float(ce_greeks['theta']),
                pe_theta=float(pe_greeks['theta']),
                ce_gamma=float(ce_greeks.get('gamma', 0.0)),
                pe_gamma=float(pe_greeks.get('gamma', 0.0)),
                fii_momentum_5d=float(row['FII_Momentum_5D']),
                fii_net_oi_z=float(row['FII_Net_OI_Z']),
                fii_velocity=float(row['FII_Velocity']), # New feature
                retail_trap_z=float(row['Retail_Trap_Z']),
                bid_ask_spread=float(spread),
                regime=regime,
                ma_50_slope=float(row['ma_50_slope']),
                ma_200_div=float(row['ma_200_div'])
            )
            episode.append(state)
            
        return episode

    def sample_start_idx(self) -> int:
        """Sample a valid starting index for an episode."""
        return np.random.randint(0, len(self.df) - 35)
