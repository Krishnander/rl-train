"""
Ultimate Historical Environment for Training.

Uses nifty_ultimate.parquet with:
- Black-Scholes prices + all Greeks
- Piecewise Delta-Gamma model
- Stress scenarios
- Microstructure signals
- 5-state regime classification
"""

import numpy as np
import pandas as pd
from typing import Tuple, Dict, Any, Optional
from dataclasses import dataclass

@dataclass
class PortfolioState:
    """Track portfolio state."""
    position_type: int  # 0: None, 1: CE, 2: PE
    position_qty: int
    entry_price: float
    entry_day: int
    peak_equity: float
    current_equity: float
    trade_count: int


class UltimateEnv:
    """
    Environment using ultimate enriched dataset.
    
    Observation space: 48 features covering:
    - Market state (spot, VIX, regime)
    - Option prices + Greeks
    - Stress scenario P&Ls
    - Microstructure signals
    - Portfolio state
    """
    
    OBS_FEATURES = 48
    OBS_DIM = 48
    
    def __init__(self, 
                 data_path: str = "nifty_ultimate.parquet",
                 initial_capital: float = 200000.0,
                 episode_length: int = 30,
                 mode: str = 'sequential'):
        
        self.df = pd.read_parquet(data_path)
        self.df = self.df.sort_values('date').reset_index(drop=True)
        self.df = self.df.ffill().fillna(0)
        
        self.initial_capital = initial_capital
        self.episode_length = episode_length
        self.lot_size = 25
        self.mode = mode
        
        self.portfolio = None
        self.current_idx = 0
        self.start_idx = 0
        self.episode_count = 0
        
        print(f"UltimateEnv initialized: {len(self.df)} days, {len(self.df.columns)} columns")
        
    def get_total_episodes(self) -> int:
        return len(self.df) - self.episode_length
    
    def reset(self, start_idx: Optional[int] = None, fixed_regime: Optional[int] = None) -> np.ndarray:
        """Reset for new episode."""
        max_start = len(self.df) - self.episode_length - 1
        
        if start_idx is not None:
            self.start_idx = min(start_idx, max_start)
        elif self.mode == 'sequential':
            self.start_idx = (self.episode_count * 5) % max_start
        else:
            self.start_idx = np.random.randint(0, max_start)
        
        self.current_idx = self.start_idx
        self.episode_count += 1
        
        self.portfolio = PortfolioState(
            position_type=0,
            position_qty=0,
            entry_price=0.0,
            entry_day=0,
            peak_equity=self.initial_capital,
            current_equity=self.initial_capital,
            trade_count=0
        )
        
        self.daily_returns = []
        self.prev_equity = self.initial_capital
        self.prev_action = 0
        self.last_step_pnl = 0.0
        
        return self._get_obs()
    
    def _get_obs(self) -> np.ndarray:
        """
        Construct 48-feature observation using ultimate dataset.
        """
        row = self.df.iloc[self.current_idx]
        
        # === MARKET STATE (8 features) ===
        spot = row['nifty_close']
        spot_norm = (spot / 22000.0) - 1.0
        gap_pct = row.get('nifty_intraday_return', 0) * 10.0
        
        vix = row.get('vix_close', 15)
        vix_norm = vix / 50.0
        vix_percentile = row.get('vix_percentile', 0.5)
        
        rv_iv_spread = row.get('rv_iv_spread', 0) / 10.0
        
        regime = float(row.get('regime_enhanced', 0)) / 4.0
        ma_50_slope = row.get('nifty_ma_50', spot) 
        ma_slope = (spot / ma_50_slope - 1.0) * 10.0 if ma_50_slope > 0 else 0
        ma_200_div = row.get('nifty_price_vs_ma_200', 0) / 10.0
        
        # === OPTION PRICES (6 features) ===
        ce_price = row.get('bs_ce_price', 50) / 300.0
        pe_price = row.get('bs_pe_price', 50) / 300.0
        straddle_price = row.get('bs_straddle_price', 100) / 600.0
        dte = row.get('bs_dte', 4) / 7.0
        iv = row.get('bs_iv', 0.15) * 5.0  # Scale IV
        atm_strike = (row.get('bs_atm_strike', spot) / spot) - 1.0
        
        # === GREEKS (12 features) ===
        ce_delta = row.get('bs_ce_delta', 0.5)
        ce_gamma = row.get('bs_ce_gamma', 0) * 1000.0
        ce_theta = row.get('bs_ce_theta', 0) * 10.0
        ce_vega = row.get('bs_ce_vega', 0) * 10.0
        ce_vanna = row.get('bs_ce_vanna', 0) * 10.0
        ce_charm = row.get('bs_ce_charm', 0) * 100.0
        
        pe_delta = row.get('bs_pe_delta', -0.5)
        pe_gamma = row.get('bs_pe_gamma', 0) * 1000.0
        pe_theta = row.get('bs_pe_theta', 0) * 10.0
        pe_vega = row.get('bs_pe_vega', 0) * 10.0
        
        straddle_delta = row.get('straddle_delta0', 0)
        straddle_gamma = row.get('straddle_gamma0', 0) * 1000.0
        
        # === STRESS SCENARIOS (8 features) ===
        ce_up_5 = row.get('ce_pnl_up_5pct', 0) / 200.0
        ce_down_5 = row.get('ce_pnl_down_5pct', 0) / 200.0
        pe_up_5 = row.get('pe_pnl_up_5pct', 0) / 200.0
        pe_down_5 = row.get('pe_pnl_down_5pct', 0) / 200.0
        
        straddle_up_5 = row.get('straddle_pnl_up_5pct', 0) / 300.0
        straddle_down_5 = row.get('straddle_pnl_down_5pct', 0) / 300.0
        
        vol_crush = row.get('ce_vol_crush', 0) / 100.0
        crisis_scenario = row.get('crisis_gap_down_vol_spike', 0) / 300.0
        
        # === MICROSTRUCTURE (6 features) ===
        spread_bps = row.get('spread_bps', 15) / 50.0
        liquidity = row.get('liquidity_score', 5) / 10.0
        fii_aggression = row.get('fii_aggression', 0)
        dii_fii_ratio = np.clip(row.get('dii_fii_ratio', 0), -2, 2)
        breadth = row.get('breadth_thrust', 0)
        pcr_extreme = row.get('pcr_extreme', 0)
        
        # === MOMENTUM/FLOW (4 features) ===
        fii_net = row.get('fii_net_value_cr', 0) / 5000.0
        rsi = (row.get('nifty_rsi_14', 50) - 50) / 50.0
        macd = row.get('nifty_macd_histogram', 0) / 100.0
        roc_5 = row.get('nifty_roc_5', 0) / 10.0
        
        # === PORTFOLIO STATE (4 features) ===
        pos_type = float(self.portfolio.position_type) / 2.0
        pos_pnl = 0.0
        if self.portfolio.position_qty > 0:
            current_price = row.get('bs_ce_price', 50) if self.portfolio.position_type == 1 else row.get('bs_pe_price', 50)
            pos_pnl = (current_price - self.portfolio.entry_price) / (self.portfolio.entry_price + 1e-6)
        
        prev_action = float(self.prev_action) / 3.0
        last_pnl = self.last_step_pnl * 10.0
        
        obs = np.array([
            # Market State (8)
            spot_norm, gap_pct, vix_norm, vix_percentile,
            rv_iv_spread, regime, ma_slope, ma_200_div,
            # Option Prices (6)
            ce_price, pe_price, straddle_price, dte, iv, atm_strike,
            # Greeks (12)
            ce_delta, ce_gamma, ce_theta, ce_vega, ce_vanna, ce_charm,
            pe_delta, pe_gamma, pe_theta, pe_vega, straddle_delta, straddle_gamma,
            # Stress (8)
            ce_up_5, ce_down_5, pe_up_5, pe_down_5,
            straddle_up_5, straddle_down_5, vol_crush, crisis_scenario,
            # Microstructure (6)
            spread_bps, liquidity, fii_aggression, dii_fii_ratio, breadth, pcr_extreme,
            # Momentum (4)
            fii_net, rsi, macd, roc_5,
            # Portfolio (4)
            pos_type, pos_pnl, prev_action, last_pnl
        ], dtype=np.float32)
        
        return np.clip(obs, -10.0, 10.0)
    
    def step(self, action: int, expected_edge_pct: Optional[float] = None,
             size_multiplier: float = 1.0) -> Tuple[np.ndarray, float, bool, Dict[str, Any]]:
        """Execute action using Black-Scholes prices."""
        row = self.df.iloc[self.current_idx]
        reward = 0.0
        done = False
        
        ce_price = row.get('bs_ce_price', 50)
        pe_price = row.get('bs_pe_price', 50)
        
        # Execute action
        if action == 3 and self.portfolio.position_qty > 0:
            reward = self._close_position(ce_price, pe_price)
        elif action == 1 and self.portfolio.position_type != 1:
            if self.portfolio.position_type == 2:
                reward += self._close_position(ce_price, pe_price)
            reward += self._open_position(ce_price, pos_type=1, size_multiplier=size_multiplier)
        elif action == 2 and self.portfolio.position_type != 2:
            if self.portfolio.position_type == 1:
                reward += self._close_position(ce_price, pe_price)
            reward += self._open_position(pe_price, pos_type=2, size_multiplier=size_multiplier)
        
        # Advance time
        self.current_idx += 1
        steps_in_episode = self.current_idx - self.start_idx
        
        if steps_in_episode >= self.episode_length or self.current_idx >= len(self.df) - 1:
            if self.portfolio.position_qty > 0:
                next_row = self.df.iloc[min(self.current_idx, len(self.df)-1)]
                reward += self._close_position(
                    next_row.get('bs_ce_price', 50), 
                    next_row.get('bs_pe_price', 50)
                )
            done = True
        
        # Track return
        daily_return = (self.portfolio.current_equity - self.prev_equity) / self.prev_equity
        self.daily_returns.append(daily_return)
        self.prev_equity = self.portfolio.current_equity
        
        self.prev_action = action
        self.last_step_pnl = daily_return
        
        obs = self._get_obs() if not done else np.zeros(48, dtype=np.float32)
        info = self._compute_metrics(done)
        
        return obs, reward, done, info
    
    def _open_position(self, price: float, pos_type: int, size_multiplier: float = 1.0) -> float:
        """Open position."""
        qty = int(2 * self.lot_size * size_multiplier)
        
        # Realistic slippage (0.1%)
        exec_price = price * 1.001
        fees = qty * 20
        
        self.portfolio.position_type = pos_type
        self.portfolio.position_qty = qty
        self.portfolio.entry_price = exec_price
        self.portfolio.entry_day = self.current_idx - self.start_idx
        self.portfolio.trade_count += 1
        self.portfolio.current_equity -= fees
        
        return -fees / self.initial_capital
    
    def _close_position(self, ce_price: float, pe_price: float) -> float:
        """Close position."""
        price = ce_price if self.portfolio.position_type == 1 else pe_price
        qty = self.portfolio.position_qty
        
        exec_price = price * 0.999
        fees = qty * 20
        
        gross_pnl = (exec_price - self.portfolio.entry_price) * qty
        net_pnl = gross_pnl - fees
        
        self.portfolio.current_equity += net_pnl
        self.portfolio.peak_equity = max(self.portfolio.peak_equity, self.portfolio.current_equity)
        
        self.portfolio.position_type = 0
        self.portfolio.position_qty = 0
        self.portfolio.entry_price = 0.0
        
        return net_pnl / self.initial_capital
    
    def _compute_metrics(self, done: bool) -> Dict[str, Any]:
        """Compute episode metrics."""
        pnl = self.portfolio.current_equity - self.initial_capital
        max_dd = (self.portfolio.peak_equity - self.portfolio.current_equity) / self.portfolio.peak_equity
        
        if len(self.daily_returns) > 1:
            returns = np.array(self.daily_returns)
            sharpe = np.mean(returns) / (np.std(returns) + 1e-8) * np.sqrt(252)
        else:
            sharpe = 0.0
        
        row = self.df.iloc[min(self.current_idx, len(self.df)-1)]
        
        return {
            'capital': self.portfolio.current_equity,
            'roi': pnl / self.initial_capital,
            'max_drawdown': max_dd,
            'sharpe': sharpe,
            'trade_count': self.portfolio.trade_count,
            'survival_pct': (self.current_idx - self.start_idx) / self.episode_length,
            'regime': int(row.get('regime_enhanced', 0)),
            'date': str(row['date']),
            'done': done
        }
