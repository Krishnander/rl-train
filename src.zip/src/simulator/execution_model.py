"""
Almgren-Chriss Execution Model.

Implements realistic execution simulation with:
- Temporary price impact (reverts)
- Permanent price impact (persists)
- Slippage = f(urgency, size, volatility)
- Queue position model

Based on:
- Almgren & Chriss (2000): "Optimal Execution of Portfolio Transactions"
- Gatheral & Schied (2011): "Optimal Trade Execution under GBM"
"""

import numpy as np
from typing import Tuple, Dict
from dataclasses import dataclass

@dataclass
class ExecutionResult:
    """Result of executing a trade."""
    executed_price: float  # Price after all impacts
    mid_price: float       # Price before impacts
    temporary_impact: float  # Temporary slippage (reverts)
    permanent_impact: float  # Permanent impact (shifts mid)
    spread_cost: float       # Bid-ask spread cost
    total_cost_bps: float    # Total cost in basis points
    fill_ratio: float        # 0-1, how much was filled


class AlmgrenChrissModel:
    """
    Almgren-Chriss execution model.
    
    Temporary Impact: g(v) = γ * σ * (v/V)^0.5
    Permanent Impact: h(v) = η * (v/V)
    
    Where:
    - v = trade size
    - V = average daily volume (ADV)
    - σ = daily volatility
    - γ, η = market-specific constants
    """
    
    # Calibrated parameters (typical equity/options markets)
    GAMMA = 0.1     # Temporary impact coefficient
    ETA = 0.01      # Permanent impact coefficient
    THETA = 0.5     # Impact exponent (square root)
    
    # Spread parameters
    BASE_SPREAD_BPS = 5.0      # Base bid-ask spread in bps
    VIX_SPREAD_COEF = 0.3      # Additional spread per VIX point
    SIZE_SPREAD_COEF = 1.0     # Additional spread for large orders
    
    def __init__(self, 
                 gamma: float = None,
                 eta: float = None,
                 theta: float = None):
        """
        Initialize model with custom parameters.
        
        Args:
            gamma: Temporary impact coefficient
            eta: Permanent impact coefficient
            theta: Impact exponent
        """
        self.gamma = gamma or self.GAMMA
        self.eta = eta or self.ETA
        self.theta = theta or self.THETA
    
    def temporary_impact(self, 
                          trade_size: float, 
                          adv: float, 
                          volatility: float) -> float:
        """
        Calculate temporary price impact.
        
        This impact reverts after the trade (market maker adjustment).
        
        g(v) = γ * σ * (v/V)^θ
        
        Args:
            trade_size: Number of shares/contracts
            adv: Average daily volume
            volatility: Daily volatility (e.g., 0.02 for 2%)
            
        Returns:
            Temporary impact as price fraction
        """
        if adv <= 0:
            return 0.0
        
        participation = trade_size / adv
        return self.gamma * volatility * (participation ** self.theta)
    
    def permanent_impact(self, 
                          trade_size: float, 
                          adv: float) -> float:
        """
        Calculate permanent price impact.
        
        This impact persists - it shifts the mid price.
        
        h(v) = η * (v/V)
        
        Args:
            trade_size: Number of shares/contracts
            adv: Average daily volume
            
        Returns:
            Permanent impact as price fraction
        """
        if adv <= 0:
            return 0.0
        
        participation = trade_size / adv
        return self.eta * participation
    
    def bid_ask_spread(self, 
                        vix: float, 
                        trade_size: float, 
                        adv: float,
                        is_option: bool = True) -> float:
        """
        Calculate bid-ask spread in basis points.
        
        Spread widens with:
        - Higher VIX (volatility)
        - Larger trade size (information)
        - Less liquidity
        
        Args:
            vix: VIX level
            trade_size: Trade size
            adv: Average daily volume
            is_option: Options have wider spreads
            
        Returns:
            Spread in basis points
        """
        # Base spread
        spread = self.BASE_SPREAD_BPS
        
        # VIX component
        spread += self.VIX_SPREAD_COEF * max(0, vix - 15)
        
        # Size component
        if adv > 0:
            participation = trade_size / adv
            spread += self.SIZE_SPREAD_COEF * participation * 100
        
        # Options have wider spreads
        if is_option:
            spread *= 1.5
        
        return spread
    
    def execute_order(self,
                       mid_price: float,
                       trade_size: float,
                       is_buy: bool,
                       adv: float,
                       volatility: float,
                       vix: float,
                       urgency: float = 0.5,
                       is_option: bool = True) -> ExecutionResult:
        """
        Execute an order with full impact modeling.
        
        Args:
            mid_price: Current mid price
            trade_size: Number of contracts to trade
            is_buy: True if buying, False if selling
            adv: Average daily volume
            volatility: Daily volatility
            vix: VIX level
            urgency: 0-1, how urgent (1 = market order, 0 = passive limit)
            is_option: True if trading options
            
        Returns:
            ExecutionResult with all impact details
        """
        # Direction
        direction = 1 if is_buy else -1
        
        # Calculate impacts
        temp_impact = self.temporary_impact(trade_size, adv, volatility)
        perm_impact = self.permanent_impact(trade_size, adv)
        
        # Spread (pay half on entry)
        spread_bps = self.bid_ask_spread(vix, trade_size, adv, is_option)
        spread_cost = spread_bps / 10000 / 2  # Half spread on one side
        
        # Urgency scaling (more urgent = more impact)
        urgency_multiplier = 0.5 + urgency  # 0.5 to 1.5
        
        # Total execution cost
        total_impact = (temp_impact + perm_impact + spread_cost) * urgency_multiplier
        
        # Executed price
        if is_buy:
            executed_price = mid_price * (1 + total_impact)
        else:
            executed_price = mid_price * (1 - total_impact)
        
        # Fill ratio (assume 100% for simplicity)
        fill_ratio = 1.0
        
        # Total cost in bps
        total_cost_bps = abs(executed_price - mid_price) / mid_price * 10000
        
        return ExecutionResult(
            executed_price=executed_price,
            mid_price=mid_price,
            temporary_impact=temp_impact,
            permanent_impact=perm_impact,
            spread_cost=spread_cost,
            total_cost_bps=total_cost_bps,
            fill_ratio=fill_ratio
        )


class OrderBookPressure:
    """
    Simplified order book pressure model.
    
    Without full LOB data, we estimate order imbalance from:
    - Advance/decline ratio
    - Volume ratio (up volume vs down volume)
    - FII flow direction
    """
    
    def __init__(self):
        pass
    
    def estimate_imbalance(self, 
                            adv_dec_ratio: float,
                            volume_ratio: float = 1.0,
                            fii_direction: float = 0.0) -> float:
        """
        Estimate order book imbalance from proxy signals.
        
        Returns: imbalance in range [-1, 1]
                 -1 = heavy selling pressure
                 +1 = heavy buying pressure
        """
        # Advance/Decline contribution
        ad_signal = np.clip((adv_dec_ratio - 1) * 2, -1, 1)
        
        # Volume ratio (up/down)
        vol_signal = np.clip((volume_ratio - 1) * 0.5, -1, 1)
        
        # FII flow
        fii_signal = np.clip(fii_direction, -1, 1)
        
        # Weighted combination
        imbalance = 0.4 * ad_signal + 0.3 * vol_signal + 0.3 * fii_signal
        
        return np.clip(imbalance, -1, 1)
    
    def imbalance_to_price_pressure(self, imbalance: float, volatility: float) -> float:
        """
        Convert order imbalance to expected price pressure.
        
        Returns: Expected short-term return from imbalance
        """
        # Imbalance predicts short-term returns
        # Coefficient from empirical studies
        return 0.1 * imbalance * volatility


class QueuePositionModel:
    """
    Model queue position for limit orders.
    
    Tracks estimated position in the queue and probability of execution.
    """
    
    def __init__(self, queue_decay_rate: float = 0.1):
        """
        Args:
            queue_decay_rate: Rate at which queue position improves (per bar)
        """
        self.queue_decay_rate = queue_decay_rate
    
    def initial_queue_position(self, 
                                 spread_bps: float, 
                                 order_size: float,
                                 adv: float) -> float:
        """
        Estimate initial queue position (0 = front, 1 = back).
        """
        # Wider spreads = larger queues
        spread_factor = min(spread_bps / 20, 1.0)
        
        # Larger orders go to back of queue
        size_factor = min(order_size / (adv * 0.01), 1.0) if adv > 0 else 0.5
        
        return 0.3 + 0.4 * spread_factor + 0.3 * size_factor
    
    def update_queue_position(self, 
                                current_position: float, 
                                bars_elapsed: int,
                                price_moved_favorable: bool) -> float:
        """
        Update queue position as time passes.
        """
        # Natural queue decay
        decay = self.queue_decay_rate * bars_elapsed
        
        # Favorable price movement helps
        if price_moved_favorable:
            decay *= 1.5
        
        new_position = max(0, current_position - decay)
        return new_position
    
    def execution_probability(self, queue_position: float) -> float:
        """
        Probability of execution given queue position.
        """
        # Front of queue = high probability
        # Back of queue = low probability
        return 1.0 - queue_position


if __name__ == "__main__":
    # Test execution model
    model = AlmgrenChrissModel()
    
    # Example: Execute 100 contracts of Nifty option
    result = model.execute_order(
        mid_price=150.0,
        trade_size=100,
        is_buy=True,
        adv=50000,  # ADV of 50k contracts
        volatility=0.02,
        vix=18,
        urgency=0.7
    )
    
    print("Execution Result:")
    print(f"  Mid Price: {result.mid_price:.2f}")
    print(f"  Executed Price: {result.executed_price:.2f}")
    print(f"  Temporary Impact: {result.temporary_impact*10000:.2f} bps")
    print(f"  Permanent Impact: {result.permanent_impact*10000:.2f} bps")
    print(f"  Spread Cost: {result.spread_cost*10000:.2f} bps")
    print(f"  Total Cost: {result.total_cost_bps:.2f} bps")
