import pandas as pd
from pathlib import Path

class DataLoader:
    """
    Loads historical Nifty data for RL research.
    """
    
    def __init__(self, data_path: str):
        self.data_path = Path(data_path)
        
    def load_master_store(self) -> pd.DataFrame:
        """
        Loads the fixed master feature store.
        """
        if not self.data_path.exists():
            raise FileNotFoundError(f"Data not found at {self.data_path}")
            
        print(f"Loading data from {self.data_path}...")
        df = pd.read_parquet(self.data_path)
        print(f"Loaded {len(df)} rows.")
        return df

    def get_summary_stats(self, df: pd.DataFrame):
        """
        Prints key statistics of the dataset.
        """
        print("\n=== Dataset Summary ===")
        print(f"Columns: {list(df.columns)}")
        print(df[['VIX', 'FII_Momentum_5D', 'Retail_Trap_Z']].describe())
        print("======================\n")
