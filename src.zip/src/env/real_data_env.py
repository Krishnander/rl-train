"""
Real Data Environment for Backtesting.

Replays actual historical Nifty data from parquet file instead of synthetic simulation.
Maps 134 columns to the 24-feature observation space expected by the agent.
"""

import numpy as np
import pandas as pd
from typing import Tuple, Dict, Any, Optional
from dataclasses import dataclass

@dataclass
class PortfolioState:
    """Track portfolio state for observation."""
    position_type: int  # 0: None, 1: CE, 2: PE
    position_qty: int
    entry_price: float
    entry_day: int
    peak_equity: float
    current_equity: float
    trade_count: int


class RealDataEnv:
    """
    Environment that replays REAL historical Nifty data.
    
    Uses nifty_complete_dataset.parquet (2007-2026, 4496 trading days).
    Maps available columns to 24-feature observation space.
    """
    
    OBS_FEATURES = 24
    OBS_DIM = 24
    
    def __init__(self, 
                 data_path: str = "nifty_complete_dataset.parquet",
                 initial_capital: float = 200000.0,
                 episode_length: int = 30):
        
        self.df = pd.read_parquet(data_path)
        self.df = self.df.sort_values('date').reset_index(drop=True)
        
        # Fill NaN values
        self.df = self.df.fillna(method='ffill').fillna(0)
        
        self.initial_capital = initial_capital
        self.episode_length = episode_length
        self.lot_size = 65
        
        # Precompute some derived features
        self._precompute_features()
        
        self.portfolio = None
        self.current_idx = 0
        self.start_idx = 0
        
    def _precompute_features(self):
        """Derive features that don't exist in raw data."""
        # FII Velocity (5-day ROC of FII net)
        self.df['fii_velocity'] = self.df['fii_net_value_cr'].pct_change(5).fillna(0)
        
        # VIX Percentile (rolling 252-day)
        self.df['vix_percentile'] = self.df['vix_close'].rolling(252).apply(
            lambda x: (x.iloc[-1] <= x).mean() if len(x) > 20 else 0.5
        ).fillna(0.5)
        
        # MA 50 Slope (normalized)
        self.df['ma_50_slope'] = self.df['nifty_ma_50'].pct_change(5).fillna(0)
        
        # MA 200 Divergence
        self.df['ma_200_div'] = (self.df['nifty_close'] / self.df['nifty_ma_200'] - 1).fillna(0)
        
        # Regime Classification (based on VIX and trend)
        def classify_regime(row):
            vix = row['vix_close'] if pd.notna(row['vix_close']) else 15
            ret = row['nifty_daily_return'] if pd.notna(row['nifty_daily_return']) else 0
            
            if vix > 30:
                return 3  # Crisis
            elif vix > 22:
                return 2  # Bear
            elif ret > 0.005:
                return 1  # Bull
            else:
                return 0  # Calm
        
        self.df['regime'] = self.df.apply(classify_regime, axis=1)
        
        # Synthetic option prices (approximation for backtest)
        # CE/PE premium ~ ATR * 0.5 (rough approximation)
        self.df['ce_price_approx'] = self.df['nifty_atr_14'] * 0.5
        self.df['pe_price_approx'] = self.df['nifty_atr_14'] * 0.5
        
    def get_total_episodes(self) -> int:
        """Total available episode windows."""
        return len(self.df) - self.episode_length
    
    def reset(self, start_idx: Optional[int] = None, fixed_regime: Optional[int] = None) -> np.ndarray:
        """Reset to a new episode window."""
        max_start = len(self.df) - self.episode_length - 1
        
        if start_idx is not None:
            self.start_idx = min(start_idx, max_start)
        else:
            # Random start for training diversity
            self.start_idx = np.random.randint(0, max_start)
        
        self.current_idx = self.start_idx
        
        # Portfolio state
        self.portfolio = PortfolioState(
            position_type=0,
            position_qty=0,
            entry_price=0.0,
            entry_day=0,
            peak_equity=self.initial_capital,
            current_equity=self.initial_capital,
            trade_count=0
        )
        
        self.daily_returns = []
        self.prev_equity = self.initial_capital
        self.prev_action = 0
        self.last_step_pnl = 0.0
        
        return self._get_obs()
    
    def _get_obs(self) -> np.ndarray:
        """
        Map real data columns to 24-feature observation vector.
        """
        row = self.df.iloc[self.current_idx]
        
        # Normalize spot
        spot_norm = (row['nifty_close'] / 22000.0) - 1.0
        
        # Gap (intraday return as proxy)
        gap_pct = row['nifty_intraday_return'] * 10.0 if pd.notna(row['nifty_intraday_return']) else 0
        
        # VIX
        vix = row['vix_close'] if pd.notna(row['vix_close']) else 15
        vix_norm = vix / 50.0
        vix_percentile = row['vix_percentile']
        
        # Option prices (approximated)
        ce_price = row['ce_price_approx'] / 300.0 if pd.notna(row['ce_price_approx']) else 0.3
        pe_price = row['pe_price_approx'] / 300.0 if pd.notna(row['pe_price_approx']) else 0.3
        
        # IV Skew (use PCR as proxy - high PCR = fear = positive skew)
        pcr = row['pcr_nifty'] if pd.notna(row['pcr_nifty']) else 1.0
        iv_skew = (pcr - 1.0) * 5.0  # Centered around 1.0
        
        # DTE (constant for daily data - assume weekly options)
        dte = 0.5
        
        # Deltas (approximation based on moneyness)
        ce_delta = 0.5
        pe_delta = 0.5
        
        # Thetas (normalized ATR impact)
        theta_norm = -row['nifty_atr_percent_14'] / 100.0 if pd.notna(row['nifty_atr_percent_14']) else -0.01
        
        # FII Signals
        fii_mom = row['fii_net_value_cr'] / 5000.0 if pd.notna(row['fii_net_value_cr']) else 0
        fii_velocity = row['fii_velocity'] * 10.0 if pd.notna(row['fii_velocity']) else 0
        
        # Net OI Z-score (use advance/decline as proxy)
        adv_dec = row['adv_dec_ratio'] if pd.notna(row['adv_dec_ratio']) else 1.0
        fii_oi_z = (adv_dec - 1.0) / 0.5  # Normalize around 1.0
        
        # Retail Trap (inverted PCR logic)
        retail_trap = -(pcr - 1.0) * 2.0
        
        # Global signals
        sp500_ret = row.get('sp500_close', 0)
        global_nasdaq = 0.0  # No Nasdaq in data
        
        usdinr = row['usdinr_close'] if pd.notna(row['usdinr_close']) else 83
        global_usdinr = (usdinr - 83) / 5.0  # Normalize around 83
        
        # Trend features
        ma_50_slope = row['ma_50_slope'] * 20.0 if pd.notna(row['ma_50_slope']) else 0
        ma_200_div = row['ma_200_div'] * 10.0 if pd.notna(row['ma_200_div']) else 0
        
        # Regime
        regime = float(row['regime']) / 4.0
        
        # Portfolio state
        pos_type = float(self.portfolio.position_type) / 2.0
        prev_action = float(self.prev_action) / 3.0
        last_pnl = self.last_step_pnl * 10.0
        
        obs = np.array([
            spot_norm,           # 0: Spot
            gap_pct,             # 1: Gap
            vix_norm,            # 2: VIX
            vix_percentile,      # 3: VIX Percentile
            ce_price,            # 4: CE Price
            pe_price,            # 5: PE Price
            iv_skew,             # 6: IV Skew
            dte,                 # 7: DTE
            ce_delta,            # 8: CE Delta
            pe_delta,            # 9: PE Delta
            theta_norm,          # 10: CE Theta
            theta_norm,          # 11: PE Theta
            fii_mom,             # 12: FII Momentum
            fii_oi_z,            # 13: FII OI Z
            fii_velocity,        # 14: FII Velocity
            retail_trap,         # 15: Retail Trap
            global_nasdaq,       # 16: Global Nasdaq
            global_usdinr,       # 17: Global USDINR
            ma_50_slope,         # 18: MA50 Slope
            ma_200_div,          # 19: MA200 Div
            regime,              # 20: Regime
            pos_type,            # 21: Position Type
            prev_action,         # 22: Prev Action
            last_pnl             # 23: Last PnL
        ], dtype=np.float32)
        
        return obs
    
    def step(self, action: int, expected_edge_pct: Optional[float] = None, 
             size_multiplier: float = 1.0) -> Tuple[np.ndarray, float, bool, Dict[str, Any]]:
        """
        Execute action on real data.
        """
        row = self.df.iloc[self.current_idx]
        reward = 0.0
        done = False
        
        # Approximate option prices
        ce_price = row['ce_price_approx'] if pd.notna(row['ce_price_approx']) else 100
        pe_price = row['pe_price_approx'] if pd.notna(row['pe_price_approx']) else 100
        
        # Execute action
        if action == 3 and self.portfolio.position_qty > 0:
            reward = self._close_position(ce_price, pe_price)
        elif action == 1 and self.portfolio.position_type != 1:
            if self.portfolio.position_type == 2:
                reward += self._close_position(ce_price, pe_price)
            reward += self._open_position(ce_price, pos_type=1, size_multiplier=size_multiplier)
        elif action == 2 and self.portfolio.position_type != 2:
            if self.portfolio.position_type == 1:
                reward += self._close_position(ce_price, pe_price)
            reward += self._open_position(pe_price, pos_type=2, size_multiplier=size_multiplier)
        
        # Advance time
        self.current_idx += 1
        steps_in_episode = self.current_idx - self.start_idx
        
        if steps_in_episode >= self.episode_length or self.current_idx >= len(self.df) - 1:
            if self.portfolio.position_qty > 0:
                next_row = self.df.iloc[self.current_idx]
                reward += self._close_position(
                    next_row['ce_price_approx'], 
                    next_row['pe_price_approx']
                )
            done = True
        
        # Track daily return
        daily_return = (self.portfolio.current_equity - self.prev_equity) / self.prev_equity
        self.daily_returns.append(daily_return)
        self.prev_equity = self.portfolio.current_equity
        
        # Update feedback state
        self.prev_action = action
        self.last_step_pnl = daily_return
        
        obs = self._get_obs() if not done else np.zeros(24, dtype=np.float32)
        info = self._compute_metrics(done)
        
        return obs, reward, done, info
    
    def _open_position(self, price: float, pos_type: int, size_multiplier: float = 1.0) -> float:
        """Open position."""
        qty = int(2 * self.lot_size * size_multiplier)
        
        # Simple slippage model
        exec_price = price * 1.002  # 0.2% slippage
        fees = exec_price * qty * 0.001  # 0.1% fees
        
        self.portfolio.position_type = pos_type
        self.portfolio.position_qty = qty
        self.portfolio.entry_price = exec_price
        self.portfolio.entry_day = self.current_idx - self.start_idx
        self.portfolio.trade_count += 1
        self.portfolio.current_equity -= fees
        
        return -fees / self.initial_capital
    
    def _close_position(self, ce_price: float, pe_price: float) -> float:
        """Close position."""
        price = ce_price if self.portfolio.position_type == 1 else pe_price
        qty = self.portfolio.position_qty
        
        exec_price = price * 0.998  # 0.2% slippage on sell
        fees = exec_price * qty * 0.001
        
        gross_pnl = (exec_price - self.portfolio.entry_price) * qty
        net_pnl = gross_pnl - fees
        
        self.portfolio.current_equity += net_pnl
        self.portfolio.peak_equity = max(self.portfolio.peak_equity, self.portfolio.current_equity)
        
        self.portfolio.position_type = 0
        self.portfolio.position_qty = 0
        self.portfolio.entry_price = 0.0
        
        return net_pnl / self.initial_capital
    
    def _compute_metrics(self, done: bool) -> Dict[str, Any]:
        """Compute episode metrics."""
        pnl = self.portfolio.current_equity - self.initial_capital
        max_dd = (self.portfolio.peak_equity - self.portfolio.current_equity) / self.portfolio.peak_equity
        
        if len(self.daily_returns) > 1:
            returns = np.array(self.daily_returns)
            sharpe = np.mean(returns) / (np.std(returns) + 1e-8) * np.sqrt(252)
        else:
            sharpe = 0.0
        
        row = self.df.iloc[min(self.current_idx, len(self.df)-1)]
        
        return {
            'capital': self.portfolio.current_equity,
            'roi': pnl / self.initial_capital,
            'max_drawdown': max_dd,
            'sharpe': sharpe,
            'trade_count': self.portfolio.trade_count,
            'survival_pct': (self.current_idx - self.start_idx) / self.episode_length,
            'regime': int(row['regime']),
            'date': str(row['date']),
            'done': done
        }
