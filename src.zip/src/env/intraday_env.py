"""
Intraday Trading Environment.

Steps through minute bars with:
- Realistic intraday price dynamics
- Almgren-Chriss execution model
- Intraday theta decay and gamma scalping
- Official 2026 Indian F&O costs (SEBI/NSE)
"""

import numpy as np
import pandas as pd
from typing import Tuple, Dict, Any, Optional, List
from dataclasses import dataclass

import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

from simulator.intraday_generator import IntradayGenerator, IntradayBar, OptionIntradayModel
from simulator.execution_model import AlmgrenChrissModel, OrderBookPressure
from simulator.india_fo_costs import IndiaFOCostCalculator


@dataclass
class IntradayPortfolioState:
    """Track portfolio state for intraday trading."""
    position_type: int  # 0: None, 1: CE, 2: PE
    position_qty: int
    entry_price: float
    entry_minute: int
    entry_day: int
    peak_equity: float
    current_equity: float
    trade_count: int
    pending_order: Optional[Dict] = None


class IntradayEnv:
    """
    Intraday trading environment.
    
    Steps through minute bars (375 per day) with:
    - Realistic price dynamics (GARCH + diurnal pattern)
    - Execution simulation (Almgren-Chriss)
    - Intraday option dynamics (theta decay, gamma scalping)
    
    Observation space: 56 features
    Action space: 4 (HOLD, BUY_CE, BUY_PE, EXIT)
    """
    
    MINUTES_PER_DAY = 375
    OBS_DIM = 56
    OBS_FEATURES = 56
    
    def __init__(self,
                 data_path: str = "nifty_ultimate.parquet",
                 initial_capital: float = 200000.0,
                 episode_days: int = 5,
                 decision_interval: int = 15,  # Decide every 15 minutes
                 mode: str = 'sequential'):
        """
        Args:
            data_path: Path to enriched parquet
            initial_capital: Starting capital
            episode_days: Days per episode
            decision_interval: Minutes between decisions
            mode: 'sequential' or 'random'
        """
        self.df = pd.read_parquet(data_path)
        self.df = self.df.sort_values('date').reset_index(drop=True)
        self.df = self.df.ffill().fillna(0)
        
        self.initial_capital = initial_capital
        self.episode_days = episode_days
        self.decision_interval = decision_interval
        self.mode = mode
        
        # Components
        self.intraday_gen = IntradayGenerator()
        self.execution_model = AlmgrenChrissModel()
        self.option_model = OptionIntradayModel()
        self.order_book = OrderBookPressure()
        
        # State
        self.portfolio = None
        self.current_day = 0
        self.current_minute = 0
        self.start_day_idx = 0
        self.episode_count = 0
        
        # Intraday data
        self.intraday_bars: List[List[IntradayBar]] = []
        self.daily_data: List[pd.Series] = []
        
        print(f"IntradayEnv initialized: {len(self.df)} days, {self.MINUTES_PER_DAY} bars/day")
    
    def get_total_episodes(self) -> int:
        return len(self.df) - self.episode_days - 10
    
    def reset(self, start_idx: Optional[int] = None) -> np.ndarray:
        """Reset for new episode."""
        max_start = len(self.df) - self.episode_days - 5
        
        if start_idx is not None:
            self.start_day_idx = min(start_idx, max_start)
        elif self.mode == 'sequential':
            self.start_day_idx = (self.episode_count * 3) % max_start
        else:
            self.start_day_idx = np.random.randint(0, max_start)
        
        self.episode_count += 1
        
        # Generate intraday bars for this episode
        self._generate_episode_bars()
        
        # Reset state
        self.current_day = 0
        self.current_minute = 0
        
        self.portfolio = IntradayPortfolioState(
            position_type=0,
            position_qty=0,
            entry_price=0.0,
            entry_minute=0,
            entry_day=0,
            peak_equity=self.initial_capital,
            current_equity=self.initial_capital,
            trade_count=0
        )
        
        self.minute_returns = []
        self.prev_equity = self.initial_capital
        self.prev_action = 0
        self.last_pnl = 0.0
        
        return self._get_obs()
    
    def _generate_episode_bars(self):
        """Generate intraday bars for the episode."""
        self.intraday_bars = []
        self.daily_data = []
        
        for d in range(self.episode_days):
            day_idx = self.start_day_idx + d
            if day_idx >= len(self.df):
                break
            
            row = self.df.iloc[day_idx]
            self.daily_data.append(row)
            
            bars = self.intraday_gen.generate_intraday_bars(
                daily_open=row['nifty_open'],
                daily_high=row['nifty_high'],
                daily_low=row['nifty_low'],
                daily_close=row['nifty_close'],
                daily_volume=row.get('nifty_volume', 1e8),
                vix=row.get('vix_close', 15),
                date_str=str(row.get('date', d))
            )
            
            self.intraday_bars.append(bars)
    
    def _get_current_bar(self) -> IntradayBar:
        """Get current minute bar."""
        if self.current_day < len(self.intraday_bars):
            bars = self.intraday_bars[self.current_day]
            if self.current_minute < len(bars):
                return bars[self.current_minute]
        # Return a dummy bar if out of bounds
        return IntradayBar(0, 0, 0, 0, 0, 0, 0, 0, 0)
    
    def _get_daily_row(self) -> pd.Series:
        """Get current day's daily data."""
        if self.current_day < len(self.daily_data):
            return self.daily_data[self.current_day]
        return self.daily_data[-1] if self.daily_data else pd.Series()
    
    def _get_obs(self) -> np.ndarray:
        """
        Construct 56-feature observation.
        
        Categories:
        - Intraday State (12)
        - Daily Context (12)
        - Option State (10)
        - Execution State (8)
        - Portfolio State (8)
        - Temporal (6)
        """
        bar = self._get_current_bar()
        row = self._get_daily_row()
        
        # === INTRADAY STATE (12) ===
        spot = bar.close if bar.close > 0 else row.get('nifty_close', 22000)
        spot_norm = (spot / 22000.0) - 1.0
        
        intraday_return = (bar.close - bar.open) / (bar.open + 1e-6) if bar.open > 0 else 0
        bar_volatility = bar.volatility * 100 if bar.volatility else 0.01
        vwap_distance = (bar.close - bar.vwap) / (bar.vwap + 1e-6) if bar.vwap > 0 else 0
        volume_ratio = bar.volume / (row.get('nifty_volume', 1e8) / self.MINUTES_PER_DAY + 1e-6)
        
        # Day progress
        day_progress = self.current_minute / self.MINUTES_PER_DAY
        
        # Trend within day
        if self.current_minute > 0 and self.current_day < len(self.intraday_bars):
            bars_today = self.intraday_bars[self.current_day][:self.current_minute+1]
            open_price = bars_today[0].open if bars_today else spot
            intraday_trend = (spot - open_price) / (open_price + 1e-6)
        else:
            intraday_trend = 0
        
        # High/Low distance
        if self.current_day < len(self.intraday_bars):
            bars_today = self.intraday_bars[self.current_day][:self.current_minute+1]
            day_high = max(b.high for b in bars_today) if bars_today else spot
            day_low = min(b.low for b in bars_today) if bars_today else spot
            high_distance = (day_high - spot) / (spot + 1e-6)
            low_distance = (spot - day_low) / (spot + 1e-6)
        else:
            high_distance = 0
            low_distance = 0
        
        # Momentum (last 15 minutes)
        if self.current_minute >= 15 and self.current_day < len(self.intraday_bars):
            bars_back = self.intraday_bars[self.current_day][self.current_minute-15:self.current_minute+1]
            if len(bars_back) > 1:
                short_momentum = (bars_back[-1].close - bars_back[0].open) / (bars_back[0].open + 1e-6)
            else:
                short_momentum = 0
        else:
            short_momentum = 0
        
        # === DAILY CONTEXT (12) ===
        vix = row.get('vix_close', 15)
        vix_norm = vix / 50.0
        vix_percentile = row.get('vix_percentile', 0.5)
        
        daily_range = (row.get('nifty_high', spot) - row.get('nifty_low', spot)) / (spot + 1e-6)
        gap_pct = row.get('nifty_intraday_return', 0) * 10.0
        
        fii_net = row.get('fii_net_value_cr', 0) / 5000.0
        fii_aggression = row.get('fii_aggression', 0)
        
        regime = float(row.get('regime_enhanced', 0)) / 4.0
        rsi = (row.get('nifty_rsi_14', 50) - 50) / 50.0
        
        pcr = row.get('pcr_nifty', 1.0)
        pcr_signal = (pcr - 1.0) * 2.0
        
        breadth = row.get('breadth_thrust', 0)
        liquidity = row.get('liquidity_score', 5) / 10.0
        
        # === OPTION STATE (10) ===
        ce_price = row.get('bs_ce_price', 100) / 300.0
        pe_price = row.get('bs_pe_price', 100) / 300.0
        
        ce_delta = row.get('bs_ce_delta', 0.5)
        ce_gamma = row.get('bs_ce_gamma', 0) * 1000.0
        ce_theta = row.get('bs_ce_theta', 0) * 10.0
        ce_vega = row.get('bs_ce_vega', 0) * 10.0
        
        pe_delta = row.get('bs_pe_delta', -0.5)
        
        dte = row.get('bs_dte', 4) / 7.0
        iv = row.get('bs_iv', 0.15) * 5.0
        
        # Intraday theta decay
        theta_decay_pct = self.option_model.intraday_theta_decay(
            dte=row.get('bs_dte', 4),
            minute=self.current_minute
        )
        
        # === EXECUTION STATE (8) ===
        spread_bps = row.get('spread_bps', 15) / 50.0
        
        # Order book imbalance
        imbalance = self.order_book.estimate_imbalance(
            adv_dec_ratio=row.get('adv_dec_ratio', 1.0),
            fii_direction=fii_aggression
        )
        
        # Temporary variables for execution cost estimates
        vol_daily = vix / 100.0
        adv = row.get('nifty_volume', 1e8)
        temp_impact = self.execution_model.temporary_impact(100, adv, vol_daily)
        perm_impact = self.execution_model.permanent_impact(100, adv)
        
        expected_slippage = (temp_impact + perm_impact) * 10000
        
        # Time urgency (higher near close)
        time_urgency = 0
        if day_progress > 0.9:  # Last 10% of day
            time_urgency = (day_progress - 0.9) / 0.1
        
        # === PORTFOLIO STATE (8) ===
        pos_type = float(self.portfolio.position_type) / 2.0
        
        pos_pnl = 0.0
        if self.portfolio.position_qty > 0:
            current_opt_price = row.get('bs_ce_price', 100) if self.portfolio.position_type == 1 else row.get('bs_pe_price', 100)
            pos_pnl = (current_opt_price - self.portfolio.entry_price) / (self.portfolio.entry_price + 1e-6)
        
        minutes_in_trade = 0
        if self.portfolio.position_type > 0:
            minutes_in_trade = (
                (self.current_day - self.portfolio.entry_day) * self.MINUTES_PER_DAY +
                (self.current_minute - self.portfolio.entry_minute)
            )
        
        minutes_in_trade_norm = min(minutes_in_trade, 500) / 500.0
        
        equity_ratio = self.portfolio.current_equity / self.initial_capital
        drawdown = (self.portfolio.peak_equity - self.portfolio.current_equity) / (self.portfolio.peak_equity + 1e-6)
        
        prev_action = float(self.prev_action) / 3.0
        last_pnl = self.last_pnl * 10.0
        trade_count = min(self.portfolio.trade_count, 20) / 20.0
        
        # === TEMPORAL (6) ===
        minute_sin = np.sin(2 * np.pi * self.current_minute / self.MINUTES_PER_DAY)
        minute_cos = np.cos(2 * np.pi * self.current_minute / self.MINUTES_PER_DAY)
        
        day_of_week = 0  # Would need date parsing
        
        is_opening = 1.0 if self.current_minute < 15 else 0.0
        is_closing = 1.0 if self.current_minute > 360 else 0.0
        is_lunch = 1.0 if 150 < self.current_minute < 210 else 0.0
        
        obs = np.array([
            # Intraday State (12)
            spot_norm, intraday_return, bar_volatility, vwap_distance,
            volume_ratio, day_progress, intraday_trend, high_distance,
            low_distance, short_momentum, 0, 0,  # padding
            
            # Daily Context (12)
            vix_norm, vix_percentile, daily_range, gap_pct,
            fii_net, fii_aggression, regime, rsi,
            pcr_signal, breadth, liquidity, 0,  # padding
            
            # Option State (10)
            ce_price, pe_price, ce_delta, ce_gamma, ce_theta,
            ce_vega, pe_delta, dte, iv, theta_decay_pct,
            
            # Execution State (8)
            spread_bps, imbalance, temp_impact * 100, perm_impact * 100,
            expected_slippage, time_urgency, 0, 0,  # padding
            
            # Portfolio State (8)
            pos_type, pos_pnl, minutes_in_trade_norm, equity_ratio,
            drawdown, prev_action, last_pnl, trade_count,
            
            # Temporal (6)
            minute_sin, minute_cos, day_of_week,
            is_opening, is_closing, is_lunch
        ], dtype=np.float32)
        
        return np.clip(obs, -10.0, 10.0)
    
    def step(self, action: int, urgency: float = 0.5) -> Tuple[np.ndarray, float, bool, Dict[str, Any]]:
        """
        Execute action at current minute.
        
        Args:
            action: 0=HOLD, 1=BUY_CE, 2=BUY_PE, 3=EXIT
            urgency: 0-1, how aggressive (affects execution cost)
        """
        row = self._get_daily_row()
        bar = self._get_current_bar()
        reward = 0.0
        done = False
        
        ce_price = row.get('bs_ce_price', 100)
        pe_price = row.get('bs_pe_price', 100)
        vix = row.get('vix_close', 15)
        adv = row.get('nifty_volume', 1e8)
        vol = vix / 100.0
        
        # Execute action with realistic execution
        if action == 3 and self.portfolio.position_qty > 0:
            reward = self._close_position(ce_price, pe_price, adv, vol, vix, urgency)
        elif action == 1 and self.portfolio.position_type != 1:
            if self.portfolio.position_type == 2:
                reward += self._close_position(ce_price, pe_price, adv, vol, vix, urgency)
            reward += self._open_position(ce_price, 1, adv, vol, vix, urgency)
        elif action == 2 and self.portfolio.position_type != 2:
            if self.portfolio.position_type == 1:
                reward += self._close_position(ce_price, pe_price, adv, vol, vix, urgency)
            reward += self._open_position(pe_price, 2, adv, vol, vix, urgency)
        
        # Advance time
        self.current_minute += self.decision_interval
        
        if self.current_minute >= self.MINUTES_PER_DAY:
            self.current_minute = 0
            self.current_day += 1
        
        if self.current_day >= len(self.intraday_bars):
            if self.portfolio.position_qty > 0:
                last_row = self.daily_data[-1] if self.daily_data else row
                reward += self._close_position(
                    last_row.get('bs_ce_price', 100),
                    last_row.get('bs_pe_price', 100),
                    last_row.get('nifty_volume', 1e8),
                    last_row.get('vix_close', 15) / 100.0,
                    last_row.get('vix_close', 15),
                    1.0  # Urgent exit at end
                )
            done = True
        
        # Track return
        minute_return = (self.portfolio.current_equity - self.prev_equity) / (self.prev_equity + 1e-6)
        self.minute_returns.append(minute_return)
        self.prev_equity = self.portfolio.current_equity
        
        self.prev_action = action
        self.last_pnl = minute_return
        
        obs = self._get_obs() if not done else np.zeros(self.OBS_DIM, dtype=np.float32)
        info = self._compute_metrics(done)
        
        return obs, reward, done, info
    
    def _open_position(self, price: float, pos_type: int, adv: float, vol: float, vix: float, urgency: float) -> float:
        """Open position with execution model."""
        qty = 50  # 1 lot = 25, trade 2 lots
        
        result = self.execution_model.execute_order(
            mid_price=price,
            trade_size=qty,
            is_buy=True,
            adv=adv,
            volatility=vol,
            vix=vix,
            urgency=urgency,
            is_option=True
        )
        
        self.portfolio.position_type = pos_type
        self.portfolio.position_qty = qty
        self.portfolio.entry_price = result.executed_price
        self.portfolio.entry_minute = self.current_minute
        self.portfolio.entry_day = self.current_day
        self.portfolio.trade_count += 1
        
        execution_cost = (result.executed_price - price) * qty
        self.portfolio.current_equity -= execution_cost
        
        return -result.total_cost_bps / 10000
    
    def _close_position(self, ce_price: float, pe_price: float, adv: float, vol: float, vix: float, urgency: float) -> float:
        """Close position with execution model."""
        price = ce_price if self.portfolio.position_type == 1 else pe_price
        qty = self.portfolio.position_qty
        
        result = self.execution_model.execute_order(
            mid_price=price,
            trade_size=qty,
            is_buy=False,
            adv=adv,
            volatility=vol,
            vix=vix,
            urgency=urgency,
            is_option=True
        )
        
        gross_pnl = (result.executed_price - self.portfolio.entry_price) * qty
        
        self.portfolio.current_equity += gross_pnl
        self.portfolio.peak_equity = max(self.portfolio.peak_equity, self.portfolio.current_equity)
        
        self.portfolio.position_type = 0
        self.portfolio.position_qty = 0
        self.portfolio.entry_price = 0.0
        
        return gross_pnl / self.initial_capital
    
    def _compute_metrics(self, done: bool) -> Dict[str, Any]:
        """Compute episode metrics."""
        pnl = self.portfolio.current_equity - self.initial_capital
        max_dd = (self.portfolio.peak_equity - self.portfolio.current_equity) / (self.portfolio.peak_equity + 1e-6)
        
        if len(self.minute_returns) > 1:
            returns = np.array(self.minute_returns)
            # Annualize: sqrt(252 * 375) = sqrt(94500) ≈ 307
            sharpe = np.mean(returns) / (np.std(returns) + 1e-8) * 307
        else:
            sharpe = 0.0
        
        row = self._get_daily_row()
        
        return {
            'capital': self.portfolio.current_equity,
            'roi': pnl / self.initial_capital,
            'max_drawdown': max_dd,
            'sharpe': sharpe,
            'trade_count': self.portfolio.trade_count,
            'day': self.current_day,
            'minute': self.current_minute,
            'regime': int(row.get('regime_enhanced', 0)),
            'date': str(row.get('date', '')),
            'done': done
        }


if __name__ == "__main__":
    # Test environment
    print("Testing IntradayEnv...")
    
    env = IntradayEnv(
        data_path='nifty_ultimate.parquet',
        episode_days=2,
        decision_interval=15
    )
    
    obs = env.reset()
    print(f"Observation shape: {obs.shape}")
    print(f"Initial obs: {obs[:10]}...")
    
    done = False
    total_reward = 0
    steps = 0
    
    while not done and steps < 50:
        action = np.random.choice([0, 1, 2, 3], p=[0.6, 0.15, 0.15, 0.1])
        obs, reward, done, info = env.step(action)
        total_reward += reward
        steps += 1
    
    print(f"\nEpisode stats:")
    print(f"  Steps: {steps}")
    print(f"  Total Reward: {total_reward:.4f}")
    print(f"  Final ROI: {info['roi']*100:.2f}%")
    print(f"  Trades: {info['trade_count']}")
