import jax
import jax.numpy as jnp
import optax
from flax.training import train_state
import flax.linen as nn
from models.world_model import WorldModel
from env.real_env import RealDataEnv
import pickle
import os
import numpy as np

def create_train_state(rng, model, learning_rate):
    """Creates initial 'TrainState'."""
    params = model.init(rng, jnp.ones((1, 64, 24))) # Batch, Seq, Feat
    tx = optax.adam(learning_rate)
    return train_state.TrainState.create(
        apply_fn=model.apply, params=params, tx=tx
    )

@jax.jit
def train_step(state, batch, rng):
    """Single training step for World Model."""
    
    def loss_fn(params):
        outputs = state.apply_fn(params, batch, key=rng)
        
        # 1. Reconstruction Loss (MSE)
        recon_loss = jnp.mean(jnp.square(batch - outputs['reconstructions']))
        
        # 2. KL Divergence Loss (VAE)
        # KL(N(mu, sigma) || N(0, 1)) = -0.5 * sum(1 + logvar - mu^2 - var)
        mu = outputs['post_means']
        logvar = outputs['post_logvars']
        kl_loss = -0.5 * jnp.mean(1 + logvar - jnp.square(mu) - jnp.exp(logvar))
        
        # 3. Contrastive Loss (Regime Consistency)
        # Pull z_t closer to z_{t+1} (Temporal consistency)
        # Push z_t away from z_random (Regime alignment)
        z = outputs['z_posts'] # [B, T, D]
        
        # Simple Temporal Contrastive: Minimize dist(z_t, z_{t+1})
        # This encourages smooth drift, not jumping.
        # SimCLR is more complex (requires augmentation).
        # Let's use a "smoothness" regularizer for now + KL handles regularization.
        contrast_loss = jnp.mean(jnp.square(z[:, 1:] - z[:, :-1]))
        
        # Total Loss
        # VAE Beta = 0.1 (disentanglement)
        total_loss = recon_loss + 0.01 * kl_loss + 0.1 * contrast_loss
        
        return total_loss, (recon_loss, kl_loss, contrast_loss)

    grad_fn = jax.value_and_grad(loss_fn, has_aux=True)
    (loss, (l_recon, l_kl, l_cont)), grads = grad_fn(state.params)
    state = state.apply_gradients(grads=grads)
    return state, loss, l_recon, l_kl, l_cont

def run_pretraining(epochs=50, batch_size=64, seq_len=64):
    print("🔱 Launching Maverick v4.0 Phase 1: World Model Pre-training...")
    
    # 1. Load Data
    print("Loading Market Data...")
    env = RealDataEnv() 
    # env.loader.df contains the data.
    # We need to reshape it into sequences.
    
    df = env.loader.df
    # Drop timestamp col if exists (indexes usually handled by loader)
    # The 'features' are in df explicitly.
    # We used DataAdaptor logic. 
    # Let's extract raw numpy array of features.
    # DataAdaptor._preprocess gives the features. 
    # The DF in loader should have ALL required columns if initialized?
    # Actually RealDataEnv calls loader.get_episode.
    
    # Let's iterate and collect ALL episodes to form a dataset
    # This might be slow but robust.
    # Or implement a speedy slicer.
    
    total_steps = len(df)
    data = []
    # Using raw values from DF columns that match OBS structure is tricky because DataAdaptor normalizes on fly?
    # No, DataAdaptor computes features and stores in DF.
    # Let's assume we can just step through the env to collect data? No too slow.
    # Use DataAdaptor.get_episode logic manually.
    
    # For now, let's grab random episodes to build a dataset buffer.
    print(f"Sampling {batch_size*100} sequences...")
    all_obs = []
    for _ in range(batch_size * 50): # 3200 sequences
        idx = np.random.randint(0, total_steps - seq_len - 1)
        # We need to construct MarketState -> Obs for each step?
        # DataAdaptor `get_episode` returns list of MarketState.
        # NiftyEnv `_get_obs` converts MarketState to vector.
        # This conversion is needed.
        
        # Shortcut: Just load a bunch of episodes via env.reset/step loop? 
        # Too slow.
        # We rely on DataAdaptor returning MarketState, then we must map to Obs vector.
        # We can instantiate NiftyEnv and use its helper.
        
        ep_states = env.loader.get_episode(idx, seq_len)
        # Convert to obs
        seq_obs = []
        for ms in ep_states:
            # We need to replicate NiftyEnv._get_obs logic.
            # Using env instance from NiftyEnv:
            env.market_state = ms
            seq_obs.append(env._get_obs())
        
        all_obs.append(np.array(seq_obs))
        
    dataset = np.array(all_obs) # [N, Seq, Dim]
    print(f"Dataset Shape: {dataset.shape}")
    
    dataset = jnp.array(dataset)
    num_samples = len(dataset)
    
    # 2. Init Model
    model = WorldModel()
    rng = jax.random.PRNGKey(0)
    state = create_train_state(rng, model, learning_rate=1e-3)
    
    # 3. Train Loop
    for epoch in range(epochs):
        # Shuffle
        rng, shuffle_key = jax.random.split(rng)
        perms = jax.random.permutation(shuffle_key, num_samples)
        shuffled_data = dataset[perms]
        
        epoch_loss = 0
        batch_count = 0
        
        for i in range(0, num_samples, batch_size):
            batch = shuffled_data[i:i+batch_size]
            if len(batch) < batch_size: continue
            
            rng, step_key = jax.random.split(rng)
            state, loss, l_recon, l_kl, l_cont = train_step(state, batch, step_key)
            
            epoch_loss += loss
            batch_count += 1
        
        avg_loss = epoch_loss / batch_count
        if epoch % 5 == 0:
            print(f"Epoch {epoch}: Total={avg_loss:.4f} (Recon={l_recon:.4f}, KL={l_kl:.4f}, Cont={l_cont:.4f})")
            
    # 4. Save
    os.makedirs("checkpoints", exist_ok=True)
    with open("checkpoints/world_model_v1.pkl", "wb") as f:
        pickle.dump(state.params, f)
    print("✅ World Model Pre-training Complete.")

if __name__ == "__main__":
    run_pretraining()
