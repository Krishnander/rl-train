"""
Historical Data Environment for Training on Real Nifty Data.

Uses enriched parquet with Black-Scholes derived option prices.
"""

import numpy as np
import pandas as pd
from typing import Tuple, Dict, Any, Optional
from dataclasses import dataclass

@dataclass
class PortfolioState:
    """Track portfolio state."""
    position_type: int  # 0: None, 1: CE, 2: PE
    position_qty: int
    entry_price: float
    entry_day: int
    peak_equity: float
    current_equity: float
    trade_count: int


class HistoricalEnv:
    """
    Environment that replays REAL Nifty data with Black-Scholes option prices.
    
    Uses nifty_enriched_bs.parquet (2007-2026, 4496 days with BS prices).
    """
    
    OBS_FEATURES = 24
    OBS_DIM = 24
    
    def __init__(self, 
                 data_path: str = "nifty_enriched_bs.parquet",
                 initial_capital: float = 200000.0,
                 episode_length: int = 30,
                 mode: str = 'sequential'):
        """
        Args:
            data_path: Path to enriched parquet
            initial_capital: Starting capital
            episode_length: Days per episode
            mode: 'sequential' for training, 'random' for evaluation
        """
        self.df = pd.read_parquet(data_path)
        self.df = self.df.sort_values('date').reset_index(drop=True)
        self.df = self.df.ffill().fillna(0)
        
        self.initial_capital = initial_capital
        self.episode_length = episode_length
        self.lot_size = 25  # Nifty lot size
        self.mode = mode
        
        # Precompute derived features
        self._precompute_features()
        
        self.portfolio = None
        self.current_idx = 0
        self.start_idx = 0
        self.episode_count = 0
        
    def _precompute_features(self):
        """Derive additional features."""
        # FII Velocity
        self.df['fii_velocity'] = self.df['fii_net_value_cr'].pct_change(5).fillna(0).clip(-1, 1)
        
        # VIX Percentile (rolling 252-day)
        vix_pct = self.df['vix_close'].rolling(252, min_periods=20).apply(
            lambda x: (x.iloc[-1] <= x).mean() if len(x) > 0 else 0.5
        )
        self.df['vix_percentile'] = vix_pct.fillna(0.5)
        
        # MA Slopes
        self.df['ma_50_slope'] = self.df['nifty_ma_50'].pct_change(5).fillna(0).clip(-0.1, 0.1)
        self.df['ma_200_div'] = ((self.df['nifty_close'] / self.df['nifty_ma_200']) - 1).fillna(0).clip(-0.2, 0.2)
        
        # Regime Classification
        def classify_regime(row):
            vix = row['vix_close'] if pd.notna(row['vix_close']) else 15
            ret = row['nifty_daily_return'] if pd.notna(row['nifty_daily_return']) else 0
            
            if vix > 30:
                return 3  # Crisis
            elif vix > 22:
                return 2  # Bear
            elif vix < 15 and ret > 0.003:
                return 1  # Bull
            else:
                return 0  # Calm
        
        self.df['regime'] = self.df.apply(classify_regime, axis=1)
        
    def get_total_episodes(self) -> int:
        return len(self.df) - self.episode_length
    
    def reset(self, start_idx: Optional[int] = None, fixed_regime: Optional[int] = None) -> np.ndarray:
        """Reset for new episode."""
        max_start = len(self.df) - self.episode_length - 1
        
        if start_idx is not None:
            self.start_idx = min(start_idx, max_start)
        elif self.mode == 'sequential':
            # Sequential for training diversity
            self.start_idx = (self.episode_count * 7) % max_start  # Weekly steps
        else:
            self.start_idx = np.random.randint(0, max_start)
        
        self.current_idx = self.start_idx
        self.episode_count += 1
        
        self.portfolio = PortfolioState(
            position_type=0,
            position_qty=0,
            entry_price=0.0,
            entry_day=0,
            peak_equity=self.initial_capital,
            current_equity=self.initial_capital,
            trade_count=0
        )
        
        self.daily_returns = []
        self.prev_equity = self.initial_capital
        self.prev_action = 0
        self.last_step_pnl = 0.0
        
        return self._get_obs()
    
    def _get_obs(self) -> np.ndarray:
        """Construct 24-feature observation vector."""
        row = self.df.iloc[self.current_idx]
        
        # Core features using REAL Black-Scholes prices
        spot = row['nifty_close']
        spot_norm = (spot / 22000.0) - 1.0
        
        gap_pct = row['nifty_intraday_return'] * 10.0 if pd.notna(row['nifty_intraday_return']) else 0
        
        vix = row['vix_close'] if pd.notna(row['vix_close']) else 15
        vix_norm = vix / 50.0
        vix_percentile = row['vix_percentile']
        
        # BLACK-SCHOLES PRICES (the key improvement!)
        ce_price = row['bs_ce_price'] / 300.0
        pe_price = row['bs_pe_price'] / 300.0
        
        # IV from VIX
        iv = row['bs_iv'] if pd.notna(row['bs_iv']) else 0.15
        iv_skew = (iv - 0.15) * 10.0  # Centered around 15%
        
        # DTE (real weekly expiry)
        dte = row['bs_dte'] / 7.0
        
        # Greeks (from Black-Scholes)
        ce_delta = row['bs_ce_delta']
        pe_delta = row['bs_pe_delta']
        ce_theta = row['bs_ce_theta'] * 100.0  # Scale up daily theta
        pe_theta = row['bs_pe_theta'] * 100.0
        
        # FII Signals
        fii_mom = row['fii_net_value_cr'] / 5000.0 if pd.notna(row['fii_net_value_cr']) else 0
        fii_velocity = row['fii_velocity'] * 10.0
        
        # Advance/Decline as OI proxy
        adv_dec = row['adv_dec_ratio'] if pd.notna(row['adv_dec_ratio']) else 1.0
        fii_oi_z = (adv_dec - 1.0) * 2.0
        
        # PCR for retail trap
        pcr = row['pcr_nifty'] if pd.notna(row['pcr_nifty']) else 1.0
        retail_trap = -(pcr - 1.0) * 2.0
        
        # Global signals
        global_nasdaq = 0.0
        usdinr = row['usdinr_close'] if pd.notna(row['usdinr_close']) else 83
        global_usdinr = (usdinr - 83) / 5.0
        
        # Trend features
        ma_50_slope = row['ma_50_slope'] * 50.0
        ma_200_div = row['ma_200_div'] * 10.0
        
        regime = float(row['regime']) / 4.0
        
        # Portfolio state
        pos_type = float(self.portfolio.position_type) / 2.0
        prev_action = float(self.prev_action) / 3.0
        last_pnl = self.last_step_pnl * 10.0
        
        obs = np.array([
            spot_norm, gap_pct, vix_norm, vix_percentile,
            ce_price, pe_price, iv_skew, dte,
            ce_delta, pe_delta, ce_theta, pe_theta,
            fii_mom, fii_oi_z, fii_velocity, retail_trap,
            global_nasdaq, global_usdinr,
            ma_50_slope, ma_200_div, regime,
            pos_type, prev_action, last_pnl
        ], dtype=np.float32)
        
        return np.clip(obs, -10.0, 10.0)  # Safety clip
    
    def step(self, action: int, expected_edge_pct: Optional[float] = None,
             size_multiplier: float = 1.0) -> Tuple[np.ndarray, float, bool, Dict[str, Any]]:
        """Execute action using REAL option prices."""
        row = self.df.iloc[self.current_idx]
        reward = 0.0
        done = False
        
        # REAL Black-Scholes prices
        ce_price = row['bs_ce_price']
        pe_price = row['bs_pe_price']
        
        # Execute action
        if action == 3 and self.portfolio.position_qty > 0:
            reward = self._close_position(ce_price, pe_price)
        elif action == 1 and self.portfolio.position_type != 1:
            if self.portfolio.position_type == 2:
                reward += self._close_position(ce_price, pe_price)
            reward += self._open_position(ce_price, pos_type=1, size_multiplier=size_multiplier)
        elif action == 2 and self.portfolio.position_type != 2:
            if self.portfolio.position_type == 1:
                reward += self._close_position(ce_price, pe_price)
            reward += self._open_position(pe_price, pos_type=2, size_multiplier=size_multiplier)
        
        # Mark-to-market if holding
        if self.portfolio.position_qty > 0:
            current_price = ce_price if self.portfolio.position_type == 1 else pe_price
            mtm = (current_price - self.portfolio.entry_price) * self.portfolio.position_qty
            temp_equity = self.initial_capital + mtm - (self.initial_capital - self.portfolio.current_equity)
            # Don't update equity, just note the unrealized
        
        # Advance time
        self.current_idx += 1
        steps_in_episode = self.current_idx - self.start_idx
        
        if steps_in_episode >= self.episode_length or self.current_idx >= len(self.df) - 1:
            if self.portfolio.position_qty > 0:
                next_row = self.df.iloc[min(self.current_idx, len(self.df)-1)]
                reward += self._close_position(next_row['bs_ce_price'], next_row['bs_pe_price'])
            done = True
        
        # Track return
        daily_return = (self.portfolio.current_equity - self.prev_equity) / self.prev_equity
        self.daily_returns.append(daily_return)
        self.prev_equity = self.portfolio.current_equity
        
        self.prev_action = action
        self.last_step_pnl = daily_return
        
        obs = self._get_obs() if not done else np.zeros(24, dtype=np.float32)
        info = self._compute_metrics(done)
        
        return obs, reward, done, info
    
    def _open_position(self, price: float, pos_type: int, size_multiplier: float = 1.0) -> float:
        """Open position with realistic costs."""
        qty = int(2 * self.lot_size * size_multiplier)
        
        # Slippage: 0.1% for Nifty options (liquid market)
        exec_price = price * 1.001
        fees = qty * 20  # Approx Rs 20 per lot
        
        self.portfolio.position_type = pos_type
        self.portfolio.position_qty = qty
        self.portfolio.entry_price = exec_price
        self.portfolio.entry_day = self.current_idx - self.start_idx
        self.portfolio.trade_count += 1
        self.portfolio.current_equity -= fees
        
        return -fees / self.initial_capital
    
    def _close_position(self, ce_price: float, pe_price: float) -> float:
        """Close position with realistic costs."""
        price = ce_price if self.portfolio.position_type == 1 else pe_price
        qty = self.portfolio.position_qty
        
        exec_price = price * 0.999  # Slippage on close
        fees = qty * 20
        
        gross_pnl = (exec_price - self.portfolio.entry_price) * qty
        net_pnl = gross_pnl - fees
        
        self.portfolio.current_equity += net_pnl
        self.portfolio.peak_equity = max(self.portfolio.peak_equity, self.portfolio.current_equity)
        
        self.portfolio.position_type = 0
        self.portfolio.position_qty = 0
        self.portfolio.entry_price = 0.0
        
        return net_pnl / self.initial_capital
    
    def _compute_metrics(self, done: bool) -> Dict[str, Any]:
        """Compute episode metrics."""
        pnl = self.portfolio.current_equity - self.initial_capital
        max_dd = (self.portfolio.peak_equity - self.portfolio.current_equity) / self.portfolio.peak_equity
        
        if len(self.daily_returns) > 1:
            returns = np.array(self.daily_returns)
            sharpe = np.mean(returns) / (np.std(returns) + 1e-8) * np.sqrt(252)
        else:
            sharpe = 0.0
        
        row = self.df.iloc[min(self.current_idx, len(self.df)-1)]
        
        return {
            'capital': self.portfolio.current_equity,
            'roi': pnl / self.initial_capital,
            'max_drawdown': max_dd,
            'sharpe': sharpe,
            'trade_count': self.portfolio.trade_count,
            'survival_pct': (self.current_idx - self.start_idx) / self.episode_length,
            'regime': int(row['regime']),
            'date': str(row['date']),
            'done': done
        }
