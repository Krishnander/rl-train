import jax
import jax.numpy as jnp
import numpy as np
from typing import Dict, Any, List, Optional
from flax.training import train_state

class ReplayBuffer:
    """
    Simple Experience Replay Buffer for continual learning.
    Stores important batches (e.g., high reward or diverse regimes).
    """
    def __init__(self, capacity: int = 100):
        self.capacity = capacity
        self.buffer = []

    def add(self, batch: Dict[str, jnp.ndarray]):
        if len(self.buffer) >= self.capacity:
            self.buffer.pop(0)
        self.buffer.append(batch)

    def sample(self) -> Optional[Dict[str, jnp.ndarray]]:
        if not self.buffer:
            return None
        idx = np.random.randint(0, len(self.buffer))
        return self.buffer[idx]

class EWC:
    """
    Elastic Weight Consolidation (EWC).
    Prevents catastrophic forgetting by penalizing changes to important weights.
    """
    def __init__(self, lambda_ewc: float = 100.0):
        self.lambda_ewc = lambda_ewc
        self.fisher_info = None
        self.opt_params = None

    def update_importance(self, state: train_state.TrainState, batch: Dict[str, jnp.ndarray], compute_loss_fn):
        """
        Estimate Fisher Information Matrix (diagonal) using gradients.
        """
        def loss_fn(params):
            loss, _ = compute_loss_fn(params, batch, jax.random.PRNGKey(0))
            return loss

        grads = jax.grad(loss_fn)(state.params)
        
        # Square of gradients as proxy for Fisher Information
        new_fisher = jax.tree_util.tree_map(lambda g: g**2, grads)
        
        if self.fisher_info is None:
            self.fisher_info = new_fisher
        else:
            # Running average of Fisher Info
            self.fisher_info = jax.tree_util.tree_map(
                lambda f, nf: 0.9 * f + 0.1 * nf, self.fisher_info, new_fisher
            )
        
        self.opt_params = state.params

    def penalty(self, params: Any) -> jnp.ndarray:
        """
        Calculate EWC penalty: sum( Fisher * (theta - theta_opt)^2 )
        """
        if self.fisher_info is None or self.opt_params is None:
            return 0.0

        diff_sq = jax.tree_util.tree_map(
            lambda p, op: (p - op)**2, params, self.opt_params
        )
        
        penalties = jax.tree_util.tree_map(
            lambda f, d: jnp.sum(f * d), self.fisher_info, diff_sq
        )
        
        # Flatten and sum all leaf penalties
        flat_penalties, _ = jax.tree_util.tree_flatten(penalties)
        return self.lambda_ewc * jnp.sum(jnp.array(flat_penalties))
