from typing import Tuple, Dict, Any, Optional
import numpy as np
from env.nifty_env import NiftyEnv, PortfolioState
from env.data_adaptor import ParquetLoader
import os

class RealDataEnv(NiftyEnv):
    """
    Subclass of NiftyEnv that plays back REAL historical data from Parquet.
    """
    def __init__(self, parquet_path: str = None):
        if parquet_path is None:
            # Default to the research feature store we found
            parquet_path = "c:/Workspace/AI Projects/Trading Engine/research/master_feature_store_fixed.parquet"
        
        if not os.path.exists(parquet_path):
            raise FileNotFoundError(f"Parquet source not found at: {parquet_path}")
            
        self.loader = ParquetLoader(parquet_path)
        self.episode_length = 30
        
        # Initialize base class (calls reset internally)
        super().__init__()

    def reset(self, fixed_regime: Optional[int] = None, start_idx: Optional[int] = None) -> np.ndarray:
        """
        Reset environment by loading a real historical episode.
        """
        self.current_step = 0
        
        # Initialize portfolio state (matching NiftyEnv)
        self.portfolio = PortfolioState(
            position_type=0,
            position_qty=0,
            entry_price=0.0,
            entry_day=0,
            peak_equity=self.initial_capital,
            current_equity=self.initial_capital,
            trade_count=0
        )
        
        self.daily_returns = []
        self.prev_equity = self.initial_capital

        # Feedback Features (Recursive Loop)
        self.prev_action = 0
        self.last_step_pnl = 0.0
        
        # Load real data
        if start_idx is None:
            start_idx = self.loader.sample_start_idx()
            
        self.episode_data = self.loader.get_episode(start_idx, length=self.episode_length)
        
        return self._get_obs()

    def get_total_available_episodes(self) -> int:
        """Helper to see how much data we have."""
        return len(self.loader.df)
