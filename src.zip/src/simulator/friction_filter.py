"""
Friction Filter - Ported from AI_Trader.

The "financial miracle" that prevents trading when costs exceed edge.
"""

from typing import Tuple
from dataclasses import dataclass


@dataclass
class FrictionConfig:
    """2026 SEBI Rules + Microstructure Costs."""
    nifty_lot_size: int = 65
    point_value: float = 65.0
    
    # Transaction costs
    stt_options_pct: float = 0.001  # 0.1% on premium (sell side)
    exchange_per_lakh: float = 3.5  # ~3500 per crore
    brokerage_per_order: float = 20.0
    gst_pct: float = 0.18
    
    # Friction thresholds
    base_slippage_pts: float = 2.0  # Base slippage in premium points
    min_profit_threshold: float = 5.0  # Minimum net profit in premium points


class FrictionFilter:
    """
    The "Friction Kill" - Skip trade if slippage + tax > edge.
    
    This is the core insight from AI_Trader that prevents over-trading.
    If the expected profit doesn't exceed all costs, DON'T TRADE.
    """
    
    def __init__(self, config: FrictionConfig = None):
        self.config = config or FrictionConfig()
    
    def calculate_transaction_cost(self, premium: float, qty: int) -> float:
        """Calculate total transaction cost in rupees."""
        # Notional value
        notional = premium * qty
        
        # STT (sell side only for options)
        stt = notional * self.config.stt_options_pct
        
        # Exchange fees
        exchange = (notional / 100000) * self.config.exchange_per_lakh * 2  # Both sides
        
        # Brokerage
        brokerage = self.config.brokerage_per_order * 2  # Entry + Exit
        
        # GST
        gst = (brokerage + exchange) * self.config.gst_pct
        
        return stt + exchange + brokerage + gst
    
    def cost_in_premium_points(self, premium: float, qty: int) -> float:
        """Convert transaction cost to premium points."""
        cost_rs = self.calculate_transaction_cost(premium, qty)
        return cost_rs / qty  # Cost per share
    
    def estimate_slippage(self, vix: float, gap_pct: float = 0.0) -> float:
        """
        Estimate slippage based on VIX and gap.
        Higher VIX = wider spreads = more slippage.
        """
        # Base slippage
        slippage = self.config.base_slippage_pts
        
        # VIX multiplier (slippage increases above VIX 15)
        if vix > 15:
            vix_mult = 1.0 + 0.05 * (vix - 15)
            slippage *= vix_mult
        
        # Gap multiplier (gaps create adverse selection)
        slippage *= (1 + 0.5 * abs(gap_pct))
        
        return slippage
    
    def should_skip(self, expected_profit_pct: float, vix: float, 
                    gap_pct: float, premium: float, qty: int) -> Tuple[bool, str]:
        """
        The MIRACLE: Skip trade if friction exceeds edge.
        
        Args:
            expected_profit_pct: Expected profit as % of premium (e.g., 0.05 = 5%)
            vix: Current VIX level
            gap_pct: Today's gap percentage
            premium: Option premium
            qty: Position size
        
        Returns:
            (should_skip, reason)
        """
        # Calculate costs
        slippage = self.estimate_slippage(vix, gap_pct)
        txn_cost = self.cost_in_premium_points(premium, qty)
        
        total_friction = slippage + txn_cost
        expected_profit_pts = premium * expected_profit_pct
        net_profit = expected_profit_pts - total_friction
        
        # The MIRACLE: Don't trade if friction kills the edge
        if net_profit < self.config.min_profit_threshold:
            return True, f"FRICTION KILL: Net {net_profit:.1f} < {self.config.min_profit_threshold}"
        
        return False, f"TRADE OK: Net {net_profit:.1f} pts profit"
    
    def get_minimum_edge_required(self, vix: float, gap_pct: float, 
                                   premium: float, qty: int) -> float:
        """
        Calculate minimum edge (%) required to overcome friction.
        
        This tells the agent: "Only trade if you expect at least X% profit"
        """
        slippage = self.estimate_slippage(vix, gap_pct)
        txn_cost = self.cost_in_premium_points(premium, qty)
        
        total_friction = slippage + txn_cost + self.config.min_profit_threshold
        
        # Convert to percentage of premium
        min_edge_pct = total_friction / premium
        
        return min_edge_pct


def test_friction_filter():
    """Test the friction filter."""
    ff = FrictionFilter()
    
    print("=" * 50)
    print("FRICTION FILTER TEST")
    print("=" * 50)
    
    # Test case 1: Low VIX, small expected profit
    skip, reason = ff.should_skip(
        expected_profit_pct=0.02,  # 2% expected
        vix=12.0,
        gap_pct=0.005,
        premium=250.0,
        qty=130
    )
    print(f"Case 1 (2% edge, VIX 12): Skip={skip}, {reason}")
    
    # Test case 2: High VIX, high expected profit
    skip, reason = ff.should_skip(
        expected_profit_pct=0.10,  # 10% expected
        vix=35.0,
        gap_pct=0.02,
        premium=400.0,
        qty=130
    )
    print(f"Case 2 (10% edge, VIX 35): Skip={skip}, {reason}")
    
    # Test case 3: What's the minimum edge needed?
    min_edge = ff.get_minimum_edge_required(
        vix=20.0,
        gap_pct=0.01,
        premium=250.0,
        qty=130
    )
    print(f"Minimum edge required at VIX 20: {min_edge*100:.1f}%")


if __name__ == "__main__":
    test_friction_filter()
