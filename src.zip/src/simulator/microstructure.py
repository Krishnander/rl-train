"""
Microstructure Model for Realistic F&O Execution
Based on 2025-2026 India F&O fee structure research.
"""

from dataclasses import dataclass
from typing import Tuple
import numpy as np

@dataclass
class TransactionCosts2026:
    """
    India F&O Transaction Costs (Revised Oct 2024, valid through 2026)
    Source: NSE, Zerodha, Angel One official fee schedules
    """
    # Brokerage
    brokerage_per_order: float = 20.0  # ₹20 flat per order
    
    # STT (Securities Transaction Tax) - Sell side only for options
    stt_rate_options_sell: float = 0.001  # 0.1% on premium (revised Oct 2024)
    
    # Exchange Transaction Charges
    exchange_fee_per_crore: float = 3503.0  # ₹3,503 per crore of turnover
    
    # SEBI Turnover Fees
    sebi_fee_per_crore: float = 10.0  # ₹10 per crore
    
    # GST on (brokerage + exchange fees + SEBI fees)
    gst_rate: float = 0.18  # 18%
    
    # Stamp Duty (Buy side only)
    stamp_duty_rate: float = 0.00003  # 0.003%
    
    def calculate_buy_cost(self, notional_value: float, premium_value: float) -> float:
        """Calculate total cost for buying options."""
        exchange_fee = (notional_value / 1e7) * self.exchange_fee_per_crore
        sebi_fee = (notional_value / 1e7) * self.sebi_fee_per_crore
        gst = self.gst_rate * (self.brokerage_per_order + exchange_fee + sebi_fee)
        stamp_duty = notional_value * self.stamp_duty_rate
        
        return self.brokerage_per_order + exchange_fee + sebi_fee + gst + stamp_duty
    
    def calculate_sell_cost(self, notional_value: float, premium_value: float) -> float:
        """Calculate total cost for selling options (includes STT)."""
        exchange_fee = (notional_value / 1e7) * self.exchange_fee_per_crore
        sebi_fee = (notional_value / 1e7) * self.sebi_fee_per_crore
        stt = premium_value * self.stt_rate_options_sell
        gst = self.gst_rate * (self.brokerage_per_order + exchange_fee + sebi_fee)
        
        return self.brokerage_per_order + exchange_fee + sebi_fee + stt + gst
    
    def round_trip_cost(self, entry_notional: float, exit_notional: float, 
                        entry_premium: float, exit_premium: float) -> float:
        """Calculate total round-trip cost."""
        buy_cost = self.calculate_buy_cost(entry_notional, entry_premium)
        sell_cost = self.calculate_sell_cost(exit_notional, exit_premium)
        return buy_cost + sell_cost


class Microstructure:
    """
    Realistic execution modeling with VIX-dependent dynamics.
    
    Key features:
    - Bid-ask spread widens with VIX (market stress = worse fills)
    - Slippage increases with order size
    - Realistic latency modeling
    """
    
    def __init__(self):
        self.base_spread_pct = 0.002  # 0.2% base spread
        self.vix_spread_sensitivity = 0.05  # Spread increases 5% per VIX point
        self.slippage_per_lot = 0.0005  # 0.05% per lot
        self.lot_size = 65  # Nifty lot size
        self.cost_model = TransactionCosts2026()
    
    def bid_ask_spread(self, vix: float) -> float:
        """
        Calculate bid-ask spread as function of VIX.
        Higher VIX = wider spreads = worse execution.
        """
        # Spread widens non-linearly above VIX 20
        if vix <= 15:
            multiplier = 1.0
        elif vix <= 20:
            multiplier = 1.0 + 0.03 * (vix - 15)
        elif vix <= 30:
            multiplier = 1.15 + 0.05 * (vix - 20)
        else:  # Crisis conditions
            multiplier = 1.65 + 0.10 * (vix - 30)
        
        return self.base_spread_pct * multiplier
    
    def slippage(self, lots: int, vix: float) -> float:
        """
        Calculate slippage based on order size and market conditions.
        Large orders in volatile markets = more slippage.
        """
        base_slippage = self.slippage_per_lot * lots
        vix_multiplier = 1.0 + max(0, (vix - 15) * 0.02)
        return base_slippage * vix_multiplier
    
    def execution_price(self, mid_price: float, is_buy: bool, 
                        lots: int, vix: float) -> float:
        """
        Calculate the actual execution price after spread and slippage.
        """
        spread = self.bid_ask_spread(vix)
        slip = self.slippage(lots, vix)
        
        if is_buy:
            # Pay above mid when buying
            return mid_price * (1 + spread / 2 + slip)
        else:
            # Receive below mid when selling
            return mid_price * (1 - spread / 2 - slip)
    
    def total_trade_cost(self, mid_price: float, qty: int, vix: float, 
                         is_buy: bool) -> Tuple[float, float]:
        """
        Calculate total trade cost including execution slippage and fees.
        
        Returns:
            (execution_price, total_fees)
        """
        lots = qty // self.lot_size
        exec_price = self.execution_price(mid_price, is_buy, lots, vix)
        notional = exec_price * qty
        
        if is_buy:
            fees = self.cost_model.calculate_buy_cost(notional, notional)
        else:
            fees = self.cost_model.calculate_sell_cost(notional, notional)
        
        return exec_price, fees
    
    def round_trip_pct(self, entry_mid: float, exit_mid: float, 
                       qty: int, entry_vix: float, exit_vix: float) -> float:
        """
        Calculate total round-trip cost as percentage of entry value.
        
        This is the key metric for determining if a trade is worthwhile.
        """
        lots = qty // self.lot_size
        
        # Entry
        entry_exec = self.execution_price(entry_mid, True, lots, entry_vix)
        entry_notional = entry_exec * qty
        entry_fees = self.cost_model.calculate_buy_cost(entry_notional, entry_notional)
        
        # Exit
        exit_exec = self.execution_price(exit_mid, False, lots, exit_vix)
        exit_notional = exit_exec * qty
        exit_fees = self.cost_model.calculate_sell_cost(exit_notional, exit_notional)
        
        # Total cost as % of entry
        spread_cost = (entry_exec - entry_mid) / entry_mid + (exit_mid - exit_exec) / exit_mid
        fee_cost = (entry_fees + exit_fees) / entry_notional
        
        return spread_cost + fee_cost


def test_microstructure():
    """Quick validation of the microstructure model."""
    micro = Microstructure()
    
    print("=" * 50)
    print("MICROSTRUCTURE MODEL VALIDATION")
    print("=" * 50)
    
    # Test spread widening with VIX
    print("\n1. Bid-Ask Spread by VIX:")
    for vix in [12, 15, 18, 22, 28, 35, 45]:
        spread = micro.bid_ask_spread(vix) * 100
        print(f"   VIX {vix}: {spread:.3f}%")
    
    # Test round-trip costs
    print("\n2. Round-Trip Costs (2 lots, ₹250 premium):")
    entry_price = 250.0
    qty = 130  # 2 lots
    
    for vix in [12, 20, 30, 40]:
        # Assume exit at same price (break-even trade)
        rt_pct = micro.round_trip_pct(entry_price, entry_price, qty, vix, vix)
        print(f"   VIX {vix}: {rt_pct*100:.3f}% round-trip cost")
    
    print("\n3. Transaction Fee Breakdown (₹250 x 130 qty = ₹32,500):")
    costs = TransactionCosts2026()
    notional = 250 * 130
    buy = costs.calculate_buy_cost(notional, notional)
    sell = costs.calculate_sell_cost(notional, notional)
    print(f"   Buy fees: ₹{buy:.2f}")
    print(f"   Sell fees: ₹{sell:.2f}")
    print(f"   Total: ₹{buy + sell:.2f} ({(buy+sell)/notional*100:.3f}%)")


if __name__ == "__main__":
    test_microstructure()
