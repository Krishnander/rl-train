import jax
import jax.numpy as jnp
from flax import linen as nn
from typing import Tuple, Optional

class Encoder(nn.Module):
    """
    Maps Observation -> Latent Distribution (Mean, LogVar).
    Captures the 'Regime' from raw features.
    """
    latent_dim: int = 64
    hidden_dim: int = 128
    
    @nn.compact
    def __call__(self, x: jnp.ndarray, training: bool = True) -> Tuple[jnp.ndarray, jnp.ndarray]:
        x = nn.Dense(self.hidden_dim, name='enc_fc1')(x)
        x = nn.elu(x) # ELU often better for VAEs
        x = nn.Dense(self.hidden_dim, name='enc_fc2')(x)
        x = nn.elu(x)
        
        mean = nn.Dense(self.latent_dim, name='enc_mean')(x)
        logvar = nn.Dense(self.latent_dim, name='enc_logvar')(x)
        return mean, logvar

class Decoder(nn.Module):
    """
    Maps Latent -> Observation Reconstruction.
    """
    obs_dim: int = 24
    hidden_dim: int = 128
    
    @nn.compact
    def __call__(self, z: jnp.ndarray) -> jnp.ndarray:
        z = nn.Dense(self.hidden_dim, name='dec_fc1')(z)
        z = nn.elu(z)
        z = nn.Dense(self.hidden_dim, name='dec_fc2')(z)
        z = nn.elu(z)
        
        recon = nn.Dense(self.obs_dim, name='dec_out')(z)
        return recon

class Dynamics(nn.Module):
    """
    Recurrent Dynamics Model: z_t = GRU(z_{t-1}, a_{t-1}).
    Predicts the future latent state (Prior).
    """
    latent_dim: int = 64
    action_dim: int = 4
    hidden_dim: int = 128
    
    def setup(self):
        self.gru = nn.GRUCell(features=self.hidden_dim)
        self.fc_mean = nn.Dense(self.latent_dim)
        self.fc_logvar = nn.Dense(self.latent_dim)
        # Action embedding if needed
        self.action_fc = nn.Dense(32)

    def __call__(self, prev_h: jnp.ndarray, prev_z: jnp.ndarray, action: Optional[jnp.ndarray] = None) -> Tuple[jnp.ndarray, Tuple[jnp.ndarray, jnp.ndarray]]:
        """
        Step the dynamics.
        Args:
            prev_h: GRU hidden state
            prev_z: Input latent (from posterior or sampling)
            action: Action taken (optional for pre-training)
        Returns:
            new_h: New GRU state
            (prior_mean, prior_logvar): Predicted next latent distribution
        """
        # Combine latent and action
        if action is not None:
            act_embed = nn.elu(self.action_fc(action))
            gru_input = jnp.concatenate([prev_z, act_embed], axis=-1)
        else:
            gru_input = prev_z
            
        new_h, _ = self.gru(new_h=prev_h, inputs=gru_input)
        
        # Predict parameters of next z
        prior_mean = self.fc_mean(new_h)
        prior_logvar = self.fc_logvar(new_h)
        
        return new_h, (prior_mean, prior_logvar)
    
    def initialize_carry(self, batch_size):
        return jnp.zeros((batch_size, self.hidden_dim))

class WorldModel(nn.Module):
    """
    Dreamer-Lite GRU-VAE Architecture.
    Combines Encoder, Decoder, and Dynamics.
    """
    latent_dim: int = 64
    obs_dim: int = 24
    action_dim: int = 4
    
    def setup(self):
        self.encoder = Encoder(latent_dim=self.latent_dim)
        self.decoder = Decoder(obs_dim=self.obs_dim)
        self.dynamics = Dynamics(latent_dim=self.latent_dim, action_dim=self.action_dim)
        
    def __call__(self, obs_seq: jnp.ndarray, action_seq: Optional[jnp.ndarray] = None, key: jnp.ndarray = None):
        """
        Forward pass for Sequence Processing (Training).
        Returns reconstruction, priors, posteriors for loss calculation.
        """
        batch_size, seq_len, _ = obs_seq.shape
        
        # 1. Encode all observations (Posterior)
        # We can parallelize this part
        post_means, post_logvars = self.encoder(obs_seq)
        
        # Sample posteriors (using reparameterization)
        if key is None:
             key = jax.random.PRNGKey(0)
             
        # We need independent RNG per batch sample
        batch_size = obs_seq.shape[0]
        rngs = jax.random.split(key, batch_size)
        
        def reparameterize(mean, logvar, rng):
            std = jnp.exp(0.5 * logvar)
            eps = jax.random.normal(rng, mean.shape)
            return mean + eps * std
        
        # Vectorized sampling over batch
        z_posts = jax.vmap(reparameterize)(post_means, post_logvars, rngs)
        
        # 2. Decode all latents (Reconstruction)
        reconstructions = self.decoder(z_posts)
        
        # 3. Dynamics Unroll (Prior Prediction)
        # This must be sequential
        h_init = self.dynamics.initialize_carry(batch_size)
        
        def step_dynamics(carry, x):
            h, (z_prev, act) = carry
            # z_prev is the POSTERIOR from previous step (teacher forcing)
            # In Phase 1 (Unsupervised), we don't have actions usually, or use dummy
            
            new_h, (prior_mean, prior_logvar) = self.dynamics(h, z_prev, act)
            return (new_h, (None, None)), (prior_mean, prior_logvar)

        # For dynamics training, we usually input z_{t-1} to predict z_t.
        # Inputs to scan: z_posts[:, :-1], actions[:, :-1]
        # Targets: z_posts[:, 1:]
        
        # Prepare inputs (shift by 1)
        z_inputs = jnp.concatenate([jnp.zeros((batch_size, 1, self.latent_dim)), z_posts[:, :-1]], axis=1)
        if action_seq is None:
             act_inputs = None # Handle inside dynamics or pass zeros
        else:
             act_inputs = action_seq # Assume already shifted or aligned? 
             # Usually action_t causes state_{t+1}.
             
        # Actually for simplicity in Phase 1 (Representation only), we might skip Dynamics Training logic inside standard call
        # or implement a simpler loop.
        
        return {
            'reconstructions': reconstructions,
            'post_means': post_means,
            'post_logvars': post_logvars,
            'z_posts': z_posts
        }
