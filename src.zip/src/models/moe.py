import jax
import jax.numpy as jnp
from flax import linen as nn
from typing import Tuple, List

class Expert(nn.Module):
    num_actions: int
    features: Tuple[int, ...] = (64, 64)

    @nn.compact
    def __call__(self, x: jnp.ndarray) -> Tuple[jnp.ndarray, jnp.ndarray]:
        x = nn.Dense(64)(x)
        x = nn.relu(x)
        logits = nn.Dense(self.num_actions)(x)
        value = nn.Dense(1)(x)
        return logits, value

class MoENet(nn.Module):
    num_actions: int
    num_experts: int = 4
    hidden_dim: int = 64
    
    @nn.compact
    def __call__(self, x: jnp.ndarray, h: jnp.ndarray) -> Tuple[jnp.ndarray, jnp.ndarray, jnp.ndarray, jnp.ndarray]:
        """
        Recursive MoE Call.
        Input: x (obs), h (hidden state)
        Output: logits, value, router_weights, next_h
        """
        # 1. Recursive Router (GRU)
        # Scan over sequence if x has 3 dims [batch, seq, obs], but here we handle step-by-step
        h, router_h = nn.GRUCell(features=self.hidden_dim)(h, x)
        
        # 2. Expert Routing
        router_weights = nn.softmax(nn.Dense(self.num_experts)(router_h))
        
        # 3. Experts
        all_logits = []
        all_values = []
        for i in range(self.num_experts):
            logits, val = Expert(num_actions=self.num_actions, name=f'expert_{i}')(router_h) # Experts see memory-rich h
            all_logits.append(logits)
            all_values.append(val)
        
        stacked_logits = jnp.stack(all_logits, axis=0) # [experts, batch, actions]
        stacked_values = jnp.stack(all_values, axis=0) # [experts, batch, 1]
        
        w = jnp.moveaxis(router_weights, -1, 0)[..., jnp.newaxis]
        
        mixed_logits = jnp.sum(stacked_logits * w, axis=0)
        mixed_value = jnp.sum(stacked_values * w, axis=0)
        
        return mixed_logits, mixed_value, router_weights, h

    def initialize_carry(self, batch_size: int):
        return jnp.zeros((batch_size, self.hidden_dim))
