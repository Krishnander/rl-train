import jax
import jax.numpy as jnp

def calculate_redit_returns(weights: jnp.ndarray, 
                              spot_returns: jnp.ndarray, 
                              cost_pct: float = 0.003) -> jnp.ndarray:
    """
    Differentiable Trading Return Calculation.
    weights: [SeqLen, 3] (Probabilities for None/Short/Long or similar)
    spot_returns: [SeqLen]
    """
    
    # Simple discrete-to-soft mapping for differentiability
    # Assume weights are [HOLD, BUY_CE, BUY_PE, EXIT]
    # For simplicity, let's map to scalar position [-1, 0, 1]
    # Position = soft_BUY_CE - soft_BUY_PE
    pos = weights[:, 1] - weights[:, 2]
    
    # Portfolio Return: pos * spot_return - costs
    delta_pos = jnp.abs(pos[1:] - pos[:-1])
    tc = delta_pos * cost_pct
    
    returns = pos[:-1] * spot_returns[1:] - tc
    
    return returns

def calculate_max_drawdown(returns: jnp.ndarray) -> float:
    """
    Differentiable-ish max drawdown (using min of cumulative sum).
    """
    cum_returns = jnp.cumsum(returns)
    running_max = jnp.maximum.accumulate(cum_returns)
    drawdown = running_max - cum_returns
    return jnp.max(drawdown)
