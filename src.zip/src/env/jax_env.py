import jax
import jax.numpy as jnp
from typing import NamedTuple, Tuple, Dict, Any
from src.simulator.bs_pricer import bs_price, bs_greeks

class MarketState(NamedTuple):
    spot: float
    prev_close: float
    gap_pct: float
    vix: float # Keeping for legacy observation compatibility, but logic moves to iv_state
    vix_percentile: float
    atm_strike: float # ROLLING ATM STRIKE (V36)
    ce_price: float
    pe_price: float
    iv_skew: float
    days_to_expiry: int
    ce_delta: float
    pe_delta: float
    ce_theta: float
    pe_theta: float
    ce_gamma: float
    pe_gamma: float
    fii_momentum_5d: float
    fii_net_oi_z: float
    fii_velocity: float # ROC of FII flow
    retail_trap_z: float
    bid_ask_spread: float
    global_nasdaq_ret: float # Lead 1: US Tech
    global_usdinr_ret: float # Lead 2: Currency
    ma_50_slope: float  # SOTA Trend Feature 1: Slope of 50d MA
    ma_200_div: float   # SOTA Trend Feature 2: Divergence from 200d MA
    regime: int
    iv_state: float     # STOCHASTIC IV STATE (V36)

class EnvState(NamedTuple):
    market_state: MarketState
    position_type: int  # 0: None, 1: CE, 2: PE
    position_qty: int
    entry_price: float
    entry_day: int
    peak_equity: float
    current_equity: float
    trade_count: int
    current_step: int
    prev_action: int
    last_step_pnl: float
    rng: jax.random.PRNGKey

# ... (JaxOptionPricer remains same)

class JaxEnv:
    """Massively Parallel Nifty Environment with Regret-Capable Physics."""
    
    def __init__(self, initial_capital=200000.0):
        self.initial_capital = initial_capital
        self.lot_size = 65
        
    def reset(self, rng: jax.random.PRNGKey) -> Tuple[EnvState, jnp.ndarray]:
        rng, subkey = jax.random.split(rng)
        
        # REAL-WORLD CALIBRATED PARAMETERS (Digital Twin: NIFTY 2015-2025)
        # Extracted via calibrate_simulator.py from golden_dataset.parquet
        # Base Vol: 16.59%, Mean Rev: 0.1705, Jump: 1.04%
        
        # Random Initial Volatility (Regime Sampling)
        base_vol = 0.1659 
        vol_regime = jax.random.categorical(subkey, jnp.array([0.4, 0.4, 0.2])) # Low, Med, High
        initial_vol = base_vol * jnp.array([0.8, 1.0, 1.5])[vol_regime]
        
        # Initial Option Pricing (BS)
        spot = 22000.0
        # Nearest Strike Logic
        atm_strike = jnp.round(spot / 50.0) * 50.0
        days = 7.0
        r = 0.05 # Risk free
        
        # Initial Greeks & Prices
        ks = bs_greeks(spot, atm_strike, days/365.0, r, initial_vol)
        ce_price = bs_price(spot, atm_strike, days/365.0, r, initial_vol, 1)
        pe_price = bs_price(spot, atm_strike, days/365.0, r, initial_vol, -1)
        
        market = MarketState(
            spot=spot, prev_close=spot, gap_pct=0.0,
            vix=initial_vol * 100.0, vix_percentile=0.5, atm_strike=atm_strike,
            ce_price=ce_price, pe_price=pe_price, iv_skew=0.02,
            days_to_expiry=jnp.int32(days), 
            ce_delta=ks['delta_call'], pe_delta=ks['delta_put'],
            ce_theta=ks['theta_call'], pe_theta=ks['theta_put'], 
            ce_gamma=ks['gamma'], pe_gamma=ks['gamma'],
            fii_momentum_5d=0.0, fii_net_oi_z=0.0, fii_velocity=0.0,
            retail_trap_z=0.0, bid_ask_spread=0.002,
            global_nasdaq_ret=0.0, global_usdinr_ret=0.0,
            ma_50_slope=0.0, ma_200_div=0.0,
            regime=jnp.int32(0),
            iv_state=initial_vol
        )
        state = EnvState(
            market_state=market,
            position_type=jnp.int32(0), position_qty=jnp.int32(0), 
            entry_price=0.0, entry_day=jnp.int32(0),
            peak_equity=self.initial_capital, current_equity=self.initial_capital,
            trade_count=jnp.int32(0), current_step=jnp.int32(0), 
            prev_action=jnp.int32(0), last_step_pnl=0.0,
            rng=rng
        )
        return state, self._get_obs(state)

    def step(self, state: EnvState, action: int, cost_scale: float = 1.0, size_multiplier: float = 1.0) -> Tuple[EnvState, jnp.ndarray, float, bool, dict]:
        """Vectorizable step function with CALIBRATED market distributions."""
        m = state.market_state
        rng, subkey = jax.random.split(state.rng)
        
        # 1. Global Evolution (Leads the Nifty)
        rng, k_nas, k_fx = jax.random.split(rng, 3)
        nas_ret = jax.random.normal(k_nas) * 0.012 - 0.0002
        fx_ret = jax.random.normal(k_fx) * 0.005 + 0.0001
        
        # 2. CALIBRATED Market Regime Evolution
        transition_matrix = jnp.array([
            [0.85, 0.08, 0.04, 0.02, 0.01],  # From Normal
            [0.15, 0.70, 0.08, 0.04, 0.03],  # From HighVol
            [0.20, 0.10, 0.60, 0.08, 0.02],  # From Trending
            [0.30, 0.10, 0.10, 0.48, 0.02],  # From Sideways
            [0.25, 0.30, 0.20, 0.10, 0.15],  # From Extreme
        ])
        regime_logits = jnp.log(transition_matrix[m.regime])
        next_regime = jax.random.categorical(subkey, regime_logits)
        
        # Stochastic Vol Evolution (Mean Reverting + Regime Shocks)
        rng, k_iv = jax.random.split(rng)
        # Regime Targets for IV: Normal=16%, High=28%, Extreme=45%
        iv_targets = jnp.array([0.16, 0.28, 0.20, 0.14, 0.45]) 
        iv_target = iv_targets[next_regime]
        
        # OU Process: dIV = theta * (target - IV) + sigma * dW
        iv_reversion = 0.1 * (iv_target - m.iv_state) 
        iv_shock = jax.random.normal(k_iv) * 0.02 * (1.0 + (next_regime==4)*2.0) # Crash = Big Shock
        next_iv = jnp.clip(m.iv_state + iv_reversion + iv_shock, 0.09, 1.50) # Clip 9% to 150%
        
        # Realized Vol (Spot Move) depends on IV
        rng, k_spot = jax.random.split(rng)
        spot_ret = jax.random.normal(k_spot) * (next_iv / 16.0) # Daily Scaled approx
        next_spot = m.spot * (1.0 + spot_ret)
        
        # Update Trend Features (Simulated Physics)
        next_ma_50_slope = m.ma_50_slope * 0.95 + spot_ret * 0.05
        next_ma_200_div = m.ma_200_div * 0.99 + spot_ret
        
        # Update FII Flow (correlated to Price - Momentum)
        rng, k_fii = jax.random.split(rng)
        fii_chg = jax.random.normal(k_fii) * 0.1 + spot_ret * 5.0
        next_fii_velocity = m.fii_velocity * 0.7 + fii_chg
        next_fii_z = m.fii_net_oi_z + next_fii_velocity
        
        # 3. Rolling ATM Logic
        next_days = m.days_to_expiry - 1
        
        # New Strike Selection (Always ATM)
        raw_strike = jnp.round(next_spot / 50.0) * 50.0
        next_strike = raw_strike
        
        r = 0.05
        t_now = jnp.maximum(next_days / 365.0, 1e-5)
        
        # Price the HELD contract at current moment (Before Roll)
        held_ce_val = bs_price(next_spot, m.atm_strike, t_now, r, next_iv, 1)
        held_pe_val = bs_price(next_spot, m.atm_strike, t_now, r, next_iv, -1)
        
        # Price the NEW contract for State Update (After Roll)
        new_ce_price = bs_price(next_spot, next_strike, t_now, r, next_iv, 1)
        new_pe_price = bs_price(next_spot, next_strike, t_now, r, next_iv, -1)
        
        # Greeks for NEW contract
        new_ks = bs_greeks(next_spot, next_strike, t_now, r, next_iv)
        
        # 4. Action Logic (Concentration)
        # Position PnL (Mark-to-Market of HELD contract)
        prev_val = jnp.where(state.position_type == 1, m.ce_price, 
                     jnp.where(state.position_type == 2, m.pe_price, 0.0))
        curr_val = jnp.where(state.position_type == 1, held_ce_val,
                     jnp.where(state.position_type == 2, held_pe_val, 0.0))
                     
        gross_pnl_cash = (curr_val - prev_val) * state.position_qty
        
        changing_pos = action != state.position_type
        
        lot_qty = self.lot_size * 2 * size_multiplier
        
        # Spread Cost: 0.02% of Spot (approx 4 pts)
        spread_cost = m.spot * 0.0002 * cost_scale * lot_qty 
        
        # If changing position direction -> Pay full spread (Open + Close)
        # If holding -> Pay roll spread (smaller, say 10% for rolling strike)
        txn_cost = jnp.where(changing_pos, spread_cost, spread_cost * 0.1)
        
        # 5. Equity Update
        # Note: 'curr_val' and 'prev_val' are already computed in section 4.
        # But for clarity in this large step function, we re-verify or reuse.
        
        # We need the price of the contract we *held* (Mark-to-Market).
        # We already computed 'held_ce_val' and 'held_pe_val' (Price at T_now, S_next).
        
        # prev_prem is the price at the START of the step (m.ce_price).
        # next_prem is the price of the SAME contract at the END of the step (held_ce_val).
        
        prev_prem = jnp.where(state.position_type == 1, m.ce_price, 
                        jnp.where(state.position_type == 2, m.pe_price, 0.0))
        
        next_prem = jnp.where(state.position_type == 1, held_ce_val,
                        jnp.where(state.position_type == 2, held_pe_val, 0.0))
        
        cash_change = (next_prem - prev_prem) * state.position_qty - txn_cost
        next_equity = state.current_equity + cash_change
        
        # 6. ACTION SHIELDING (Risk Management)
        # If Drawdown > 20% from Peak, Force Done (Hard Stop)
        # If Equity < 60% of Initial, Force Done (Bankruptcy Protection)
        current_peak = jnp.maximum(state.peak_equity, next_equity)
        drawdown_pct = (current_peak - next_equity) / current_peak
        
        shield_triggered = (drawdown_pct > 0.20) | (next_equity < self.initial_capital * 0.60)
        
        reward = cash_change / self.initial_capital
        
        # 7. Teacher Policy (Rational Greeks Oracle)
        # Instead of Hindsight, use Rationality:
        # If Delta > 0.6 (Strong Bull) -> Call
        # If Delta < -0.6 (Strong Bear) -> Put
        # If Gamma * Vol^2 > Theta (Vol Breakout) -> Buy Leg favoring Delta
        # This is a "Rational" teacher, not a "Cheating" one.
        # BUT for KC-1.0 (Kickstart), we usually want "Best Possible Action".
        # Let's keep Hindsight for now as the "Upper Bound" teacher but add constraints.
        
        best_possible = jnp.maximum((held_ce_val - m.ce_price), (held_pe_val - m.pe_price))
        best_possible = jnp.maximum(best_possible, 0.0) / m.spot 
        
        # Assemble State
        next_market = m._replace(
            spot=next_spot, ce_price=new_ce_price, pe_price=new_pe_price,
            vix=next_iv * 100.0, atm_strike=next_strike,
            fii_net_oi_z=next_fii_z, fii_velocity=next_fii_velocity,
            global_nasdaq_ret=nas_ret, global_usdinr_ret=fx_ret,
            ma_50_slope=next_ma_50_slope, ma_200_div=next_ma_200_div,
            regime=next_regime, iv_state=next_iv,
            days_to_expiry=jnp.int32(next_days),
            ce_delta=new_ks['delta_call'], pe_delta=new_ks['delta_put'],
            ce_theta=new_ks['theta_call'], pe_theta=new_ks['theta_put'],
            ce_gamma=new_ks['gamma'], pe_gamma=new_ks['gamma']
        )
        
        # Done condition (Horizon OR Shield Trigger)
        done = shield_triggered | (state.current_step + 1 >= 30)
        
        next_state = state._replace(
            market_state=next_market,
            position_type=action.astype(jnp.int32),
            position_qty=jnp.where(action > 0, lot_qty, 0).astype(jnp.int32),
            current_equity=next_equity, peak_equity=current_peak, 
            current_step=state.current_step + 1,
            prev_action=action, last_step_pnl=reward, rng=rng
        )
        
        return next_state, self._get_obs(next_state), reward, done, {'oracle_reward': best_possible}

    def _get_obs(self, state: EnvState) -> jnp.ndarray:
        m = state.market_state
        return jnp.array([
            (m.spot / 22000.0) - 1.0, m.gap_pct * 10.0, m.vix / 50.0, m.vix_percentile,
            m.ce_price / 300.0, m.pe_price / 300.0, m.iv_skew * 10.0, m.days_to_expiry.astype(jnp.float32) / 10.0,
            m.ce_delta, m.pe_delta + 1.0, m.ce_theta / 100.0, m.pe_theta / 100.0,
            m.fii_momentum_5d / 5000.0, m.fii_net_oi_z / 3.0, m.fii_velocity * 10.0,
            m.retail_trap_z / 2.5, 
            m.global_nasdaq_ret * 50.0, m.global_usdinr_ret * 100.0, # GLOBAL LEADS
            m.ma_50_slope * 20.0, m.ma_200_div * 10.0, 0.0 * m.regime, # V36 PATCH: BLIND ACTOR (Masked Regime)
            state.position_type.astype(jnp.float32) / 2.0,
            state.prev_action.astype(jnp.float32) / 3.0, state.last_step_pnl * 10.0
        ])
