import jax
import jax.numpy as jnp
from flax import linen as nn
from typing import Tuple, List

class Expert(nn.Module):
    """Standard MLP Expert."""
    num_actions: int
    hidden_dim: int = 64

    @nn.compact
    def __call__(self, x: jnp.ndarray) -> Tuple[jnp.ndarray, jnp.ndarray]:
        x = nn.Dense(self.hidden_dim, name='fc1')(x)
        x = nn.relu(x)
        logits = nn.Dense(self.num_actions, name='logits')(x)
        value = nn.Dense(1, name='value')(x)
        return logits, value

class DeepSeekMoE(nn.Module):
    """
    DeepSeek-Style MoE Architecture:
    1. Shared Experts (Always Active)
    2. Routed Experts (Top-K Gating with Loss-Free Load Balancing)
    """
    num_actions: int
    num_experts: int = 8  # Increased from 4
    num_shared: int = 1   # Always active
    top_k: int = 2
    hidden_dim: int = 64
    
    @nn.compact
    def __call__(self, x: jnp.ndarray, h: jnp.ndarray) -> Tuple[jnp.ndarray, jnp.ndarray, jnp.ndarray, jnp.ndarray]:
        # 1. Recurrent State Update (GRU)
        # Note: x is [obs_dim] or [seq, obs_dim]? Assuming step-by-step
        h, embedding = nn.GRUCell(features=self.hidden_dim)(h, x)
        
        # 2. Shared Expert Path
        # Captures general market knowledge (Friction, Liquidity, etc.)
        shared_logits_sum = jnp.zeros(self.num_actions)
        shared_value_sum = jnp.zeros(1)
        
        for i in range(self.num_shared):
            # Shared experts see the memory 'embedding'
            s_logits, s_val = Expert(num_actions=self.num_actions, hidden_dim=self.hidden_dim, name=f'shared_expert_{i}')(embedding)
            shared_logits_sum += s_logits
            shared_value_sum += s_val
            
        # 3. Routed Expert Path
        # Captures specialized knowledge (Regimes)
        
        # Router: Maps embedding -> [num_experts] scores
        router_logits = nn.Dense(self.num_experts, name='router')(embedding)
        
        # LOSS-FREE BALANCING (Bias Injection)
        # We expect 'router_bias' to be passed in 'params' or 'variables'.
        # Since we use standard linen, we can define a variable 'router_bias'.
        # However, for training stability, we track it in 'batch_stats' or similar?
        # For this prototype, we'll assume router_logits includes the bias (Dense has bias).
        # To make it dynamic, we would update the bias parameter in the Training Loop.
        
        # Top-K Gating
        router_probs = nn.softmax(router_logits)
        top_k_probs, top_k_indices = jax.lax.top_k(router_probs, self.top_k)
        
        # Normalize weights
        top_k_weights = top_k_probs / jnp.sum(top_k_probs, axis=-1, keepdims=True)
        
        # Execute Routed Experts
        routed_logits_sum = jnp.zeros(self.num_actions)
        routed_value_sum = jnp.zeros(1)
        
        # We iterate all experts and mask. (Efficient implementation involves specialized kernels,
        # but for JAX/Flax loop over experts is acceptable for small num checks)
        
        # Efficient JAX Map: Vmap over experts?
        # Since parameters are distinct, we can't vmap easily without blocking params.
        # Loop is fine for < 16 experts.
        
        for i in range(self.num_experts):
            # Check if this expert is in top_k
            # (In JAX, dynamic branching is tricky, we use masks)
            # Create mask: 1.0 if i in top_k_indices else 0.0
            
            # Mask generation
            is_active = jnp.sum(jnp.where(top_k_indices == i, 1.0, 0.0))
            
            # Get weight
            # If active, find the weight index
            # weight = sum(where(indices==i, weights, 0))
            weight = jnp.sum(jnp.where(top_k_indices == i, top_k_weights, 0.0))
            
            # Run expert (always run or mask? JAX runs all usually, masking output)
            # To be truly conditional, we need lax.cond/switch.
            # But standard Soft-TopK runs all and masks. 
            # For 8 experts, running all is acceptable.
            
            e_logits, e_val = Expert(num_actions=self.num_actions, hidden_dim=self.hidden_dim, name=f'routed_expert_{i}')(embedding)
            
            routed_logits_sum += e_logits * weight
            routed_value_sum += e_val * weight
            
        # 4. Combine
        # DeepSeek adds Shared + Routed
        final_logits = shared_logits_sum + routed_logits_sum
        final_value = shared_value_sum + routed_value_sum
        
        return final_logits, final_value, router_probs, h

    def initialize_carry(self, batch_size: int):
        return jnp.zeros((batch_size, self.hidden_dim))
