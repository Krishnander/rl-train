"""
Intraday Bar Generator.

Generates 375 minute bars per trading day from daily OHLC data.
Uses volatility clustering (GARCH) and U-shaped diurnal pattern.

Based on research:
- Diurnal volatility pattern (high at open/close, low at midday)
- GARCH(1,1) for volatility clustering
- Constrained to hit daily OHLC exactly
"""

import numpy as np
from typing import Tuple, List, Dict
from dataclasses import dataclass

@dataclass
class IntradayBar:
    """Single minute bar."""
    minute: int  # 0-374 (9:15 AM to 3:30 PM)
    timestamp_minutes: int  # Minutes from market open
    open: float
    high: float
    low: float
    close: float
    volume: float
    vwap: float
    volatility: float  # Realized vol for this bar
    
    
class IntradayGenerator:
    """
    Generate realistic intraday minute bars from daily OHLC.
    
    Features:
    - U-shaped diurnal volatility pattern
    - GARCH(1,1) volatility clustering
    - Constrained to hit daily High, Low, Close
    - VIX-dependent base volatility
    """
    
    MINUTES_PER_DAY = 375  # 9:15 AM to 3:30 PM = 6.25 hours
    
    # GARCH(1,1) parameters (calibrated to typical equity markets)
    GARCH_OMEGA = 0.00001
    GARCH_ALPHA = 0.08
    GARCH_BETA = 0.90
    
    def __init__(self, seed: int = None):
        self.rng = np.random.default_rng(seed)
    
    def _diurnal_pattern(self, minute: int) -> float:
        """
        U-shaped volatility pattern throughout the day.
        
        High at open (9:15) → Low at midday (12:00) → High at close (3:30)
        
        Returns: multiplier (0.5 to 1.5)
        """
        # Normalize minute to [0, 1] for the trading day
        t = minute / self.MINUTES_PER_DAY
        
        # U-shape: high at t=0 and t=1, low at t=0.5
        # Using parabola: y = 4 * (t - 0.5)^2 + 0.5
        # This gives: t=0 → 1.5, t=0.5 → 0.5, t=1 → 1.5
        u_shape = 4 * (t - 0.5) ** 2 + 0.5
        
        return u_shape
    
    def _simulate_garch_path(self, n_steps: int, base_vol: float) -> np.ndarray:
        """
        Simulate volatility path using GARCH(1,1).
        
        σ²_t = ω + α * ε²_{t-1} + β * σ²_{t-1}
        """
        omega = self.GARCH_OMEGA
        alpha = self.GARCH_ALPHA
        beta = self.GARCH_BETA
        
        # Initialize
        vol_sq = np.zeros(n_steps)
        vol_sq[0] = (base_vol / np.sqrt(252 * self.MINUTES_PER_DAY)) ** 2
        
        for t in range(1, n_steps):
            # Previous shock
            epsilon = self.rng.normal(0, np.sqrt(vol_sq[t-1]))
            
            # GARCH update
            vol_sq[t] = omega + alpha * epsilon**2 + beta * vol_sq[t-1]
        
        return np.sqrt(vol_sq)
    
    def generate_intraday_bars(self, 
                                daily_open: float,
                                daily_high: float,
                                daily_low: float,
                                daily_close: float,
                                daily_volume: float,
                                vix: float = 15.0,
                                date_str: str = "") -> List[IntradayBar]:
        """
        Generate 375 minute bars for a single trading day.
        
        Args:
            daily_open, daily_high, daily_low, daily_close: Daily OHLC
            daily_volume: Daily volume
            vix: VIX level (for volatility scaling)
            date_str: Date string for logging
            
        Returns:
            List of 375 IntradayBar objects
        """
        n = self.MINUTES_PER_DAY
        
        # Base volatility from VIX (annualized → per-minute)
        annual_vol = vix / 100.0
        minute_vol = annual_vol / np.sqrt(252 * n)
        
        # Generate GARCH volatility path
        garch_vols = self._simulate_garch_path(n, annual_vol)
        
        # Apply diurnal pattern
        diurnal = np.array([self._diurnal_pattern(m) for m in range(n)])
        local_vols = garch_vols * diurnal
        
        # Generate returns
        returns = self.rng.normal(0, local_vols)
        
        # Generate raw price path (cumulative returns)
        cumulative_returns = np.cumsum(returns)
        
        # Create normalized path [0, 1] → [open, close]
        # Path starts at 0, ends at total drift
        total_drift = np.log(daily_close / daily_open)
        
        # Normalize to have correct start/end
        if len(cumulative_returns) > 0:
            path_drift = cumulative_returns - cumulative_returns[0]
            path_normalized = path_drift / (path_drift[-1] + 1e-8) if abs(path_drift[-1]) > 1e-8 else path_drift * 0
            path_adjusted = path_normalized * total_drift
        else:
            path_adjusted = np.zeros(n)
        
        # Convert to prices
        raw_prices = np.zeros(n + 1)
        raw_prices[0] = daily_open
        raw_prices[1:] = daily_open * np.exp(path_adjusted)
        raw_prices[-1] = daily_close  # Ensure exact close
        
        # === SCALE TO HIT HIGH AND LOW ===
        current_high = np.max(raw_prices)
        current_low = np.min(raw_prices)
        
        # Apply affine transformation to hit targets
        # We want: new_high = daily_high, new_low = daily_low
        if current_high != current_low:
            scale = (daily_high - daily_low) / (current_high - current_low)
            offset = daily_low - current_low * scale
            prices = raw_prices * scale + offset
            
            # Re-adjust to preserve open and close
            prices[0] = daily_open
            prices[-1] = daily_close
        else:
            prices = raw_prices
        
        # Generate volume profile (also U-shaped)
        volume_profile = diurnal / np.sum(diurnal)  # Normalize
        minute_volumes = daily_volume * volume_profile
        
        # Generate bars
        bars = []
        for m in range(n):
            bar_open = prices[m]
            bar_close = prices[m + 1]
            
            # Intraday high/low (add some noise)
            if bar_close > bar_open:
                bar_low = bar_open * (1 - 0.0005 * self.rng.random())
                bar_high = bar_close * (1 + 0.0005 * self.rng.random())
            else:
                bar_high = bar_open * (1 + 0.0005 * self.rng.random())
                bar_low = bar_close * (1 - 0.0005 * self.rng.random())
            
            # VWAP (average of OHLC as approximation)
            vwap = (bar_open + bar_high + bar_low + bar_close) / 4
            
            bars.append(IntradayBar(
                minute=m,
                timestamp_minutes=m,
                open=bar_open,
                high=bar_high,
                low=bar_low,
                close=bar_close,
                volume=minute_volumes[m],
                vwap=vwap,
                volatility=local_vols[m]
            ))
        
        return bars
    
    def generate_from_dataframe(self, df, start_idx: int = 0, num_days: int = 30) -> List[List[IntradayBar]]:
        """
        Generate intraday bars for multiple days from a DataFrame.
        
        Args:
            df: DataFrame with columns ['nifty_open', 'nifty_high', 'nifty_low', 'nifty_close', 'nifty_volume', 'vix_close']
            start_idx: Starting row index
            num_days: Number of days to generate
            
        Returns:
            List of days, each containing list of IntradayBar
        """
        all_days = []
        
        for i in range(start_idx, min(start_idx + num_days, len(df))):
            row = df.iloc[i]
            
            bars = self.generate_intraday_bars(
                daily_open=row['nifty_open'],
                daily_high=row['nifty_high'],
                daily_low=row['nifty_low'],
                daily_close=row['nifty_close'],
                daily_volume=row.get('nifty_volume', 1e8),
                vix=row.get('vix_close', 15),
                date_str=str(row.get('date', i))
            )
            
            all_days.append(bars)
        
        return all_days


# === OPTION INTRADAY DYNAMICS ===

class OptionIntradayModel:
    """
    Model intraday option dynamics.
    
    Features:
    - Theta decay (accelerates toward close)
    - Gamma scalping opportunities
    - IV mean reversion intraday
    """
    
    def __init__(self):
        pass
    
    def intraday_theta_decay(self, dte: float, minute: int) -> float:
        """
        Calculate proportion of daily theta that decays by this minute.
        
        Theta accelerates toward end of day (closer to expiry).
        
        Returns: decay_rate (0 to 1)
        """
        n = IntradayGenerator.MINUTES_PER_DAY
        t = minute / n  # Proportion of day elapsed
        
        # Theta decay is not linear - accelerates toward close
        # Using quadratic: decay = t^1.5 (faster at end)
        if dte <= 1:
            # Last day - even more acceleration
            decay = t ** 2.0
        else:
            decay = t ** 1.3
        
        return decay
    
    def intraday_gamma_pnl(self, spot_move_pct: float, gamma: float, spot: float) -> float:
        """
        Calculate gamma P&L from intraday spot move.
        
        Gamma P&L = 0.5 * Gamma * (ΔS)^2
        """
        delta_s = spot * spot_move_pct
        return 0.5 * gamma * delta_s ** 2
    
    def intraday_iv_adjustment(self, minute: int, daily_iv: float) -> float:
        """
        Intraday IV tends to mean-revert to daily average.
        
        Higher IV at open/close, lower at midday.
        """
        n = IntradayGenerator.MINUTES_PER_DAY
        t = minute / n
        
        # Same U-shape as price vol, but smaller magnitude
        u_shape = 4 * (t - 0.5) ** 2 + 0.8
        adjustment = 1.0 + 0.05 * (u_shape - 1.0)  # ±5% variation
        
        return daily_iv * adjustment


if __name__ == "__main__":
    # Test: Generate intraday bars for sample day
    gen = IntradayGenerator(seed=42)
    
    bars = gen.generate_intraday_bars(
        daily_open=22000,
        daily_high=22150,
        daily_low=21900,
        daily_close=22100,
        daily_volume=1e9,
        vix=18
    )
    
    print(f"Generated {len(bars)} minute bars")
    print(f"\nFirst 5 bars:")
    for b in bars[:5]:
        print(f"  Min {b.minute}: O={b.open:.2f} H={b.high:.2f} L={b.low:.2f} C={b.close:.2f} Vol={b.volatility:.6f}")
    
    print(f"\nLast 5 bars:")
    for b in bars[-5:]:
        print(f"  Min {b.minute}: O={b.open:.2f} H={b.high:.2f} L={b.low:.2f} C={b.close:.2f} Vol={b.volatility:.6f}")
    
    print(f"\nDay Summary:")
    print(f"  Open: {bars[0].open:.2f} (Target: 22000)")
    print(f"  Close: {bars[-1].close:.2f} (Target: 22100)")
    print(f"  High: {max(b.high for b in bars):.2f} (Target: 22150)")
    print(f"  Low: {min(b.low for b in bars):.2f} (Target: 21900)")
