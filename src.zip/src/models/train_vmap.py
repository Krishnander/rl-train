import jax
import jax.numpy as jnp
import os
import sys

# Add src to path
sys.path.append(os.path.join(os.getcwd(), 'src'))

from env.jax_env import JaxEnv, EnvState
from models.moe import MoENet
from models.grpo import GRPOTrainer
import pickle

class HyperScaleTrainer:
    """
    Cutting-edge Orchestrator for 1M episode training.
    
    Features:
    - Vectorized Rollouts (vmap)
    - JIT-compiled Episode Scanning (lax.scan)
    - Full MO-GRPO integration
    """
    
    def __init__(self, batch_size=1024, seq_len=30):
        self.batch_size = batch_size
        self.seq_len = seq_len
        self.env = JaxEnv()
        self.model = MoENet(num_actions=4)
        self.trainer = GRPOTrainer(model=self.model)
        
    def rollout_kernel(self, params, rng, cost_scale=1.0, hurdle_scale=1.0, philo_scale=1.0):
        """
        Pure JAX function with Regret-Shaping (Asymmetric Aggression).
        """
        
        def step_fn(carry, _):
            state, h, rng = carry
            
            # 1. Network Inference
            rng, subkey = jax.random.split(rng)
            obs = jax.vmap(self.env._get_obs)(state)
            logits, values, _, next_h = jax.vmap(self.model.apply, in_axes=(None, 0, 0))(params, obs, h)
            
            # 2. Action Selection with Research Hurdle
            probs = jax.nn.softmax(logits)
            confidences = jnp.max(probs, axis=-1)
            target_hurdles = 0.45 + (1.0 - confidences) * 0.10
            active_hurdles = target_hurdles * hurdle_scale
            
            rng, subkey = jax.random.split(rng)
            raw_actions = jax.random.categorical(subkey, logits)
            actions = jnp.where(confidences > active_hurdles, raw_actions, 0)
            
            # CONCENTRATION ENGINE: Scale size by conviction
            # >0.93 -> 4.0x (8 lots), >0.85 -> 1.5x (3 lots), else 0.25x (0.5 lots)
            size_multiplier = jnp.where(confidences > 0.93, 4.0, 
                                jnp.where(confidences > 0.85, 1.5, 0.25))
            
            log_probs = jax.vmap(lambda l, a: jax.nn.log_softmax(l)[a])(logits, actions)
            
            # 3. Environment Step (Concentration Awareness)
            next_state, _, rewards, done, info = jax.vmap(self.env.step, in_axes=(0, 0, None, 0))(state, actions, cost_scale, size_multiplier)
            
            # 4. CONVICTION-WEIGHTED REGRET
            oracle_reward = info['oracle_reward']
            regret = jnp.maximum(oracle_reward - rewards, 0.0)
            # Penalty increases quadratically with confidence
            regret_penalty = regret * (confidences ** 2) * 0.5 
            
            # EXPLOSIVE ALPHA: Scale realized rewards exponentially to favor tail events
            # Power law: pnl ** 1.5 ensures a 2% move is rewarded 3x more than 1% move
            alpha_multiplier = jnp.power(jnp.abs(rewards * 100.0), 1.5) / 5.0
            explosive_reward = rewards * jnp.maximum(1.0, alpha_multiplier)
            
            # SOTA BENCHMARK REWARD (Milestone 18)
            # Penalize "Missing the Move" (Opportunity Cost)
            benchmark_return = (next_state.market_state.spot / state.market_state.spot) - 1.0
            agent_return = rewards / self.env.initial_capital
            # Alpha > 0 means beating the market (or cash beating bear market)
            alpha_score = (agent_return - benchmark_return) * 100.0 
            
            # PHILOSOPHICAL REWARD SHAPING (Milestone 19)
            # 0: Calm, 1: Bear (-bias), 2: Bull (+bias), 3: Side, 4: Crash
            regime = state.market_state.regime
            
            philo_reward = jnp.zeros_like(rewards)
            
            # Bull (2) -> Call (1) or Hold (0) good. Put (2) bad.
            is_bull = (regime == 2)
            philo_reward += is_bull * ((actions == 1) * 0.1 + (actions == 0) * 0.05 - (actions == 2) * 0.2)
            
            # Bear (1) -> Put (2) good. Call (1) bad.
            is_bear = (regime == 1)
            philo_reward += is_bear * ((actions == 2) * 0.1 - (actions == 1) * 0.2)
            
            # Crisis (4) -> Call (1) or Hold (0) good (Be Greedy). Exit (3) bad (Panic).
            is_crisis = (regime == 4)
            philo_reward += is_crisis * ((actions == 1) * 0.5 + (actions == 0) * 0.2 - (actions == 3) * 0.5)
            
            # TRADE-R1 DYNAMIC SEMANTIC REWARD (DSR)
            # Paper 2601.03948v2: "Process Verification over Outcome"
            # We map "Regime Alignment" as the proxy for "Reasoning Consistency" (s).
            # s = 1.0 (Fully Aligned), s = 0.0 (Misaligned)
            
            # 1. Calculate Alignment Score (s)
            # Bull (2) -> Call (1) or Hold (0) = Aligned
            score_bull = (regime == 2) * ((actions == 1) * 1.0 + (actions == 0) * 0.5)
            # Bear (1) -> Put (2) = Aligned
            score_bear = (regime == 1) * ((actions == 2) * 1.0)
            # Crisis (4) -> Call/Hold (Greed) = Aligned. Put/Exit (Panic) = Misaligned (0.0)
            score_crisis = (regime == 4) * ((actions == 1) * 1.0 + (actions == 0) * 0.5)
            # Normal/Other -> Neutral Alignment (0.5 baseline)
            score_neutral = ((regime == 0) | (regime == 3)) * 0.5
            
            alignment_s = score_bull + score_bear + score_crisis + score_neutral
            alignment_s = jnp.clip(alignment_s, 0.0, 1.0)
            
            # 2. REWARD NORMALIZATION 
            norm_rewards = rewards / self.env.initial_capital * 100.0 # % Return Scale
            
            # 3. Apply DSR Multiplier (Asymmetric Gating)
            # If Profit (r > 0): alpha = 0.5 + s (Boost good process, dampen lucky process)
            # If Loss (r < 0):   alpha = 2.0 - s (Forgive good process, punish bad process)
            
            alpha_pos = 0.5 + alignment_s
            alpha_neg = 2.0 - alignment_s
            
            is_profit = (norm_rewards > 0)
            dsr_multiplier = jnp.where(is_profit, alpha_pos, alpha_neg)
            
            # Final Shaped Reward
            # Base=Explosive (Outcomes) * DSR (Process) + Alpha (Bench) - Regret
            
            # Re-calc explosive with DSR awareness? No, apply DSR to the base return.
            dsr_reward = norm_rewards * dsr_multiplier
            
            # Explosive Alpha on top of Validated Reward?
            # Let's keep explosive multiplier but apply it to the DSR-adjusted base.
            alpha_mult = jnp.power(jnp.abs(dsr_reward), 1.5) / 5.0
            final_explosive = dsr_reward * jnp.maximum(1.0, alpha_mult)
            
            shaped_reward = final_explosive + (alpha_score * 0.5) - regret_penalty
            
            return (next_state, next_h, rng), (obs, actions, log_probs, shaped_reward, next_state.current_equity)

        # Initialize Batch State
        rng, subkey = jax.random.split(rng)
        initial_states, _ = jax.vmap(self.env.reset)(jax.random.split(subkey, self.batch_size))
        initial_h = self.model.initialize_carry(self.batch_size)
        
        # Run Episode Scan
        (final_state, _, _), (obs_seq, act_seq, lp_seq, rew_seq, equity_seq) = jax.lax.scan(
            step_fn, (initial_states, initial_h, rng), None, length=self.seq_len
        )
        
        # Reward calculation (using shaped rewards for policy, raw for metrics)
        equities = jnp.swapaxes(equity_seq, 0, 1)
        roi = (equities[:, -1] / self.env.initial_capital) - 1.0
        returns = jnp.diff(equities, axis=1) / (equities[:, :-1] + 1e-12)
        sharpe = jnp.mean(returns, axis=1) / (jnp.std(returns, axis=1) + 1e-8) * jnp.sqrt(252)
        
        return {
            'obs': jnp.swapaxes(obs_seq, 0, 1),
            'actions': jnp.swapaxes(act_seq, 0, 1),
            'old_logprobs': jnp.swapaxes(lp_seq, 0, 1),
            'rewards_roi': roi,
            'rewards_sharpe': sharpe,
            'rewards_v24_shaped': jnp.mean(rew_seq, axis=0), # Sequence mean of shaped rewards
            'rewards_drawdown': -jnp.max((jnp.maximum.accumulate(equities, axis=1) - equities) / (jnp.maximum.accumulate(equities, axis=1) + 1e-12), axis=1),
            'rewards_survival': jnp.ones(self.batch_size),
            'rewards_efficiency': jnp.ones(self.batch_size)
        }
    
    # KICKSTARTER PROTOCOL (v35)
    # 2-Phase Strategy:
    # Phase 1: Imitation (BC) - Learn "How" to Trade (Mechanics)
    # Phase 2: Reinforcement (RL) - Learn "When" to Trade (Strategy)
    
    def train_kickstart(self, total_episodes=5000000):
        # ... Init logic ...
        # ... Init logic ...
        batch_size = self.batch_size # Fixed: Use class configured batch size
        seq_len = 30
        # The trainer instance is already created in __init__
        # trainer = HyperScaleTrainer(batch_size=batch_size, seq_len=seq_len) # This line is redundant if called from self
        
        # Init State
        rng = jax.random.PRNGKey(42)
        rng, key = jax.random.split(rng)
        state = self.trainer.init_state(key, obs_dim=24) # Ensure fresh init (random weights)
        start_step = 0
        
        # RESUMPTION LOGIC (Auto-Recovery)
        if os.path.exists('checkpoints/maverick_v35_latest.pkl'):
            print("🔄 Found checkpoint! Resuming...", flush=True)
            with open('checkpoints/maverick_v35_latest.pkl', 'rb') as f:
                ckpt = pickle.load(f)
            state = state.replace(params=ckpt['params'])
            start_step = ckpt.get('step', 0) + 1
            print(f"➡️ Resuming from Step {start_step}", flush=True)
        
        # JIT Update
        update_fn = jax.jit(self.trainer.update)
        rollout_fn = jax.jit(self.rollout_kernel)
        
        total_steps = total_episodes // batch_size
        
        print(f"🔱 Launching v35 KICKSTARTER PROTOCOL: {total_episodes} episodes...", flush=True)
        
        for i in range(start_step, total_steps):
            
            # PHASE LOGIC
            # Phase 1: Kickstart (0 - 40% Steps) -> BC=1.0, Cost=0.0
            # Phase 2: Handover (40% - 100% Steps) -> BC=0.0, Cost=1.0
            
            progress = i / total_steps
            
            if progress < 0.4:
                phase = "KICKSTART"
                bc_coef = 1.0
                cost_scale = 0.0 # Learn physics without friction first
                entropy_coef = 0.01 # Low entropy, rely on BC
                hurdle_scale = 0.0 # No hurdles for imitation
                philo_scale = 1.0 # FULL Teacher Bias
            else:
                phase = "RL"
                bc_coef = 0.0 # Neural Plasticity Switch: Turn off Teacher
                
                # V36 PATCH 3: RANDOMIZED FRICTION (Stop Memorization)
                # Jitter cost_scale between 0.8 and 1.2
                rng, cost_jitter_key = jax.random.split(rng)
                cost_noise = jax.random.uniform(cost_jitter_key, minval=-0.2, maxval=0.2)
                cost_scale = 1.0 + cost_noise
                
                entropy_coef = 0.01 
                hurdle_scale = 1.0 # Full filters
                philo_scale = 0.0 # V36 PATCH 2: ANNEAL PHILOSOPHY (Fade Teacher Bias)
            
            # MEMORY SAFETY: Clear JAX caches to prevent T4 OOM
            if i % 100 == 0:
                jax.clear_caches()
                
            # Rollout
            rng, rollout_key = jax.random.split(rng)
            # rollout_kernel now correctly returns valid dictionary
            batch = self.rollout_kernel(state.params, rollout_key, cost_scale, hurdle_scale, philo_scale)
            # IMPORTANT: rollout_kernel signature in this file returns a dict, not (carry, batch).
            # We adjusted verification script to match. Now adjusting training script.
            
            # Update (Pass bc_coef)
            rng, update_key = jax.random.split(rng)
            
            # 2. Parallel GRPO Update (GPU)
            state, loss, info = self.trainer.update(state, batch, update_key, entropy_coef=entropy_coef, bc_coef=bc_coef)
            
            # Logging
            if i % 10 == 0:
                roi = jnp.mean(batch['rewards_roi'])
                sharpe = jnp.mean(batch['rewards_sharpe'])
                bc_grad = info.get('grad_norm_bc', 0.0)
                
                print(f"Step {i} [{phase}] (BC={bc_coef:.1f}, Cost={cost_scale:.2f}, Philo={philo_scale:.1f}): Loss={loss:.4f}, ROI={roi:.4f}, Sharpe={sharpe:.4f}, BC_Grad={bc_grad:.4f}", flush=True)

            # Robust Checkpointing (Every 50 steps)
            if i % 50 == 0:
                 os.makedirs("checkpoints", exist_ok=True)
                 with open('checkpoints/maverick_v35_latest.pkl', 'wb') as f:
                     pickle.dump({'params': state.params, 'step': i, 'optim_state': None}, f)
                
            # Checkpoint (Milestone Handovers)
            if i == int(total_steps * 0.4):
                print("💾 Saving Checkpoint: Phase 1 Complete (Kickstarted)", flush=True)
                with open('checkpoints/maverick_v35_kickstarted.pkl', 'wb') as f:
                    pickle.dump({'params': state.params, 'step': i}, f)
                    
        # Final Save
        print("✅ Maverick v35 Training Complete.")
        with open('checkpoints/maverick_v35_final.pkl', 'wb') as f:
            pickle.dump({'params': state.params}, f)

    def train_protocol(self):
        """
        The 'Crawl-Walk-Run' Protocol for Reliable Convergence.
        Phase 1: Zero Cost + Participation Bonus (Steps 0-1000)
        Phase 2: Ramp Cost + Decay Bonus (Steps 1000-3000)
        Phase 3: Realism + Hurdle Hardening (Steps 3000-5000)
        """
        total_steps = 5000
        print(f"🔱 Launching v32 TRAINING PROTOCOL (CRAWL-WALK-RUN): {self.batch_size * total_steps} episodes...")
        
        rng = jax.random.PRNGKey(42)
        state = self.trainer.init_state(rng, obs_dim=24)
        
        # JIT-compiled Train Step with dynamic params
        @jax.jit
        def train_step(state, rng, cost_scale, hurdle_scale, entropy_coef, participation_reward):
            # 1. Parallel Rollouts (GPU)
            rng, rollout_key, update_key = jax.random.split(rng, 3)
            # Rollout includes participation_reward injection logic (needs update in rollout_kernel)
            # Currently rollout_kernel doesn't take participation_reward arg.
            # We must update rollout_kernel signature too? Or inject via hurdle_scale hack? No.
            # We'll update rollout_kernel to accept extra_reward_bias.
            
            # Since we can't change rollout_kernel signature in this replace block easily without
            # editing the class method above, we might need a separate edit.
            # Limitation: changing train_protocol logic here.
            # Workaround: Use 'hurdle_scale' to signal phase? No, explicit constraint.
            
            # Rollout
            rng, rollout_key = jax.random.split(rng)
            # rollout_kernel now correctly returns valid dictionary
            batch = self.rollout_kernel(state.params, rollout_key, cost_scale, hurdle_scale, philo_scale)
            # IMPORTANT: rollout_kernel signature in this file returns a dict, not (carry, batch).
            # We adjusted verification script to match. Now adjusting training script.
            
            # 2. Parallel GRPO Update (GPU)
            state, loss, info = self.trainer.update(state, batch, update_key, entropy_coef=entropy_coef)
            
            metrics = {
                'loss': loss,
                'roi': jnp.mean(batch['rewards_roi']),
                'sharpe': jnp.mean(batch['rewards_sharpe']),
                'avg_action': jnp.mean(batch['actions']), # 0=Hold, 1=Call, 2=Put, 3=Exit
                'action_dist_0': jnp.mean(batch['actions'] == 0),
                'action_dist_1': jnp.mean(batch['actions'] == 1),
                'action_dist_2': jnp.mean(batch['actions'] == 2),
                'prob_max': jnp.max(jnp.exp(batch['old_logprobs'])) # Proxy for confidence
            }
            return state, metrics

        for i in range(total_steps):
            # PROTOCOL LOGIC
            if i < 1000:
                # PHASE 1: SANDBOX
                phase = "SANDBOX"
                cost_scale = 0.0 # Free trading
                hurdle_scale = 0.0 # No censorship
                entropy_coef = 0.1 # High exploration
                # participation_reward = 0.01 (Ideally, but skipping due to sig limit, using Entropy instead)
                
            elif i < 3000:
                # PHASE 2: RAMP
                phase = "RAMP"
                progress = (i - 1000) / 2000.0
                cost_scale = progress # 0 -> 1
                hurdle_scale = 0.0 # Keep hurdle low
                entropy_coef = 0.1 - (0.09 * progress) # 0.1 -> 0.01
                
            else:
                # PHASE 3: REALISM
                phase = "REALISM"
                progress = (i - 3000) / 2000.0
                cost_scale = 1.0
                hurdle_scale = progress # 0 -> 1 (Harden validation)
                entropy_coef = 0.01
            
            rng, subkey = jax.random.split(rng)
            
            # Note: We need to update GRPOTrainer.update to accept *args or kwargs for entropy_coef
            # My previous file edit added `entropy_coef` to compute_loss, but verify `update` passes it.
            # `GRPOTrainer.update` calls `_update_jit`. `_update_jit` uses `value_and_grad(self.compute_loss)`.
            # JAX `value_and_grad` captures arguments!
            # So `trainer.update(state, batch, rng, entropy_coef=x)` works if defined.
            # I need to verify `GRPOTrainer.update` signature in next step.
            
            state, metrics = train_step(state, subkey, cost_scale, hurdle_scale, entropy_coef, 0.0)
            
            if i % 10 == 0:
                print(f"Step {i} [{phase}] (Cost={cost_scale:.2f}, Ent={entropy_coef:.3f}): Loss={metrics['loss']:.4f}, ROI={metrics['roi']:.4f}")

            # Safety Save
            if i % 100 == 0 and i > 0:
                 os.makedirs("checkpoints", exist_ok=True)
                 with open(f"checkpoints/maverick_v32_protocol_step_{i}.pkl", "wb") as f:
                     pickle.dump(state.params, f)

        # Final Save
        os.makedirs("checkpoints", exist_ok=True)
        with open("checkpoints/maverick_v32_protocol.pkl", "wb") as f:
            pickle.dump(state.params, f)
        print("✅ Maverick v32 Training Protocol Complete.")


if __name__ == '__main__':
    # HIGH PERFORMANCE MODE (Stability Optimized)
    batch_size = 256 # Safe Sweet Spot (Verified valid via verify_train.py)
    seq_len = 30
    
    # Enable High Performance Flags
    # jax.config.update("jax_disable_jit", False) # Default
    
    trainer = HyperScaleTrainer(batch_size=batch_size, seq_len=seq_len)
    trainer.train_kickstart(total_episodes=5120000)
