"""
Production-grade Nifty Options Trading Environment.

Full 18-feature state space per DESIGN.md specification.
Integrates microstructure and FrictionFilter from AI_Trader.
"""

import numpy as np
import pandas as pd
from typing import Tuple, Dict, Any, List, Optional
from dataclasses import dataclass
from simulator.simulator import MarketSimulator, MarketState
from simulator.microstructure import Microstructure
from simulator.friction_filter import FrictionFilter

@dataclass
class PortfolioState:
    """Track portfolio state for observation."""
    position_type: int  # 0: None, 1: CE, 2: PE
    position_qty: int
    entry_price: float
    entry_day: int
    peak_equity: float
    current_equity: float
    trade_count: int


class NiftyEnv:
    """
    Production-grade Gym-like environment for Nifty Options Trading.
    
    Features:
    - 18-feature observation space per DESIGN.md
    - VIX-dependent microstructure (realistic execution)
    - Full portfolio tracking (drawdown, days in trade)
    - Multi-objective reward support
    """
    
    OBS_FEATURES = 24
    OBS_DIM = 24
    
    def __init__(self, initial_capital: float = 200000.0):
        self.simulator = MarketSimulator()
        self.microstructure = Microstructure()
        self.friction_filter = FrictionFilter()  # The "financial miracle" from AI_Trader
        self.initial_capital = initial_capital
        self.lot_size = 65
        
        # Regime-based trading gates (from AI_Trader)
        # In CALM regime, require higher edge to trade
        self.regime_edge_multiplier = {
            0: 2.0,   # CALM: Need 2x normal edge (don't trade unless very confident)
            1: 1.0,   # BULL: Normal edge required
            2: 1.2,   # BEAR: Slightly higher edge
            3: 0.8    # CRISIS: Lower edge OK (high vol = high reward)
        }
        # Baseline portfolio state (will be re-initialized in reset)
        self.portfolio = None 
        
        self.reset()
    
    def reset(self, fixed_regime: Optional[int] = None) -> np.ndarray:
        """Reset environment for new episode."""
        self.episode_data = self.simulator.generate_episode(days=30, fixed_regime=fixed_regime)
        self.current_step = 0
        
        # Portfolio state
        self.portfolio = PortfolioState(
            position_type=0,
            position_qty=0,
            entry_price=0.0,
            entry_day=0,
            peak_equity=self.initial_capital,
            current_equity=self.initial_capital,
            trade_count=0
        )
        
        # Track returns for Sharpe calculation
        self.daily_returns = []
        self.prev_equity = self.initial_capital
        
        # Feedback Features (Recursive Loop)
        self.prev_action = 0
        self.last_step_pnl = 0.0
        
        return self._get_obs()
    
    def _get_obs(self) -> np.ndarray:
        """
        Construct 19-feature normalized observation vector.
        """
        state = self.episode_data[self.current_step]
        
        # Calculate unrealized P&L
        unrealized_pnl_pct = 0.0
        if self.portfolio.position_qty > 0:
            current_price = state.ce_price if self.portfolio.position_type == 1 else state.pe_price
            unrealized_pnl_pct = (current_price - self.portfolio.entry_price) / self.portfolio.entry_price
        
        # Calculate drawdown from peak
        drawdown = (self.portfolio.peak_equity - self.portfolio.current_equity) / self.portfolio.peak_equity
        
        # Days in current trade
        days_in_trade = 0
        if self.portfolio.position_type > 0:
            days_in_trade = self.current_step - self.portfolio.entry_day
        
        obs = np.array([
            (state.spot / 22000.0) - 1.0, 
            state.gap_pct * 10.0,
            state.vix / 50.0,
            state.vix_percentile,
            state.ce_price / 300.0,
            state.pe_price / 300.0,
            state.iv_skew * 10.0,
            float(state.days_to_expiry) / 10.0,
            state.ce_delta,
            state.pe_delta + 1.0,
            state.ce_theta / 100.0,
            state.pe_theta / 100.0,
            state.fii_momentum_5d / 5000.0,
            state.fii_net_oi_z / 3.0,
            state.fii_velocity * 10.0,
            state.retail_trap_z / 2.5,
            0.0, # global_nasdaq_ret placeholder
            0.0, # global_usdinr_ret placeholder
            state.ma_50_slope * 20.0, state.ma_200_div * 10.0, float(state.regime) / 4.0, # SOTA REGIME FEATURES
            float(self.portfolio.position_type) / 2.0,
            float(self.prev_action) / 3.0,
            self.last_step_pnl * 10.0
        ], dtype=np.float32)
        
        return obs
    
    def step(self, action: int, expected_edge_pct: Optional[float] = None, size_multiplier: float = 1.0) -> Tuple[np.ndarray, float, bool, Dict[str, Any]]:
        """
        Execute action and return (obs, reward, done, info).
        
        Args:
            action: 0: HOLD, 1: BUY_CE, 2: BUY_PE, 3: EXIT
            expected_edge_pct: Optional dynamic edge prediction from model value head.
            size_multiplier: Confidence-based sizing (Concentration Engine).
        """
        state = self.episode_data[self.current_step]
        reward = 0.0
        done = False
        
        # Execute action
        # SNIPER PATCH: Minimum hold time of 3 days before allowing exit
        days_held = 0
        if self.portfolio.position_type > 0:
            days_held = self.current_step - self.portfolio.entry_day
        
        if action == 3 and self.portfolio.position_qty > 0:
            reward = self._close_position(state)
        elif action == 1 and self.portfolio.position_type != 1:
            # FRICTION FILTER: Check if we should skip this trade
            premium = state.ce_price
            qty = int(2 * self.lot_size * size_multiplier)
            edge_mult = self.regime_edge_multiplier.get(state.regime, 1.0)
            
            # MIRACLE: Use dynamic value prediction if available, else fallback to heuristic
            if expected_edge_pct is None:
                base_edge = 0.05 if state.vix > 20 else 0.03
                expected_edge_pct = base_edge / edge_mult
            
            skip, reason = self.friction_filter.should_skip(
                expected_edge_pct, state.vix, state.gap_pct, premium, qty
            )
            
            if skip:
                reward = 0.0
            else:
                if self.portfolio.position_type == 2:
                    reward += self._close_position(state)
                reward += self._open_position(state, pos_type=1, size_multiplier=size_multiplier)
                
        elif action == 2 and self.portfolio.position_type != 2:
            # FRICTION FILTER: Check if we should skip this trade
            premium = state.pe_price
            qty = int(2 * self.lot_size * size_multiplier)
            edge_mult = self.regime_edge_multiplier.get(state.regime, 1.0)
            
            if expected_edge_pct is None:
                base_edge = 0.05 if state.vix > 20 else 0.03
                expected_edge_pct = base_edge / edge_mult
            
            skip, reason = self.friction_filter.should_skip(
                expected_edge_pct, state.vix, state.gap_pct, premium, qty
            )
            
            if skip:
                reward = 0.0
            else:
                if self.portfolio.position_type == 1:
                    reward += self._close_position(state)
                reward += self._open_position(state, pos_type=2, size_multiplier=size_multiplier)
        
        # Advance time
        self.current_step += 1
        if self.current_step >= len(self.episode_data) - 1:
            if self.portfolio.position_qty > 0:
                reward += self._close_position(self.episode_data[self.current_step])
            done = True
        
        # Track daily return for Sharpe
        daily_return = (self.portfolio.current_equity - self.prev_equity) / self.prev_equity
        self.daily_returns.append(daily_return)
        self.prev_equity = self.portfolio.current_equity
        
        # Time penalty (opportunity cost)
        if not done:
            reward -= 0.00005
            
        # Update Feedback State
        self.prev_action = action
        self.last_step_pnl = daily_return
        
        obs = self._get_obs()
        
        # Compute info for multi-objective rewards
        info = self._compute_episode_metrics(state, done)
        
        return obs, reward, done, info


    
    def _open_position(self, state: MarketState, pos_type: int, size_multiplier: float = 1.0) -> float:
        """Open position with realistic execution."""
        mid_price = state.ce_price if pos_type == 1 else state.pe_price
        qty = int(2 * self.lot_size * size_multiplier)  # Baseline is 2 lots
        
        # Get execution price with microstructure
        exec_price, fees = self.microstructure.total_trade_cost(
            mid_price, qty, state.vix, is_buy=True
        )
        
        total_cost = exec_price * qty + fees
        
        self.portfolio.position_type = pos_type
        self.portfolio.position_qty = qty
        self.portfolio.entry_price = exec_price
        self.portfolio.entry_day = self.current_step
        self.portfolio.trade_count += 1
        self.portfolio.current_equity -= fees  # Deduct fees immediately
        
        # Return negative reward for transaction cost
        return -fees / self.initial_capital
    
    def _close_position(self, state: MarketState) -> float:
        """Close position with realistic execution."""
        mid_price = state.ce_price if self.portfolio.position_type == 1 else state.pe_price
        qty = self.portfolio.position_qty
        
        # Get execution price with microstructure
        exec_price, fees = self.microstructure.total_trade_cost(
            mid_price, qty, state.vix, is_buy=False
        )
        
        # Calculate P&L
        gross_pnl = (exec_price - self.portfolio.entry_price) * qty
        net_pnl = gross_pnl - fees
        
        self.portfolio.current_equity += net_pnl
        self.portfolio.peak_equity = max(self.portfolio.peak_equity, self.portfolio.current_equity)
        
        # Reset position
        self.portfolio.position_type = 0
        self.portfolio.position_qty = 0
        self.portfolio.entry_price = 0.0
        
        return net_pnl / self.initial_capital
    
    def _compute_episode_metrics(self, state: MarketState, done: bool) -> Dict[str, Any]:
        """Compute metrics for multi-objective reward calculation."""
        pnl_realized = self.portfolio.current_equity - self.initial_capital
        max_dd = (self.portfolio.peak_equity - self.portfolio.current_equity) / self.portfolio.peak_equity
        
        # Sharpe calculation
        if len(self.daily_returns) > 1:
            returns = np.array(self.daily_returns)
            sharpe = np.mean(returns) / (np.std(returns) + 1e-8) * np.sqrt(252)
        else:
            sharpe = 0.0
        
        return {
            'capital': self.portfolio.current_equity,
            'pnl_realized': pnl_realized,
            'roi': pnl_realized / self.initial_capital,
            'max_drawdown': max_dd,
            'sharpe': sharpe,
            'trade_count': self.portfolio.trade_count,
            'survival_pct': self.current_step / len(self.episode_data),
            'regime': state.regime,
            'spot': state.spot,
            'done': done
        }
